# AI FLOOD PREDICTION & HYDROLOGICAL MODELLING PLAN

## 1. Physical Hydrology Baseline

### 1.1 Rational Method for Peak Urban Runoff
Urban peak discharge is formulated as:
$$Q_p = 0.278 \cdot C \cdot I \cdot A$$
Where:
- $Q_p$: Peak runoff discharge in $\text{m}^3/\text{s}$
- $C$: Composite runoff coefficient (0.70 to 0.90 for high-density Indore urban core like Rajwada and Sarafa; 0.45 to 0.60 for residential like Scheme 54 and Annapurna).
- $I$: Rainfall intensity in $\text{mm}/\text{hr}$
- $A$: Sub-catchment area in $\text{km}^2$

### 1.2 SCS-CN (Soil Conservation Service Curve Number)
To estimate cumulative direct runoff depth $Q$ from storm rainfall $P$:
$$Q = \frac{(P - I_a)^2}{(P - I_a) + S} \quad \text{for } P > I_a$$
Where:
- Initial abstraction $I_a \approx 0.2 \cdot S$
- Potential maximum retention $S = \frac{25400}{\text{CN}} - 254 \text{ mm}$
- Indore black cotton soil (Vertisols) exhibits low baseline infiltration capacity when saturated, yielding high Curve Numbers ($\text{CN} = 85 \text{ to } 93$ in urban wards).

### 1.3 Inundation Depth & Drainage Capacity Deficit
The rate of floodwater accumulation in a catchment basin is governed by mass balance:
$$\frac{dV}{dt} = Q_{\text{inflow}}(t) - Q_{\text{outflow}}(t)$$
Where $Q_{\text{outflow}}$ is bounded by drainage channel conveyance capacity (Kahn River storm outfall $\approx 45 \text{ m}^3/\text{s}$, Saraswati tributary $\approx 28 \text{ m}^3/\text{s}$) minus silt reduction:
$$Q_{\text{actual\_outfall}} = Q_{\text{rated}} \cdot (1 - \text{silt\_blockage\_pct})$$
If $Q_{\text{inflow}} > Q_{\text{actual\_outfall}}$, excess volume ponds in low-lying depressions, calculating localized surface water depth:
$$d_{\text{water}} = \frac{V_{\text{ponding}}}{A_{\text{depression}}}$$

---

## 2. Multi-Horizon AI Forecasting (1h, 2h, 3h)

```
[ Weather Ingestion: Radar/Sensors/Forecast ]
                    |
                    v
[ Missing Data & Outlier Imputation Engine ]
                    |
                    v
[ Soil Saturation & Antecedent Moisture State ]
                    |
                    v
[ Hybrid Physics-Informed Runoff Network ]
       |                  |                 |
       v                  v                 v
[ Horizon T+1h ]   [ Horizon T+2h ]  [ Horizon T+3h ]
  - Water Depth      - Water Depth     - Water Depth
  - Hazard Level     - Hazard Level    - Hazard Level
  - 90% Confidence   - 85% Confidence  - 78% Confidence
```

### 2.1 Model Inputs
1. Current rainfall rate ($\text{mm}/\text{hr}$) and 3-hour cumulative precipitation.
2. Antecedent moisture index (0-100%).
3. Catchment elevation delta relative to river outfall.
4. Impervious surface fraction from GIS land cover.
5. Live IoT ultrasonic water level telemetry.
6. Silt blockage percentage from field engineer inspection.

### 2.2 Model Versioning & Reproducibility
- Version: `ifi-hybrid-v1.2.0`
- Baseline: Physical Rational-SCS Hydrograph
- ML Layer: Gradient Boosting / Random Forest regressor with calibrated quantile regressors ($q_{0.05}$, $q_{0.50}$, $q_{0.95}$) for uncertainty estimation.
- Training pipeline: `backend/ml/train.py` outputs JSON model metrics and weights.
- Benchmark: Evaluates RMSE (cm) and F1-Score for Critical Warning thresholds.
