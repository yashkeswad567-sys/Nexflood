import {
  User, CatchmentZone, SensorDevice, DrainageAsset, Incident,
  WorkOrder, RoadSegment, RouteResponse, PumpRecommendation,
  EmergencyShelter, AlertNotification, AuditLog, FloodStatusSummary
} from '../types';

import {
  INITIAL_ZONES, INITIAL_SENSORS, INITIAL_ASSETS, INITIAL_INCIDENTS,
  INITIAL_SHELTERS, INITIAL_WORK_ORDERS, INITIAL_PUMP_RECS, INITIAL_ALERTS
} from './demoData';

const BASE_URL = '/api/v1';

// Local storage persistent fallback state keys
const STORAGE_PREFIX = 'ifi_state_';

function getStored<T>(key: string, defaultVal: T): T {
  try {
    const raw = localStorage.getItem(STORAGE_PREFIX + key);
    return raw ? JSON.parse(raw) : defaultVal;
  } catch {
    return defaultVal;
  }
}

function setStored<T>(key: string, val: T): void {
  try {
    localStorage.setItem(STORAGE_PREFIX + key, JSON.stringify(val));
  } catch (e) {
    console.warn('LocalStorage save failed:', e);
  }
}

export const api = {
  // Auth
  async login(email: string, role: string = 'citizen'): Promise<{ access_token: string; user: User }> {
    try {
      const res = await fetch(`${BASE_URL}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password: 'password123', role })
      });
      if (res.ok) return await res.json();
    } catch (e) {
      console.warn('Backend login unavailable, fallback demo session');
    }
    return this.demoSession(role);
  },

  async demoSession(role: string): Promise<{ access_token: string; user: User }> {
    try {
      const res = await fetch(`${BASE_URL}/auth/demo-session`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ role })
      });
      if (res.ok) return await res.json();
    } catch {}

    const profiles: Record<string, User> = {
      citizen: { id: 'usr_c01', email: 'citizen@indore.gov.in', name: 'Pooja Sharma', role: 'citizen', organization: 'Indore Resident (Rajwada)' },
      municipal: { id: 'usr_m01', email: 'municipal@indore.gov.in', name: 'Dr. Anil Gupta', role: 'municipal', organization: 'IMC Disaster Cell' },
      field_engineer: { id: 'usr_e01', email: 'engineer@indore.gov.in', name: 'Vikram Singh', role: 'field_engineer', organization: 'IMC Drainage Division' },
      firefighter: { id: 'usr_f01', email: 'firefighter@indore.gov.in', name: 'Suresh Rathore', role: 'firefighter', organization: 'Indore Fire Rescue (Palasia)' }
    };
    const user = profiles[role] || profiles.citizen;
    return { access_token: `demo_token_${role}_${Date.now()}`, user };
  },

  // Flood Status & Simulation
  async getFloodStatus(): Promise<FloodStatusSummary> {
    try {
      const res = await fetch(`${BASE_URL}/flood/status`);
      if (res.ok) {
        const data = await res.json();
        setStored('flood_status', data);
        return data;
      }
    } catch {}

    const stored = getStored<FloodStatusSummary | null>('flood_status', null);
    if (stored) return stored;

    return {
      scenario_name: 'Monsoon Heavy Downpour',
      rainfall_rate_mmh: 42.5,
      rainfall_24h_accum_mm: 78.4,
      city_hazard_level: 'HIGH',
      city_max_depth_cm: 44.0,
      zones: INITIAL_ZONES,
      active_alerts_count: 2,
      timestamp: new Date().toISOString()
    };
  },

  async simulateScenario(scenarioName: string, rainfallMmh: number): Promise<FloodStatusSummary> {
    try {
      const res = await fetch(`${BASE_URL}/flood/simulate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ scenario_name: scenarioName, rainfall_rate_mmh: rainfallMmh })
      });
      if (res.ok) {
        const updated = await this.getFloodStatus();
        return updated;
      }
    } catch {}

    // Offline simulation update
    const prev = await this.getFloodStatus();
    const factor = rainfallMmh / 30.0;
    const updatedZones = prev.zones.map(z => {
      const newDepth = Math.min(140.0, Math.round(z.current_water_depth_cm * factor * 10) / 10);
      let hazard: any = 'LOW';
      if (newDepth >= 50.0) hazard = 'CRITICAL';
      else if (newDepth >= 30.0) hazard = 'HIGH';
      else if (newDepth >= 15.0) hazard = 'MODERATE';
      return {
        ...z,
        current_water_depth_cm: newDepth,
        current_hazard_level: hazard,
        soil_saturation_pct: Math.min(100.0, Math.round(z.soil_saturation_pct * (1 + factor * 0.1)))
      };
    });

    const maxDepth = Math.max(...updatedZones.map(z => z.current_water_depth_cm));
    const cityHazard = maxDepth >= 50.0 ? 'CRITICAL' : maxDepth >= 30.0 ? 'HIGH' : 'MODERATE';

    const result: FloodStatusSummary = {
      scenario_name: scenarioName,
      rainfall_rate_mmh: rainfallMmh,
      rainfall_24h_accum_mm: rainfallMmh * 1.8 + 15,
      city_hazard_level: cityHazard,
      city_max_depth_cm: maxDepth,
      zones: updatedZones,
      active_alerts_count: prev.active_alerts_count,
      timestamp: new Date().toISOString()
    };
    setStored('flood_status', result);
    return result;
  },

  // Routing
  async calculateRoute(origLat: number, origLng: number, destLat: number, destLng: number, mode: string = 'vehicle'): Promise<RouteResponse> {
    try {
      const res = await fetch(`${BASE_URL}/routing/calculate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          origin: { lat: origLat, lng: origLng },
          destination: { lat: destLat, lng: destLng },
          travel_mode: mode
        })
      });
      if (res.ok) return await res.json();
    } catch {}

    // Offline routing calculation
    const isOrigNearRajwada = Math.abs(origLat - 22.7196) < 0.02;
    return {
      origin: { lat: origLat, lng: origLng, nearest_node: isOrigNearRajwada ? 'Rajwada Chowk' : 'Palasia Square' },
      destination: { lat: destLat, lng: destLng, nearest_node: 'Vijay Nagar Square' },
      primary_route: {
        route_id: 'rt_safe_01',
        name: 'Flood-Aware Safe Route (Avoids Inundated Wards)',
        distance_km: 7.4,
        estimated_minutes: 22.5,
        max_flood_depth_cm: 8.0,
        hazard_risk_score: 12.0,
        path_coordinates: [
          [origLat, origLng],
          [22.7240, 75.8720], // High Court
          [22.7244, 75.8839], // Palasia
          [22.7533, 75.8937]  // Vijay Nagar
        ],
        turn_by_turn: [
          'Depart onto MG Road Bypass away from low basin',
          'Continue towards Sardar Patel Marg to Palasia',
          'Follow AB Road North to Vijay Nagar Square'
        ]
      },
      alternative_routes: [
        {
          route_id: 'rt_alt_01',
          name: 'Shortest Direct Route (High Flood Risk)',
          distance_km: 5.6,
          estimated_minutes: 17.0,
          max_flood_depth_cm: 48.0,
          hazard_risk_score: 82.0,
          warning: 'Passes through inundated underpasses with 48cm standing water!',
          path_coordinates: [
            [origLat, origLng],
            [22.7196, 75.8577],
            [22.7533, 75.8937]
          ],
          turn_by_turn: [
            'Direct route via inner city arterial',
            'Warning: Severe waterlogging reported at Rajwada underpass'
          ]
        }
      ],
      disclaimer: 'EXPERIMENTAL ROUTING ADVISORY: Real-time water depths may change rapidly. Never attempt to drive through standing water.'
    };
  },

  // Incidents & SOS
  async getIncidents(): Promise<Incident[]> {
    try {
      const res = await fetch(`${BASE_URL}/incidents`);
      if (res.ok) {
        const data = await res.json();
        setStored('incidents', data);
        return data;
      }
    } catch {}
    return getStored<Incident[]>('incidents', INITIAL_INCIDENTS);
  },

  async submitSOS(payload: { citizen_name: string; phone: string; location: { lat: number; lng: number; address: string }; people_stranded: number; has_medical_emergency: boolean; notes: string }): Promise<Incident> {
    try {
      const res = await fetch(`${BASE_URL}/incidents/sos`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      if (res.ok) {
        const created = await res.json();
        return created;
      }
    } catch {}

    const newInc: Incident = {
      id: `INC_SOS_${Date.now()}`,
      tracking_code: `IND-SOS-${Math.floor(1000 + Math.random() * 9000)}`,
      reported_by_name: payload.citizen_name,
      phone: payload.phone,
      incident_type: 'EMERGENCY_SOS',
      latitude: payload.location.lat,
      longitude: payload.location.lng,
      landmark_address: payload.location.address,
      severity: 'CRITICAL',
      people_stranded: payload.people_stranded,
      medical_emergency: payload.has_medical_emergency ? 1 : 0,
      status: 'DISPATCHED',
      assigned_unit: 'Palasia Fire Rescue Unit 1',
      notes: payload.notes,
      resolution_notes: 'Rescue crew dispatched immediately.',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    const all = await this.getIncidents();
    const updated = [newInc, ...all];
    setStored('incidents', updated);
    return newInc;
  },

  async submitReport(payload: { reporter_name: string; phone: string; latitude: number; longitude: number; landmark: string; severity: string; description: string }): Promise<Incident> {
    try {
      const res = await fetch(`${BASE_URL}/incidents/report`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      if (res.ok) return await res.json();
    } catch {}

    const newInc: Incident = {
      id: `INC_REP_${Date.now()}`,
      tracking_code: `IND-REP-${Math.floor(1000 + Math.random() * 9000)}`,
      reported_by_name: payload.reporter_name,
      phone: payload.phone,
      incident_type: 'WATERLOGGING_REPORT',
      latitude: payload.latitude,
      longitude: payload.longitude,
      landmark_address: payload.landmark,
      severity: payload.severity as any,
      people_stranded: 0,
      medical_emergency: 0,
      status: 'REPORTED',
      notes: payload.description,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    const all = await this.getIncidents();
    const updated = [newInc, ...all];
    setStored('incidents', updated);
    return newInc;
  },

  async updateIncidentStatus(incidentId: string, status: string, notes?: string): Promise<void> {
    try {
      await fetch(`${BASE_URL}/incidents/${incidentId}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status, notes })
      });
    } catch {}

    const all = await this.getIncidents();
    const updated = all.map(inc => inc.id === incidentId ? { ...inc, status: status as any, resolution_notes: notes || inc.resolution_notes, updated_at: new Date().toISOString() } : inc);
    setStored('incidents', updated);
  },

  async assignIncident(incidentId: string, unit: string): Promise<void> {
    try {
      await fetch(`${BASE_URL}/incidents/${incidentId}/assign`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ assigned_unit: unit })
      });
    } catch {}

    const all = await this.getIncidents();
    const updated = all.map(inc => inc.id === incidentId ? { ...inc, assigned_unit: unit, status: 'DISPATCHED' as any, updated_at: new Date().toISOString() } : inc);
    setStored('incidents', updated);
  },

  // IoT Sensors & Assets
  async getSensors(): Promise<SensorDevice[]> {
    try {
      const res = await fetch(`${BASE_URL}/iot/sensors`);
      if (res.ok) {
        const data = await res.json();
        setStored('sensors', data);
        return data;
      }
    } catch {}
    return getStored<SensorDevice[]>('sensors', INITIAL_SENSORS);
  },

  async getAssets(): Promise<DrainageAsset[]> {
    try {
      const res = await fetch(`${BASE_URL}/assets`);
      if (res.ok) {
        const data = await res.json();
        setStored('assets', data);
        return data;
      }
    } catch {}
    return getStored<DrainageAsset[]>('assets', INITIAL_ASSETS);
  },

  async updateAssetStatus(assetId: string, status: string): Promise<void> {
    try {
      await fetch(`${BASE_URL}/assets/${assetId}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status })
      });
    } catch {}

    const all = await this.getAssets();
    const updated = all.map(a => a.id === assetId ? { ...a, current_status: status as any } : a);
    setStored('assets', updated);
  },

  // Work Orders
  async getWorkOrders(): Promise<WorkOrder[]> {
    try {
      const res = await fetch(`${BASE_URL}/work-orders`);
      if (res.ok) {
        const data = await res.json();
        setStored('work_orders', data);
        return data;
      }
    } catch {}
    return getStored<WorkOrder[]>('work_orders', INITIAL_WORK_ORDERS);
  },

  async completeWorkOrder(woId: string, finalSilt: number, notes: string): Promise<void> {
    try {
      await fetch(`${BASE_URL}/work-orders/${woId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'COMPLETED', final_silt_pct: finalSilt, inspection_notes: notes })
      });
    } catch {}

    const all = await this.getWorkOrders();
    const updated = all.map(w => w.id === woId ? { ...w, status: 'COMPLETED' as any, final_silt_pct: finalSilt, inspection_notes: notes, completed_at: new Date().toISOString() } : w);
    setStored('work_orders', updated);
  },

  // Pump Recommendations
  async getPumpRecommendations(): Promise<PumpRecommendation[]> {
    try {
      const res = await fetch(`${BASE_URL}/iot/recommendations`);
      if (res.ok) {
        const data = await res.json();
        setStored('pump_recs', data);
        return data;
      }
    } catch {}
    return getStored<PumpRecommendation[]>('pump_recs', INITIAL_PUMP_RECS);
  },

  async actOnRecommendation(recId: string, action: 'ACCEPT' | 'OVERRIDE', notes?: string): Promise<void> {
    try {
      await fetch(`${BASE_URL}/iot/recommendations/${recId}/action`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action, notes })
      });
    } catch {}

    const all = await this.getPumpRecommendations();
    const updated = all.map(r => r.id === recId ? { ...r, status: (action === 'ACCEPT' ? 'ACCEPTED' : 'OVERRIDDEN') as any } : r);
    setStored('pump_recs', updated);
  },

  // Shelters & Alerts
  async getShelters(): Promise<EmergencyShelter[]> {
    try {
      const res = await fetch(`${BASE_URL}/shelters`);
      if (res.ok) return await res.json();
    } catch {}
    return INITIAL_SHELTERS;
  },

  async getAlerts(): Promise<AlertNotification[]> {
    try {
      const res = await fetch(`${BASE_URL}/alerts`);
      if (res.ok) {
        const data = await res.json();
        setStored('alerts', data);
        return data;
      }
    } catch {}
    return getStored<AlertNotification[]>('alerts', INITIAL_ALERTS);
  },

  async broadcastAlert(payload: { title: string; severity: string; target_zones: string; message: string; instructions: string }): Promise<void> {
    try {
      await fetch(`${BASE_URL}/alerts`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
    } catch {}

    const newAlert: AlertNotification = {
      id: `ALERT_${Date.now()}`,
      title: payload.title,
      severity: payload.severity as any,
      target_zones: payload.target_zones,
      message: payload.message,
      instructions: payload.instructions,
      created_at: new Date().toISOString(),
      expires_at: new Date(Date.now() + 6 * 3600000).toISOString(),
      is_active: 1
    };
    const all = await this.getAlerts();
    setStored('alerts', [newAlert, ...all]);
  },

  // AI Flood Copilot (OpenAI Powered)
  async getAIStatus(): Promise<{ configured: boolean; model: string; key_preview: string; service: string }> {
    try {
      const res = await fetch(`${BASE_URL}/ai/status`);
      if (res.ok) return await res.json();
    } catch {}
    const clientKey = (import.meta as any).env?.VITE_OPENAI_API_KEY || '';
    const hasKey = clientKey.length > 10;
    return {
      configured: hasKey,
      model: 'gpt-4o-mini',
      key_preview: hasKey ? clientKey.slice(0, 8) + '...' + clientKey.slice(-4) : 'Not Configured',
      service: 'OpenAI Flood Intelligence Copilot'
    };
  },

  async askAICopilot(prompt: string, context?: any): Promise<{ response: string; model: string; source: string }> {
    try {
      const res = await fetch(`${BASE_URL}/ai/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt, context })
      });
      if (res.ok) {
        const data = await res.json();
        if (data.response) return data;
      }
    } catch {}

    // Direct client fallback via VITE_OPENAI_API_KEY
    const clientKey = (import.meta as any).env?.VITE_OPENAI_API_KEY;
    if (clientKey) {
      try {
        const directRes = await fetch('https://api.openai.com/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${clientKey}`
          },
          body: JSON.stringify({
            model: 'gpt-4o-mini',
            messages: [
              {
                role: 'system',
                content: 'You are the Indore Flood Intelligence (IFI) Emergency AI Copilot. Provide concise, lifesaving flood navigation and shelter advice for Indore, MP, India. Advise staying off roads with >30cm water.'
              },
              { role: 'user', content: prompt }
            ],
            max_tokens: 350
          })
        });
        if (directRes.ok) {
          const directData = await directRes.json();
          return {
            response: directData.choices[0].message.content,
            model: directData.model || 'gpt-4o-mini',
            source: 'openai-client-direct'
          };
        }
      } catch (err) {
        console.warn('Direct OpenAI client call failed:', err);
      }
    }

    // Hydrological Rule-Based Fallback
    const p = prompt.toLowerCase();
    if (p.includes('rajwada') || p.includes('sarafa')) {
      return {
        response: 'Rajwada & Sarafa Basin is a natural low-lying commercial depression near Kahn River. With current rainfall, avoid basement storage and ground-level underpasses. Utilize MG Road Bypass.',
        model: 'rule-based-hydrology-baseline',
        source: 'local_hydrological_baseline'
      };
    }
    if (p.includes('shelter') || p.includes('safe')) {
      return {
        response: 'Active high-ground shelters: Holkar Stadium (Palasia, 2500 cap), Nehru Stadium (Navlakha, 3000 cap), Scheme 54 Community Hall (Vijay Nagar, 1200 cap). Medical kits and drinking water deployed.',
        model: 'rule-based-hydrology-baseline',
        source: 'local_hydrological_baseline'
      };
    }
    return {
      response: 'Indore Flood Intelligence Copilot: Monitor low basin zones along Kahn & Saraswati rivers. Dial 101 for rescue boat dispatch. Avoid driving across any water deeper than 30 cm.',
      model: 'rule-based-hydrology-baseline',
      source: 'local_hydrological_baseline'
    };
  }
};
