"""
Unit and Integration Tests for Hydrological & Flood Prediction Engine.
"""

import unittest
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
from backend.app.flood_engine import (
    calculate_scs_runoff, calculate_peak_discharge, compute_zone_hazard,
    run_flood_simulation, MODEL_VERSION
)
from backend.app.database import init_db
from backend.app.seed_data import seed_all_data

class TestFloodEngine(unittest.TestCase):
    
    @classmethod
    def setUpClass(cls):
        init_db()
        seed_all_data()

    def test_scs_runoff_physics(self):
        # Zero rainfall should give zero runoff
        self.assertEqual(calculate_scs_runoff(0.0, 90.0), 0.0)
        
        # Rainfall below initial abstraction should give zero runoff
        # For CN=90: S = 28.2mm, Ia = 5.64mm
        self.assertEqual(calculate_scs_runoff(4.0, 90.0), 0.0)
        
        # Significant rain should produce positive runoff monotonically
        runoff_50 = calculate_scs_runoff(50.0, 90.0)
        runoff_100 = calculate_scs_runoff(100.0, 90.0)
        self.assertGreater(runoff_50, 0.0)
        self.assertGreater(runoff_100, runoff_50)

    def test_rational_method_peak_discharge(self):
        # Q = 0.278 * C * I * A
        # C = 0.85, I = 50 mm/h, A = 4.0 km2 -> ~47.26 m3/s
        q = calculate_peak_discharge(50.0, 0.85, 4.0)
        self.assertAlmostEqual(q, 0.278 * 0.85 * 50.0 * 4.0, places=2)
        self.assertGreater(q, 45.0)

    def test_multi_horizon_forecasting(self):
        sample_zone = {
            "id": "zone_rajwada",
            "name": "Rajwada Basin",
            "elevation_m": 546.0,
            "catchment_area_km2": 4.8,
            "impervious_surface_ratio": 0.88,
            "soil_curve_number": 92.0,
            "drainage_capacity_m3s": 32.0
        }
        
        h0 = compute_zone_hazard(40.0, 60.0, sample_zone, horizon_hours=0.0)
        h1 = compute_zone_hazard(40.0, 60.0, sample_zone, horizon_hours=1.0)
        h2 = compute_zone_hazard(40.0, 60.0, sample_zone, horizon_hours=2.0)
        h3 = compute_zone_hazard(40.0, 60.0, sample_zone, horizon_hours=3.0)
        
        # Hazard levels should be valid strings
        valid_hazards = {"LOW", "MODERATE", "HIGH", "CRITICAL"}
        self.assertIn(h0["hazard_level"], valid_hazards)
        self.assertIn(h1["hazard_level"], valid_hazards)
        
        # Confidence interval lower bound should be <= depth <= upper bound
        self.assertLessEqual(h1["depth_ci_lower"], h1["water_depth_cm"])
        self.assertGreaterEqual(h1["depth_ci_upper"], h1["water_depth_cm"])
        
        # Confidence should degrade with forecast distance
        self.assertGreater(h0["confidence_pct"], h3["confidence_pct"])

    def test_full_simulation_run(self):
        result = run_flood_simulation("Test Cloudburst", 95.0, 80.0)
        self.assertEqual(result["scenario_name"], "Test Cloudburst")
        self.assertEqual(result["rainfall_rate_mmh"], 95.0)
        self.assertIn("city_hazard_level", result)
        self.assertEqual(result["model_version"], MODEL_VERSION)
        self.assertGreaterEqual(len(result["zones"]), 8)

if __name__ == "__main__":
    unittest.main()
