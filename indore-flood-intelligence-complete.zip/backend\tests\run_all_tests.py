"""
Master Test Runner for Indore Flood Intelligence (IFI).
Discovers and executes all backend unit, integration, hydrological, and RBAC tests.
"""

import unittest
import sys
import os

if __name__ == "__main__":
    test_dir = os.path.dirname(__file__)
    # Ensure package root is in sys.path
    project_root = os.path.dirname(os.path.dirname(test_dir))
    sys.path.insert(0, project_root)
    
    loader = unittest.TestLoader()
    suite = loader.discover(start_dir=test_dir, pattern="test_*.py")
    
    print("\n" + "=" * 70)
    print("INDORE FLOOD INTELLIGENCE — COMPREHENSIVE BACKEND TEST SUITE")
    print("=" * 70 + "\n")
    
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    print("\n" + "=" * 70)
    print(f"TESTS RUN: {result.testsRun} | ERRORS: {len(result.errors)} | FAILURES: {len(result.failures)}")
    print("=" * 70 + "\n")
    
    sys.exit(0 if result.wasSuccessful() else 1)
