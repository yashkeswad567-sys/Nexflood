import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, Role } from '../types';
import { api } from '../services/api';

interface AuthContextType {
  user: User | null;
  role: Role;
  token: string | null;
  login: (email: string, role?: Role) => Promise<void>;
  switchDemoRole: (role: Role) => Promise<void>;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  role: 'citizen',
  token: null,
  login: async () => {},
  switchDemoRole: async () => {},
  logout: () => {},
  isAuthenticated: false,
});

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(() => {
    try {
      const saved = localStorage.getItem('ifi_user');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const [token, setToken] = useState<string | null>(() => {
    return localStorage.getItem('ifi_token') || null;
  });

  // Default to citizen if not logged in
  const role: Role = user?.role || 'citizen';

  const login = async (email: string, targetRole: Role = 'citizen') => {
    const res = await api.login(email, targetRole);
    setUser(res.user);
    setToken(res.access_token);
    localStorage.setItem('ifi_user', JSON.stringify(res.user));
    localStorage.setItem('ifi_token', res.access_token);
  };

  const switchDemoRole = async (targetRole: Role) => {
    const res = await api.demoSession(targetRole);
    setUser(res.user);
    setToken(res.access_token);
    localStorage.setItem('ifi_user', JSON.stringify(res.user));
    localStorage.setItem('ifi_token', res.access_token);
  };

  const logout = () => {
    setUser(null);
    setToken(null);
    localStorage.removeItem('ifi_user');
    localStorage.removeItem('ifi_token');
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        role,
        token,
        login,
        switchDemoRole,
        logout,
        isAuthenticated: !!user,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
