"""
Synthetic Hydrological Dataset Generator for Indore Flood Intelligence (IFI).
Generates physically consistent rainfall-runoff hydrograph datasets based on
Indore's black cotton soil characteristics, urban density, and Kahn river basin geometry.
"""

import math
import random
import json
from typing import List, Dict, Any

def generate_hydro_samples(n_samples: int = 1500) -> List[Dict[str, float]]:
    """
    Generates training samples with physical features and observed water depths.
    """
    samples = []
    
    # Indore catchment baselines
    elevations = [545.0, 546.0, 547.0, 548.0, 552.0, 554.0, 558.0, 560.0]
    impervious_ratios = [0.88, 0.76, 0.82, 0.79, 0.85, 0.72, 0.68, 0.35]
    curve_numbers = [92.0, 86.0, 89.0, 88.0, 91.0, 84.0, 82.0, 74.0]
    capacities = [32.0, 55.0, 42.0, 38.0, 30.0, 46.0, 60.0, 90.0]
    
    for i in range(n_samples):
        idx = random.randint(0, len(elevations) - 1)
        elev = elevations[idx]
        imp = impervious_ratios[idx]
        cn = curve_numbers[idx]
        cap = capacities[idx]
        
        # Rainfall scenario
        rain_rate = random.uniform(5.0, 110.0) # mm/hr
        accum_rain_3h = rain_rate * random.uniform(1.2, 2.8)
        soil_moisture_pct = random.uniform(40.0, 95.0)
        silt_blockage_pct = random.uniform(5.0, 45.0)
        
        # Physical SCS calculation
        s = (25400.0 / cn) - 254.0
        ia = 0.2 * s
        if accum_rain_3h > ia:
            scs_runoff = ((accum_rain_3h - ia) ** 2) / ((accum_rain_3h - ia) + s)
        else:
            scs_runoff = 0.0
            
        # Rational peak inflow
        inflow = 0.278 * imp * rain_rate * (5.0 + random.uniform(0.0, 4.0))
        effective_capacity = cap * (1.0 - (silt_blockage_pct / 100.0))
        excess = max(0.0, inflow - effective_capacity)
        
        depression_factor = max(0.6, (560.0 - elev) / 12.0 + 0.8)
        
        # Target observed water depth (cm) with realistic environmental noise
        target_depth = (scs_runoff * 0.45 * depression_factor) + (excess * 0.85) + random.gauss(0, 1.2)
        target_depth = round(max(0.0, min(140.0, target_depth)), 2)
        
        samples.append({
            "rainfall_rate_mmh": round(rain_rate, 2),
            "accum_rain_3h_mm": round(accum_rain_3h, 2),
            "elevation_m": elev,
            "impervious_ratio": imp,
            "curve_number": cn,
            "drainage_capacity_m3s": cap,
            "silt_blockage_pct": round(silt_blockage_pct, 1),
            "soil_moisture_pct": round(soil_moisture_pct, 1),
            "observed_water_depth_cm": target_depth
        })
        
    return samples

if __name__ == "__main__":
    data = generate_hydro_samples(100)
    print(f"Generated {len(data)} physical hydrology sample records.")
