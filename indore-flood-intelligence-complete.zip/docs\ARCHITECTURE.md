# SYSTEM ARCHITECTURE — INDORE FLOOD INTELLIGENCE (IFI)

## 1. High-Level Architectural Topology

```
+---------------------------------------------------------------------------------+
|                                 CLIENT TIER                                     |
|  React 18 + TypeScript + Vite + Tailwind CSS + Lucide React + Leaflet + 3D Twin |
|                                                                                 |
|  +--------------------+  +--------------------+  +----------------------------+ |
|  | Citizen Dashboard  |  | Municipal Monitor  |  | Field Engineer Portal      | |
|  | - Map & Forecast   |  | - City Overview    |  | - Asset Inspections        | |
|  | - Safe Routing     |  | - Pump Recs & Auto |  | - Sensor Diagnostics       | |
|  | - Emergency SOS    |  | - Dispatch Center  |  | - Work Orders & Tasks      | |
|  +--------------------+  +--------------------+  +----------------------------+ |
|                                                                                 |
|  +--------------------+  +--------------------+  +----------------------------+ |
|  | Firefighter App    |  | 3D Digital Twin    |  | SaaS Control & Settings    | |
|  | - Incident Queue   |  | - 3D Terrain & Run |  | - RBAC & Org Isolation     | |
|  | - Flood Nav Route  |  | - Rain Scenarios   |  | - Dark/Light Theme Switch  | |
|  | - Status Lifecycle |  | - Mitig. Compare   |  | - Audit History & Logs     | |
|  +--------------------+  +--------------------+  +----------------------------+ |
+---------------------------------------+-----------------------------------------+
                                        | HTTP / REST + Event Streams
+---------------------------------------v-----------------------------------------+
|                                BACKEND TIER                                     |
|           Python 3.11+ / FastAPI / ASGI Server with Modular Engines             |
|                                                                                 |
|  +-------------------+  +-------------------+  +------------------------------+ |
|  | Auth & RBAC Guard |  | Flood Prediction  |  | Flood-Aware Route Engine     | |
|  | - JWT Tokens      |  | - Rational/SCS-CN |  | - Indore Road Graph          | |
|  | - Roles (4 tiers) |  | - 1h/2h/3h Pred.  |  | - Depth Hazard Penalties     | |
|  | - Demo Sessions   |  | - Confidence CIs  |  | - Safe & Alt Path Compute    | |
|  +-------------------+  +-------------------+  +------------------------------+ |
|                                                                                 |
|  +-------------------+  +-------------------+  +------------------------------+ |
|  | IoT Telemetry API |  | Incident Manager  |  | Drainage Asset Advisor       | |
|  | - ESP32 Endpoint  |  | - Citizen SOS Hub |  | - Inflow vs Capacity Calc   | |
|  | - Range Validation|  | - Dispatch Engine |  | - Advisory Generation       | |
|  | - Heartbeat Check |  | - Lifecycle Hook  |  | - Audit Trail Log            | |
|  +-------------------+  +-------------------+  +------------------------------+ |
+---------------------------------------+-----------------------------------------+
                                        | SQLAlchemy / Spatial Abstraction
+---------------------------------------v-----------------------------------------+
|                               PERSISTENCE TIER                                  |
|         PostgreSQL + PostGIS (Production) / SQLite Spatial (Local / Zero-Conf)  |
|                                                                                 |
|  - Zones & Geofences    - IoT Sensor Logs       - Incidents & SOS Reports       |
|  - Drainage Network     - Road Segment Graph    - Work Orders & Inspections     |
|  - Forecast Snapshots   - Pump Advisories       - Audit & Activity Logs         |
+---------------------------------------------------------------------------------+
```

---

## 2. Core Subsystems

### 2.1 Citizen Portal & Emergency Lifecycle
- **Map & Real-Time Risk**: Citizens see live zone color-coding (Green, Yellow, Orange, Red) and water level sensor readings across Indore.
- **Flood-Aware Navigation**: Graph routing avoids waterlogged intersections (e.g. Rajwada underpass, Bhanwarkuan square) and supplies alternative safe paths with emergency disclaimers.
- **Life-Safety SOS**: Citizens submit distress signals with geolocation, stranded headcount, and medical priority. The ticket enters the municipal queue immediately.

### 2.2 Municipal Unified Command Center
- **Disaster Management Overview**: Aggregates city-wide telemetry, total precipitation, active pumps, and high-risk zones.
- **Scenario Simulator**: Operators simulate cloudbursts (e.g. 85mm/hr) to forecast downstream inundation before it occurs.
- **Asset & Pump Advisory**: Hydrological rules calculate required pump activation to prevent canal overflows along Kahn and Saraswati rivers.
- **Emergency Dispatch**: Assigns verified citizen SOS reports to nearest fire stations (Palasia, Cantonment) or field engineers.

### 2.3 Field Engineering & Infrastructure Maintenance
- **Asset Telemetry**: Tracks culverts, retention basins, sluice gates, and submersible storm pumps.
- **Inspection Logs**: Allows engineers to record silt accumulation percentage, blockage status, and maintenance sign-offs.
- **Sensor Calibration**: Alerts if water level sensors drift or report stale timestamps (>15 min delay).

### 2.4 Fire & Emergency Rescue Response
- **Dispatch Queue**: Prioritizes rescues by headcount and medical vulnerability.
- **Dynamic Routing**: Response vehicles receive live flood-aware navigational guidance avoiding flooded roads.
- **Status Lifecycle**: Dispatched -> En Route -> On Scene -> Evacuating -> Completed, updating the Citizen dashboard in real time.

### 2.5 3D Digital Twin
- Interactive WebGL/Canvas representation of Indore topography (elevation 553m AMSL), major water bodies (Bilawali, Pipliyapala, Kahn River channel), and dynamic floodwater surface extrusions responding to rainfall scenarios.
