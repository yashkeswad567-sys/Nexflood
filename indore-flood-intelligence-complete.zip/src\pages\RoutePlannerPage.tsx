import React, { useState } from 'react';
import { Navigation, Compass, AlertTriangle, ShieldCheck, ArrowRight, RefreshCw, Info } from 'lucide-react';
import { IndoreMapView } from '../components/map/IndoreMapView';
import { useFloodData } from '../context/FloodDataContext';
import { RouteResponse } from '../types';
import { api } from '../services/api';

export const RoutePlannerPage: React.FC = () => {
  const { floodStatus, sensors, shelters } = useFloodData();
  const zones = floodStatus?.zones || [];

  const [origId, setOrigId] = useState<string>('zone_rajwada');
  const [destId, setDestId] = useState<string>('zone_vijay_nagar');
  const [travelMode, setTravelMode] = useState<string>('vehicle');
  const [routeResult, setRouteResult] = useState<RouteResponse | null>(null);
  const [loading, setLoading] = useState<boolean>(false);

  const handlePlanRoute = async () => {
    const orig = zones.find(z => z.id === origId) || zones[0];
    const dest = zones.find(z => z.id === destId) || zones[1];
    if (!orig || !dest) return;

    setLoading(true);
    try {
      const res = await api.calculateRoute(orig.centroid_lat, orig.centroid_lng, dest.centroid_lat, dest.centroid_lng, travelMode);
      setRouteResult(res);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6">
      
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <Compass className="w-5 h-5 text-sky-500" />
            <h1 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
              Indore Flood-Aware Topological Route Engine
            </h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Impedance-weighted Dijkstra graph search evaluating standing water depth, underpass closures, and alternative paths.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-slate-500">Travel Mode:</span>
          <div className="flex p-0.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-xs font-semibold">
            {['vehicle', 'rescue_boat', 'walking'].map((m) => (
              <button
                key={m}
                onClick={() => setTravelMode(m)}
                className={`px-3 py-1 rounded-md capitalize transition-colors ${travelMode === m ? 'bg-sky-600 text-white shadow-sm' : 'text-slate-500'}`}
              >
                {m.replace('_', ' ')}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Control Inputs */}
      <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div>
          <label className="block text-xs font-semibold text-slate-500 mb-1">Origin Point</label>
          <select
            value={origId}
            onChange={(e) => setOrigId(e.target.value)}
            className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-semibold"
          >
            {zones.map(z => (
              <option key={z.id} value={z.id}>{z.name}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-500 mb-1">Destination Point</label>
          <select
            value={destId}
            onChange={(e) => setDestId(e.target.value)}
            className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-semibold"
          >
            {zones.map(z => (
              <option key={z.id} value={z.id}>{z.name}</option>
            ))}
          </select>
        </div>

        <div className="flex items-end">
          <button
            onClick={handlePlanRoute}
            disabled={loading}
            className="w-full py-2.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs shadow-md transition-all flex items-center justify-center gap-2"
          >
            {loading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Navigation className="w-4 h-4" />}
            <span>Calculate Route Geometry</span>
          </button>
        </div>
      </div>

      {/* Map + Route Details */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        <div className="lg:col-span-2">
          <IndoreMapView
            zones={zones}
            sensors={sensors}
            shelters={shelters}
            activeRoute={routeResult?.primary_route}
            alternativeRoute={routeResult?.alternative_routes[0]}
            height="520px"
          />
        </div>

        <div className="space-y-4">
          {routeResult ? (
            <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-sky-500">Route Geometry Computed</span>
                <h3 className="font-bold text-sm text-slate-900 dark:text-white mt-0.5">{routeResult.primary_route.name}</h3>
              </div>

              <div className="grid grid-cols-3 gap-2 text-xs">
                <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60">
                  <span className="text-slate-400 block text-[10px]">Distance</span>
                  <span className="font-bold">{routeResult.primary_route.distance_km} km</span>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60">
                  <span className="text-slate-400 block text-[10px]">Travel Time</span>
                  <span className="font-bold text-sky-500">{routeResult.primary_route.estimated_minutes} min</span>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60">
                  <span className="text-slate-400 block text-[10px]">Max Depth</span>
                  <span className="font-bold text-emerald-500">{routeResult.primary_route.max_flood_depth_cm} cm</span>
                </div>
              </div>

              <div>
                <span className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-2">Turn-by-Turn Navigation</span>
                <div className="space-y-1.5 text-xs text-slate-600 dark:text-slate-300">
                  {routeResult.primary_route.turn_by_turn.map((step, idx) => (
                    <div key={idx} className="flex items-start gap-2">
                      <span className="text-sky-500 font-bold">{idx + 1}.</span>
                      <span>{step}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-700 dark:text-amber-400 text-xs flex items-start gap-2">
                <Info className="w-4 h-4 shrink-0 mt-0.5" />
                <span>{routeResult.disclaimer}</span>
              </div>
            </div>
          ) : (
            <div className="p-8 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-center text-xs text-slate-400">
              Select origin and destination and click 'Calculate Safe Route' to view path geometry.
            </div>
          )}
        </div>

      </div>

    </div>
  );
};
