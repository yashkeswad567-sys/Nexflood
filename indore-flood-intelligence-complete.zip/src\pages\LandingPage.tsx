import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Waves, ShieldAlert, Cpu, Navigation, Activity, ArrowRight,
  ShieldCheck, CheckCircle2, Droplets, Radio, Building2, Flame, Wrench, Users
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useFloodData } from '../context/FloodDataContext';
import { Role } from '../types';

export const LandingPage: React.FC = () => {
  const { switchDemoRole } = useAuth();
  const { floodStatus } = useFloodData();
  const navigate = useNavigate();

  const handleLaunchRole = async (r: Role, path: string) => {
    await switchDemoRole(r);
    navigate(path);
  };

  return (
    <div className="flex flex-col min-h-screen">
      
      {/* Hero Section */}
      <section className="relative overflow-hidden pt-12 pb-20 lg:pt-20 lg:pb-28">
        
        {/* Subtle Background Glow */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-96 bg-gradient-to-b from-sky-500/10 via-indigo-500/5 to-transparent blur-3xl pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          
          <div className="text-center max-w-3xl mx-auto space-y-6">
            
            {/* Pill Tag */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full border border-sky-500/30 bg-sky-500/10 text-sky-600 dark:text-sky-400 text-xs font-bold tracking-wide">
              <span className="w-2 h-2 rounded-full bg-sky-500 animate-ping"></span>
              <span>24-Hour AI Hackathon Innovation for Smart Cities</span>
            </div>

            {/* Main Headline */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-slate-900 dark:text-white leading-[1.15]">
              AI-Powered Urban Drainage &{' '}
              <span className="bg-gradient-to-r from-sky-600 via-blue-600 to-indigo-600 dark:from-sky-400 dark:to-indigo-400 bg-clip-text text-transparent">
                Flash Flood Intelligence
              </span>
            </h1>

            {/* Sub-headline */}
            <p className="text-base sm:text-lg text-slate-600 dark:text-slate-300 max-w-2xl mx-auto leading-relaxed">
              Predictive stormwater management for the Indore Municipal Corporation (IMC). Combining physics-informed hydrology, real-time IoT sensors, flood-aware routing, and a 3D digital twin.
            </p>

            {/* Live City Telemetry Pill */}
            {floodStatus && (
              <div className="inline-flex items-center gap-3 p-2 px-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-md text-xs font-semibold">
                <span className="flex items-center gap-1.5 text-sky-500">
                  <Droplets className="w-4 h-4" />
                  {floodStatus.rainfall_rate_mmh.toFixed(1)} mm/h Rain
                </span>
                <span className="text-slate-300 dark:text-slate-700">|</span>
                <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                  floodStatus.city_hazard_level === 'CRITICAL' ? 'bg-rose-500 text-white' : 'bg-amber-500 text-white'
                }`}>
                  {floodStatus.city_hazard_level} RISK
                </span>
                <span className="text-slate-300 dark:text-slate-700">|</span>
                <span className="text-slate-500">Active Outfall: Kahn River (Khan Nadi)</span>
              </div>
            )}

            {/* Action CTA Buttons */}
            <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
              <button
                onClick={() => handleLaunchRole('citizen', '/dashboard/citizen')}
                className="px-6 py-3.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-sm shadow-lg shadow-sky-600/25 transition-all hover:scale-105 flex items-center gap-2"
              >
                <span>Launch Citizen Portal</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => handleLaunchRole('municipal', '/dashboard/municipal')}
                className="px-6 py-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 dark:bg-slate-800 dark:hover:bg-slate-700 text-white font-bold text-sm border border-slate-700 transition-all hover:scale-105 flex items-center gap-2"
              >
                <span>Municipal Command Center</span>
              </button>

              <Link
                to="/digital-twin"
                className="px-5 py-3.5 rounded-xl bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-600 dark:text-indigo-400 border border-indigo-500/20 font-bold text-sm transition-all"
              >
                Explore 3D Digital Twin
              </Link>
            </div>

          </div>

        </div>
      </section>

      {/* 4 Persona Portals Grid */}
      <section className="py-12 bg-slate-100/60 dark:bg-slate-900/40 border-y border-slate-200 dark:border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-2xl mx-auto mb-10 space-y-2">
            <h2 className="text-2xl font-extrabold text-slate-900 dark:text-white">
              End-to-End Enterprise Stakeholder Portals
            </h2>
            <p className="text-xs sm:text-sm text-slate-500">
              One unified platform tailored with role-based access control for citizens, officials, and first responders.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            
            {/* 1. Citizen Portal Card */}
            <div
              onClick={() => handleLaunchRole('citizen', '/dashboard/citizen')}
              className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-sky-500 transition-all hover:shadow-lg cursor-pointer group space-y-3"
            >
              <div className="w-12 h-12 rounded-xl bg-sky-500/10 text-sky-500 flex items-center justify-center group-hover:scale-110 transition-transform">
                <Users className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-base text-slate-900 dark:text-white">Citizen Portal</h3>
              <p className="text-xs text-slate-500 leading-relaxed">
                Localized rainfall telemetry, 1h-3h flood forecast timelines, flood-aware navigation routes, and life-safety SOS submission.
              </p>
              <span className="inline-flex items-center gap-1 text-xs font-bold text-sky-600 group-hover:translate-x-1 transition-transform">
                Open Citizen View &rarr;
              </span>
            </div>

            {/* 2. Municipal Command Card */}
            <div
              onClick={() => handleLaunchRole('municipal', '/dashboard/municipal')}
              className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-indigo-500 transition-all hover:shadow-lg cursor-pointer group space-y-3"
            >
              <div className="w-12 h-12 rounded-xl bg-indigo-500/10 text-indigo-500 flex items-center justify-center group-hover:scale-110 transition-transform">
                <Radio className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-base text-slate-900 dark:text-white">Municipal Command</h3>
              <p className="text-xs text-slate-500 leading-relaxed">
                City-wide flood risk heatmap, precipitation hydrographs, AI pump advisories, scenario simulators, and emergency dispatch.
              </p>
              <span className="inline-flex items-center gap-1 text-xs font-bold text-indigo-600 group-hover:translate-x-1 transition-transform">
                Open Command View &rarr;
              </span>
            </div>

            {/* 3. Field Engineer Card */}
            <div
              onClick={() => handleLaunchRole('field_engineer', '/dashboard/field-engineer')}
              className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-amber-500 transition-all hover:shadow-lg cursor-pointer group space-y-3"
            >
              <div className="w-12 h-12 rounded-xl bg-amber-500/10 text-amber-500 flex items-center justify-center group-hover:scale-110 transition-transform">
                <Wrench className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-base text-slate-900 dark:text-white">Field Engineering</h3>
              <p className="text-xs text-slate-500 leading-relaxed">
                Asset inspection workflows, post-desilting silt verification, ESP32 sensor heartbeat calibration, and fault ticketing.
              </p>
              <span className="inline-flex items-center gap-1 text-xs font-bold text-amber-600 group-hover:translate-x-1 transition-transform">
                Open Engineer View &rarr;
              </span>
            </div>

            {/* 4. Firefighter Card */}
            <div
              onClick={() => handleLaunchRole('firefighter', '/dashboard/firefighter')}
              className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-rose-500 transition-all hover:shadow-lg cursor-pointer group space-y-3"
            >
              <div className="w-12 h-12 rounded-xl bg-rose-500/10 text-rose-500 flex items-center justify-center group-hover:scale-110 transition-transform">
                <Flame className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-base text-slate-900 dark:text-white">Fire & Rescue Service</h3>
              <p className="text-xs text-slate-500 leading-relaxed">
                Priority SOS incident dispatch queue, flood-aware response navigation, boat deployment, and rescue progress lifecycle.
              </p>
              <span className="inline-flex items-center gap-1 text-xs font-bold text-rose-600 group-hover:translate-x-1 transition-transform">
                Open Rescue View &rarr;
              </span>
            </div>

          </div>

        </div>
      </section>

      {/* Core Technical Capabilities Section */}
      <section className="py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <h2 className="text-2xl font-extrabold text-slate-900 dark:text-white">
            Engineering & Hydrological Innovations
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            Built from scratch for the Indore drainage basin according to municipal stormwater standards.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-xs">
          
          <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3">
            <div className="p-3 rounded-xl bg-sky-500/10 text-sky-500 w-fit">
              <Cpu className="w-6 h-6" />
            </div>
            <h3 className="font-bold text-sm text-slate-900 dark:text-white">Physics-Informed AI Prediction</h3>
            <p className="text-slate-500 leading-relaxed">
              Combines the Rational Method ($Q_p = 0.278 C I A$) and SCS Curve Numbers for Indore black cotton vertisols with 1h, 2h, and 3h horizons and 90% confidence bounds.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3">
            <div className="p-3 rounded-xl bg-indigo-500/10 text-indigo-500 w-fit">
              <Navigation className="w-6 h-6" />
            </div>
            <h3 className="font-bold text-sm text-slate-900 dark:text-white">Dynamic Flood-Aware Graph Routing</h3>
            <p className="text-slate-500 leading-relaxed">
              NetworkX-compatible graph routing that applies quadratic flood impedance penalties, avoiding submerged underpasses and identifying safer alternative evacuation paths.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3">
            <div className="p-3 rounded-xl bg-emerald-500/10 text-emerald-500 w-fit">
              <Activity className="w-6 h-6" />
            </div>
            <h3 className="font-bold text-sm text-slate-900 dark:text-white">Interactive 3D Digital Twin</h3>
            <p className="text-slate-500 leading-relaxed">
              WebGL Cesium-compatible digital twin visualizing the 553m AMSL Indore depression, riverbed canals, animated floodwater rise, and scenario comparisons.
            </p>
          </div>

        </div>
      </section>

      {/* Footer */}
      <footer className="mt-auto py-8 border-t border-slate-200 dark:border-slate-800 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 space-y-2">
          <p className="font-bold">Indore Flood Intelligence (IFI) &copy; 2026</p>
          <p>Indore Municipal Corporation (IMC) Smart City Disaster Management Hackathon Project</p>
        </div>
      </footer>

    </div>
  );
};
