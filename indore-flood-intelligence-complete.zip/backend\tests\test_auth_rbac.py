"""
Unit and Integration Tests for Authentication, Token Verification and Role-Based Access Control.
"""

import unittest
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
from backend.app.auth import (
    create_access_token, verify_token, check_permission,
    create_demo_user, ROLE_PERMISSIONS
)

class TestAuthRBAC(unittest.TestCase):

    def test_token_creation_and_verification(self):
        token = create_access_token("usr_001", "test@indore.gov.in", "municipal", "Dr. Gupta", "IMC Disaster")
        self.assertIsInstance(token, str)
        self.assertEqual(len(token.split('.')), 3)
        
        payload = verify_token(token)
        self.assertIsNotNone(payload)
        self.assertEqual(payload["sub"], "usr_001")
        self.assertEqual(payload["role"], "municipal")
        self.assertEqual(payload["email"], "test@indore.gov.in")

    def test_tampered_token_rejection(self):
        token = create_access_token("usr_001", "test@indore.gov.in", "citizen", "Citizen", "Indore")
        parts = token.split('.')
        # Tamper payload
        tampered_token = f"{parts[0]}.eyJyYW5kb20iOiJib2d1cyJ9.{parts[2]}"
        self.assertIsNone(verify_token(tampered_token))

    def test_role_based_permissions(self):
        # Municipal can dispatch units and simulate scenarios
        self.assertTrue(check_permission("municipal", "dispatch_units"))
        self.assertTrue(check_permission("municipal", "simulate_scenarios"))
        
        # Citizen cannot dispatch units or simulate scenarios
        self.assertFalse(check_permission("citizen", "dispatch_units"))
        self.assertFalse(check_permission("citizen", "simulate_scenarios"))
        
        # Field engineer can submit inspections
        self.assertTrue(check_permission("field_engineer", "submit_inspections"))
        self.assertFalse(check_permission("citizen", "submit_inspections"))
        
        # Firefighter can accept incident and update rescue status
        self.assertTrue(check_permission("firefighter", "update_rescue_status"))
        self.assertFalse(check_permission("field_engineer", "update_rescue_status"))

    def test_demo_sessions_for_all_four_roles(self):
        roles = ["citizen", "municipal", "field_engineer", "firefighter"]
        for r in roles:
            demo = create_demo_user(r)
            self.assertIn("access_token", demo)
            self.assertEqual(demo["user"]["role"], r)
            verified = verify_token(demo["access_token"])
            self.assertIsNotNone(verified)
            self.assertEqual(verified["role"], r)

if __name__ == "__main__":
    unittest.main()
