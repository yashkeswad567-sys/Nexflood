import React, { useRef, useEffect, useState } from 'react';
import {
  Play, Pause, RotateCcw, Eye, Compass, Layers,
  Droplets, Waves, ShieldCheck, AlertTriangle, Maximize2
} from 'lucide-react';
import { useFloodData } from '../../context/FloodDataContext';
import { useTheme } from '../../context/ThemeContext';

export const IndoreDigitalTwin3D: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const { floodStatus, triggerScenario, sensors, assets } = useFloodData();
  const { theme } = useTheme();

  // 3D Controls State
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [timeStep, setTimeStep] = useState<number>(60); // minutes (0 to 180)
  const [cameraPreset, setCameraPreset] = useState<'aerial' | 'rajwada' | 'kahn' | 'vijay'>('aerial');
  const [mitigationMode, setMitigationMode] = useState<'mitigated' | 'unmitigated'>('mitigated');
  const [rainfallInput, setRainfallInput] = useState<number>(floodStatus?.rainfall_rate_mmh || 85.0);

  // Rotation angles
  const [yaw, setYaw] = useState<number>(45);
  const [pitch, setPitch] = useState<number>(35);
  const [zoom, setZoom] = useState<number>(1.0);
  const isDragging = useRef<boolean>(false);
  const lastMouse = useRef<{ x: number; y: number }>({ x: 0, y: 0 });

  // Camera presets
  const applyPreset = (preset: 'aerial' | 'rajwada' | 'kahn' | 'vijay') => {
    setCameraPreset(preset);
    if (preset === 'aerial') {
      setYaw(45);
      setPitch(40);
      setZoom(1.0);
    } else if (preset === 'rajwada') {
      setYaw(15);
      setPitch(25);
      setZoom(1.6);
    } else if (preset === 'kahn') {
      setYaw(80);
      setPitch(20);
      setZoom(1.8);
    } else if (preset === 'vijay') {
      setYaw(-30);
      setPitch(30);
      setZoom(1.4);
    }
  };

  // Automated Timeline Loop
  useEffect(() => {
    if (!isPlaying) return;
    const interval = setInterval(() => {
      setTimeStep((prev) => (prev >= 180 ? 0 : prev + 5));
    }, 400);
    return () => clearInterval(interval);
  }, [isPlaying]);

  // Sync rainfall input with global flood state
  useEffect(() => {
    if (floodStatus) {
      setRainfallInput(floodStatus.rainfall_rate_mmh);
    }
  }, [floodStatus?.rainfall_rate_mmh]);

  // Interactive 3D Canvas Renderer
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;

    const render = () => {
      const width = canvas.width;
      const height = canvas.height;
      ctx.clearRect(0, 0, width, height);

      // Background gradient
      const bgGrad = ctx.createLinearGradient(0, 0, 0, height);
      if (theme === 'dark') {
        bgGrad.addColorStop(0, '#090d16');
        bgGrad.addColorStop(1, '#0f172a');
      } else {
        bgGrad.addColorStop(0, '#f1f5f9');
        bgGrad.addColorStop(1, '#e2e8f0');
      }
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, width, height);

      const cx = width / 2;
      const cy = height / 2 + 30;

      // Projection parameters
      const radYaw = (yaw * Math.PI) / 180;
      const radPitch = (pitch * Math.PI) / 180;
      const scale = 220 * zoom;

      // 3D Point to 2D Screen Projection
      const project = (x: number, y: number, z: number): [number, number] => {
        // Rotate around Y
        const x1 = x * Math.cos(radYaw) - z * Math.sin(radYaw);
        const z1 = x * Math.sin(radYaw) + z * Math.cos(radYaw);
        // Rotate around X
        const y2 = y * Math.cos(radPitch) - z1 * Math.sin(radPitch);
        const z2 = y * Math.sin(radPitch) + z1 * Math.cos(radPitch);
        // Isometric perspective projection
        const depthFactor = 800 / (800 + z2);
        return [cx + x1 * scale * depthFactor, cy - y2 * scale * depthFactor];
      };

      // 1. Draw Indore Topography Grid (Elevation 545m to 565m)
      const gridSize = 16;
      const step = 2.0 / gridSize;

      // Elevation field with natural Indore depression around Kahn river
      const getElevation = (gx: number, gz: number) => {
        const distToRiver = Math.abs(gx - 0.2 * Math.sin(gz * 2.5));
        const riverTrench = -0.18 * Math.exp(-distToRiver * 6.0);
        const lakeBasin = -0.15 * Math.exp(-((gx + 0.5) ** 2 + (gz + 0.6) ** 2) * 8.0);
        const hills = 0.12 * Math.sin(gx * 2.0) * Math.cos(gz * 2.0);
        return riverTrench + lakeBasin + hills;
      };

      // Draw Topography Surface Triangles/Quads
      for (let i = -gridSize / 2; i < gridSize / 2; i++) {
        for (let j = -gridSize / 2; j < gridSize / 2; j++) {
          const x0 = i * step;
          const z0 = j * step;
          const x1 = (i + 1) * step;
          const z1 = (j + 1) * step;

          const y00 = getElevation(x0, z0);
          const y10 = getElevation(x1, z0);
          const y11 = getElevation(x1, z1);
          const y01 = getElevation(x0, z1);

          const p00 = project(x0, y00, z0);
          const p10 = project(x1, y10, z0);
          const p11 = project(x1, y11, z1);
          const p01 = project(x0, y01, z1);

          ctx.beginPath();
          ctx.moveTo(p00[0], p00[1]);
          ctx.lineTo(p10[0], p10[1]);
          ctx.lineTo(p11[0], p11[1]);
          ctx.lineTo(p01[0], p01[1]);
          ctx.closePath();

          // Terrain coloring based on elevation
          const avgElev = (y00 + y10 + y11 + y01) / 4;
          if (avgElev < -0.1) {
            ctx.fillStyle = theme === 'dark' ? '#1e293b' : '#cbd5e1'; // Riverbed
          } else if (avgElev < 0.05) {
            ctx.fillStyle = theme === 'dark' ? '#1e3a5f' : '#94a3b8'; // Low basin
          } else {
            ctx.fillStyle = theme === 'dark' ? '#0f3460' : '#64748b'; // High ridge
          }
          ctx.fill();

          ctx.strokeStyle = theme === 'dark' ? 'rgba(56, 189, 248, 0.12)' : 'rgba(100, 116, 139, 0.2)';
          ctx.lineWidth = 0.6;
          ctx.stroke();
        }
      }

      // 2. Animated Water Level Simulation
      // Water level increases with rainfall and timeline scrubber
      const rainFactor = rainfallInput / 60.0;
      const timeFactor = Math.sin((timeStep / 180) * Math.PI); // Rises then recedes
      const mitigationDiscount = mitigationMode === 'mitigated' ? 0.45 : 1.0;
      const floodHeight = -0.05 + 0.18 * rainFactor * timeFactor * mitigationDiscount;

      // Draw Water Plane Quads where terrain is submerged
      for (let i = -gridSize / 2; i < gridSize / 2; i++) {
        for (let j = -gridSize / 2; j < gridSize / 2; j++) {
          const x0 = i * step;
          const z0 = j * step;
          const x1 = (i + 1) * step;
          const z1 = (j + 1) * step;

          const yAvg = (getElevation(x0, z0) + getElevation(x1, z1)) / 2;

          if (floodHeight > yAvg) {
            const p00 = project(x0, floodHeight, z0);
            const p10 = project(x1, floodHeight, z0);
            const p11 = project(x1, floodHeight, z1);
            const p01 = project(x0, floodHeight, z1);

            ctx.beginPath();
            ctx.moveTo(p00[0], p00[1]);
            ctx.lineTo(p10[0], p10[1]);
            ctx.lineTo(p11[0], p11[1]);
            ctx.lineTo(p01[0], p01[1]);
            ctx.closePath();

            // Water depth color (shallow teal -> deep dark azure)
            const depth = floodHeight - yAvg;
            if (depth > 0.1) {
              ctx.fillStyle = 'rgba(239, 68, 68, 0.75)'; // Critical danger inundation
            } else if (depth > 0.04) {
              ctx.fillStyle = 'rgba(249, 115, 22, 0.65)'; // High hazard
            } else {
              ctx.fillStyle = 'rgba(14, 165, 233, 0.6)'; // Moderate surface water
            }
            ctx.fill();
          }
        }
      }

      // 3. Draw 3D Landmarks & Buildings
      const landmarks = [
        { name: 'Rajwada Palace', x: -0.1, z: 0.1, h: 0.22, color: '#f59e0b' },
        { name: 'Vijay Nagar Hub', x: 0.5, z: 0.5, h: 0.32, color: '#38bdf8' },
        { name: 'Palasia Square', x: 0.2, z: 0.2, h: 0.26, color: '#818cf8' },
        { name: 'Bhanwarkuan DAVV', x: -0.4, z: -0.2, h: 0.2, color: '#fb7185' },
        { name: 'Bilawali Lake Sluice', x: -0.5, z: -0.6, h: 0.12, color: '#10b981' },
      ];

      landmarks.forEach((b) => {
        const baseElev = getElevation(b.x, b.z);
        const pBase = project(b.x, baseElev, b.z);
        const pTop = project(b.x, baseElev + b.h, b.z);

        // Building column
        ctx.beginPath();
        ctx.moveTo(pBase[0] - 8, pBase[1]);
        ctx.lineTo(pTop[0] - 8, pTop[1]);
        ctx.lineTo(pTop[0] + 8, pTop[1]);
        ctx.lineTo(pBase[0] + 8, pBase[1]);
        ctx.closePath();
        ctx.fillStyle = b.color;
        ctx.fill();
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 1.2;
        ctx.stroke();

        // Building top roof
        ctx.beginPath();
        ctx.arc(pTop[0], pTop[1], 4, 0, Math.PI * 2);
        ctx.fillStyle = '#ffffff';
        ctx.fill();

        // Label
        ctx.font = 'bold 11px system-ui';
        ctx.fillStyle = theme === 'dark' ? '#f8fafc' : '#0f172a';
        ctx.textAlign = 'center';
        ctx.fillText(b.name, pTop[0], pTop[1] - 8);
      });

      // 4. Draw Active IoT Sensors Pins with Pulsing Beacons
      sensors.slice(0, 6).forEach((s, idx) => {
        const sx = ((s.longitude - 75.8577) / 0.05) * 0.4;
        const sz = ((s.latitude - 22.7196) / 0.05) * 0.4;
        const sy = getElevation(sx, sz);
        const p = project(sx, sy + 0.05, sz);

        const isCrit = s.current_water_level_cm >= s.warning_threshold_cm;

        // Pulsing ring
        const pulse = (Date.now() / 300 + idx) % 3;
        ctx.beginPath();
        ctx.arc(p[0], p[1], 5 + pulse * 4, 0, Math.PI * 2);
        ctx.strokeStyle = isCrit ? 'rgba(239, 68, 68, 0.6)' : 'rgba(56, 189, 248, 0.6)';
        ctx.lineWidth = 1.5;
        ctx.stroke();

        // Center pin
        ctx.beginPath();
        ctx.arc(p[0], p[1], 4, 0, Math.PI * 2);
        ctx.fillStyle = isCrit ? '#ef4444' : '#0284c7';
        ctx.fill();
        ctx.strokeStyle = '#ffffff';
        ctx.stroke();
      });

      // Compass Rose
      const compassP = [width - 50, 50];
      const nVector = [Math.sin(radYaw) * 22, -Math.cos(radYaw) * Math.cos(radPitch) * 22];
      ctx.beginPath();
      ctx.moveTo(compassP[0], compassP[1]);
      ctx.lineTo(compassP[0] + nVector[0], compassP[1] + nVector[1]);
      ctx.strokeStyle = '#ef4444';
      ctx.lineWidth = 3;
      ctx.stroke();
      ctx.font = 'bold 10px monospace';
      ctx.fillStyle = '#ef4444';
      ctx.fillText('N', compassP[0] + nVector[0], compassP[1] + nVector[1] - 4);

      animId = requestAnimationFrame(render);
    };

    render();
    return () => cancelAnimationFrame(animId);
  }, [yaw, pitch, zoom, timeStep, rainfallInput, mitigationMode, theme, sensors]);

  // Mouse drag rotate handlers
  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    isDragging.current = true;
    lastMouse.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDragging.current) return;
    const dx = e.clientX - lastMouse.current.x;
    const dy = e.clientY - lastMouse.current.y;
    setYaw((prev) => prev + dx * 0.5);
    setPitch((prev) => Math.max(10, Math.min(80, prev - dy * 0.5)));
    lastMouse.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseUp = () => {
    isDragging.current = false;
  };

  const handleWheel = (e: React.WheelEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    setZoom((prev) => Math.max(0.6, Math.min(2.5, prev - e.deltaY * 0.001)));
  };

  return (
    <div className="flex flex-col gap-4 p-4 lg:p-6 max-w-7xl mx-auto">
      
      {/* Header & Controls Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-bold tracking-tight">Indore 3D Digital Twin Engine</h2>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-sky-500/10 text-sky-500 border border-sky-500/20">
              WebGL Cesium-Compatible
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Interactive hydrological terrain, Kahn River stormwater outfall & dynamic inundation simulation.
          </p>
        </div>

        {/* Camera Preset Buttons */}
        <div className="flex items-center gap-1.5 p-1 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-semibold">
          <button
            onClick={() => applyPreset('aerial')}
            className={`px-3 py-1.5 rounded-lg transition-colors ${cameraPreset === 'aerial' ? 'bg-white dark:bg-slate-700 shadow-sm text-sky-600 dark:text-sky-400' : 'text-slate-600 dark:text-slate-400'}`}
          >
            Aerial View
          </button>
          <button
            onClick={() => applyPreset('rajwada')}
            className={`px-3 py-1.5 rounded-lg transition-colors ${cameraPreset === 'rajwada' ? 'bg-white dark:bg-slate-700 shadow-sm text-sky-600 dark:text-sky-400' : 'text-slate-600 dark:text-slate-400'}`}
          >
            Rajwada Basin
          </button>
          <button
            onClick={() => applyPreset('kahn')}
            className={`px-3 py-1.5 rounded-lg transition-colors ${cameraPreset === 'kahn' ? 'bg-white dark:bg-slate-700 shadow-sm text-sky-600 dark:text-sky-400' : 'text-slate-600 dark:text-slate-400'}`}
          >
            Kahn River Channel
          </button>
          <button
            onClick={() => applyPreset('vijay')}
            className={`px-3 py-1.5 rounded-lg transition-colors ${cameraPreset === 'vijay' ? 'bg-white dark:bg-slate-700 shadow-sm text-sky-600 dark:text-sky-400' : 'text-slate-600 dark:text-slate-400'}`}
          >
            Vijay Nagar Corridor
          </button>
        </div>
      </div>

      {/* Main 3D Canvas Viewport */}
      <div className="relative rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 shadow-xl bg-slate-950">
        <canvas
          ref={canvasRef}
          width={1020}
          height={560}
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseUp}
          onWheel={handleWheel}
          className="w-full h-[520px] cursor-grab active:cursor-grabbing block"
        />

        {/* Floating Scrubber HUD Overlay */}
        <div className="absolute bottom-4 left-4 right-4 flex flex-wrap items-center justify-between gap-4 p-3 rounded-xl bg-slate-900/85 backdrop-blur-md border border-slate-700/60 text-white shadow-2xl">
          
          {/* Play/Pause & Time Scrubber */}
          <div className="flex items-center gap-3 flex-1 min-w-[280px]">
            <button
              onClick={() => setIsPlaying(!isPlaying)}
              className="p-2 rounded-lg bg-sky-600 hover:bg-sky-500 text-white transition-colors"
              title={isPlaying ? 'Pause Simulation' : 'Play Simulation'}
            >
              {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            </button>

            <button
              onClick={() => setTimeStep(0)}
              className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
              title="Reset to T=0"
            >
              <RotateCcw className="w-4 h-4" />
            </button>

            <div className="flex-1 flex flex-col gap-1">
              <div className="flex justify-between text-xs font-mono">
                <span>Timeline Horizon:</span>
                <span className="text-sky-400 font-bold">+{timeStep} min (T+{(timeStep / 60).toFixed(1)}h)</span>
              </div>
              <input
                type="range"
                min={0}
                max={180}
                step={5}
                value={timeStep}
                onChange={(e) => setTimeStep(Number(e.target.value))}
                className="w-full accent-sky-500 cursor-pointer h-1.5 rounded-lg bg-slate-700"
              />
            </div>
          </div>

          {/* Mitigation Mode Comparison Toggle */}
          <div className="flex items-center gap-2 border-l border-slate-700 pl-4">
            <span className="text-xs text-slate-400 font-medium hidden sm:inline">Mitigation:</span>
            <div className="flex items-center p-0.5 rounded-lg bg-slate-800 text-xs font-semibold">
              <button
                onClick={() => setMitigationMode('mitigated')}
                className={`px-2.5 py-1 rounded-md transition-colors ${mitigationMode === 'mitigated' ? 'bg-emerald-600 text-white shadow-sm' : 'text-slate-400'}`}
              >
                Pumps Active (Mitigated)
              </button>
              <button
                onClick={() => setMitigationMode('unmitigated')}
                className={`px-2.5 py-1 rounded-md transition-colors ${mitigationMode === 'unmitigated' ? 'bg-rose-600 text-white shadow-sm' : 'text-slate-400'}`}
              >
                Zero Pumps (Unmitigated)
              </button>
            </div>
          </div>

        </div>

        {/* Live Elevation Info Overlay Badge */}
        <div className="absolute top-4 left-4 p-2.5 rounded-xl bg-slate-900/85 backdrop-blur-md border border-slate-700/60 text-white text-xs font-mono space-y-1">
          <div className="flex items-center gap-2">
            <Waves className="w-3.5 h-3.5 text-sky-400" />
            <span>Rainfall Rate: <strong>{rainfallInput.toFixed(1)} mm/h</strong></span>
          </div>
          <div className="flex items-center gap-2">
            <Layers className="w-3.5 h-3.5 text-emerald-400" />
            <span>Basin Depression: <strong>546m AMSL (Rajwada)</strong></span>
          </div>
          <div className="text-[10px] text-slate-400">Drag to Orbit | Scroll to Zoom</div>
        </div>

      </div>

      {/* Scenario Parameters Card */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        
        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Simulate Cloudburst Inflow</h4>
          <div className="space-y-3">
            <div className="flex justify-between text-xs font-semibold">
              <span>Precipitation:</span>
              <span className="text-sky-500">{rainfallInput} mm/h</span>
            </div>
            <input
              type="range"
              min={15}
              max={130}
              step={5}
              value={rainfallInput}
              onChange={(e) => setRainfallInput(Number(e.target.value))}
              className="w-full accent-sky-500 cursor-pointer h-1.5 rounded-lg bg-slate-200 dark:bg-slate-800"
            />
            <button
              onClick={() => triggerScenario('Custom Cloudburst Twin Test', rainfallInput)}
              className="w-full py-1.5 text-xs font-bold rounded-lg bg-sky-600 hover:bg-sky-500 text-white transition-colors"
            >
              Sync Simulation to Whole City
            </button>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Drainage Outfall Conveyance</h4>
          <div className="space-y-2 text-xs">
            <div className="flex justify-between">
              <span className="text-slate-500">Kahn River Outfall:</span>
              <span className="font-semibold">45.0 m³/s rated</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Saraswati Canal Trunk:</span>
              <span className="font-semibold">28.0 m³/s rated</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Bilawali Lake Spillway:</span>
              <span className="font-semibold">30.0 m³/s buffer</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Urban Impervious Cover:</span>
              <span className="font-semibold text-rose-500">82.4% avg</span>
            </div>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Hydrological Impact Summary</h4>
          <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
            {mitigationMode === 'mitigated'
              ? 'Pumps operating at Kahn River and Rajwada basin successfully reduce downstream surface ponding by 55%, preventing bank overtopping into Sarafa Bazaar.'
              : 'CRITICAL ALERT: Without pump operation, surface water ponds to 62cm depth in Rajwada, submerging MG Road and triggering vehicular stalling.'}
          </p>
        </div>

      </div>

    </div>
  );
};
