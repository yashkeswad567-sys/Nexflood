"""
Unit and Integration Tests for Flood-Aware Road Routing Engine.
"""

import unittest
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
from backend.app.routing_engine import (
    calculate_flood_aware_route, find_nearest_junction, haversine_km,
    DISCLAIMER_TEXT, INDORE_JUNCTIONS
)
from backend.app.database import init_db
from backend.app.seed_data import seed_all_data

class TestRoutingEngine(unittest.TestCase):
    
    @classmethod
    def setUpClass(cls):
        init_db()
        seed_all_data()

    def test_haversine_calculation(self):
        # Distance between Rajwada (22.7196, 75.8577) and Vijay Nagar (22.7533, 75.8937)
        dist = haversine_km(22.7196, 75.8577, 22.7533, 75.8937)
        self.assertGreater(dist, 4.0)
        self.assertLess(dist, 7.0)

    def test_nearest_junction_matching(self):
        # Exact Rajwada coordinates should match J_RAJWADA
        node = find_nearest_junction(22.7196, 75.8577)
        self.assertEqual(node, "J_RAJWADA")

    def test_route_calculation_structure(self):
        res = calculate_flood_aware_route(
            origin_lat=22.7196, origin_lng=75.8577, # Rajwada
            dest_lat=22.7533, dest_lng=75.8937,     # Vijay Nagar
            travel_mode="vehicle"
        )
        self.assertIn("primary_route", res)
        primary = res["primary_route"]
        self.assertGreater(primary["distance_km"], 0.0)
        self.assertGreater(primary["estimated_minutes"], 0.0)
        self.assertIn("path_coordinates", primary)
        self.assertGreater(len(primary["path_coordinates"]), 1)
        self.assertIn("turn_by_turn", primary)
        
        # Mandatory disclaimer check
        self.assertEqual(res["disclaimer"], DISCLAIMER_TEXT)
        self.assertIn("EXPERIMENTAL ROUTING ADVISORY", res["disclaimer"])

if __name__ == "__main__":
    unittest.main()
