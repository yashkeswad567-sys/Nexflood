"""
Unit and Integration Tests for Incident Lifecycle and Emergency SOS Dispatch.
"""

import unittest
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
from backend.app.database import get_connection, init_db
from backend.app.seed_data import seed_all_data

class TestIncidents(unittest.TestCase):
    
    @classmethod
    def setUpClass(cls):
        init_db()
        seed_all_data()

    def test_incident_query_and_counts(self):
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) as cnt FROM incidents")
        count = cursor.fetchone()["cnt"]
        conn.close()
        self.assertGreater(count, 0)

    def test_incident_status_progression(self):
        conn = get_connection()
        cursor = conn.cursor()
        # Create test incident
        cursor.execute("""
            INSERT INTO incidents (
                id, tracking_code, reported_by_name, phone, incident_type,
                latitude, longitude, landmark_address, severity, people_stranded,
                medical_emergency, status, created_at, updated_at
            ) VALUES ('TEST_INC_01', 'IND-TST-999', 'Test Citizen', '9826000000', 'EMERGENCY_SOS',
                      22.7196, 75.8577, 'Rajwada', 'CRITICAL', 2, 1, 'REPORTED', '2026-11-01', '2026-11-01')
        """)
        conn.commit()
        
        # Dispatch
        cursor.execute("UPDATE incidents SET status = 'DISPATCHED', assigned_unit = 'Palasia Boat 1' WHERE id = 'TEST_INC_01'")
        conn.commit()
        
        cursor.execute("SELECT status, assigned_unit FROM incidents WHERE id = 'TEST_INC_01'")
        row = cursor.fetchone()
        self.assertEqual(row["status"], "DISPATCHED")
        self.assertEqual(row["assigned_unit"], "Palasia Boat 1")
        
        # Advance to RESOLVED
        cursor.execute("UPDATE incidents SET status = 'RESOLVED' WHERE id = 'TEST_INC_01'")
        conn.commit()
        cursor.execute("SELECT status FROM incidents WHERE id = 'TEST_INC_01'")
        self.assertEqual(cursor.fetchone()["status"], "RESOLVED")
        
        # Cleanup
        cursor.execute("DELETE FROM incidents WHERE id = 'TEST_INC_01'")
        conn.commit()
        conn.close()

if __name__ == "__main__":
    unittest.main()
