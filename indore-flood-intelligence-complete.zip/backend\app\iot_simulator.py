"""
IoT Telemetry Ingestion, Validation & Simulator Engine for Indore Flood Intelligence (IFI).
Handles ESP32 edge telemetry ingestion, range and timestamp validation,
sensor stale status detection, real-time telemetry generation,
and intelligent pump operation recommendation calculations.
"""

import math
import random
import time
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional
from .database import get_connection, _lock, log_audit

def validate_telemetry_payload(payload: Dict[str, Any]) -> Tuple[bool, str]:
    """
    Validates ESP32 telemetry inputs according to hardware and physical constraints.
    """
    device_id = payload.get("device_id")
    if not device_id or not isinstance(device_id, str):
        return False, "Missing or invalid device_id."
        
    water_level = payload.get("water_level_cm")
    if water_level is None or not (0.0 <= float(water_level) <= 500.0):
        return False, f"Water level {water_level} cm is out of physical sensor bounds (0.0 - 500.0 cm)."
        
    battery_v = payload.get("battery_voltage")
    if battery_v is not None and not (2.5 <= float(battery_v) <= 4.5):
        return False, f"Battery voltage {battery_v} V is out of standard Li-ion bounds (2.5 - 4.5 V)."
        
    ts = payload.get("timestamp")
    if ts:
        now_ts = time.time()
        # Allow 5 mins future clock skew, reject if older than 24 hours
        if float(ts) > now_ts + 300:
            return False, "Timestamp is in the future."
        if float(ts) < now_ts - 86400:
            return False, "Timestamp is older than 24 hours."
            
    return True, "Valid"

def ingest_telemetry(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Ingests and stores ESP32 sensor telemetry after strict validation.
    """
    is_valid, err_msg = validate_telemetry_payload(payload)
    if not is_valid:
        return {"status": "REJECTED", "reason": err_msg}
        
    device_id = payload["device_id"]
    water_level_cm = float(payload["water_level_cm"])
    flow_rate_m3s = float(payload.get("flow_rate_m3s", 0.0))
    battery_v = float(payload.get("battery_voltage", 3.8))
    now_iso = datetime.utcnow().isoformat()
    
    with _lock:
        conn = get_connection()
        cursor = conn.cursor()
        
        # Check if device exists
        cursor.execute("SELECT id, warning_threshold_cm, critical_threshold_cm, current_water_level_cm FROM sensor_devices WHERE id = ?", (device_id,))
        device = cursor.fetchone()
        
        if not device:
            conn.close()
            return {"status": "ERROR", "reason": f"Unknown sensor device: {device_id}"}
            
        # Check rate of change anomaly (>80 cm jump in single telemetry)
        prev_level = device["current_water_level_cm"]
        is_anomaly = abs(water_level_cm - prev_level) > 80.0
        
        # Calculate battery percentage from Li-ion curve (3.0V = 0%, 4.2V = 100%)
        battery_pct = max(0.0, min(100.0, round(((battery_v - 3.0) / 1.2) * 100.0, 1)))
        
        # Update device current state
        cursor.execute("""
            UPDATE sensor_devices
            SET current_water_level_cm = ?,
                current_flow_rate_m3s = ?,
                battery_pct = ?,
                last_heartbeat = ?
            WHERE id = ?
        """, (water_level_cm, flow_rate_m3s, battery_pct, now_iso, device_id))
        
        # Insert telemetry record
        cursor.execute("""
            INSERT INTO sensor_telemetry (
                device_id, timestamp, water_level_cm, flow_rate_m3s, battery_v, is_valid
            ) VALUES (?, ?, ?, ?, ?, ?)
        """, (device_id, now_iso, water_level_cm, flow_rate_m3s, battery_v, 0 if is_anomaly else 1))
        
        conn.commit()
        conn.close()
        
    # Re-evaluate pump recommendations for this sensor's catchment
    evaluate_pump_recommendations()
    
    return {
        "status": "ACCEPTED",
        "device_id": device_id,
        "water_level_cm": water_level_cm,
        "is_anomaly": is_anomaly,
        "recorded_at": now_iso
    }

def evaluate_pump_recommendations() -> List[Dict[str, Any]]:
    """
    Evaluates current inflows and water levels to compute pump operation recommendations.
    Advisory rule: If catchment inflow > 75% canal conveyance or sensor > warning threshold,
    recommend staging secondary pump or increasing RPM.
    """
    now_iso = datetime.utcnow().isoformat()
    recommendations_generated = []
    
    with _lock:
        conn = get_connection()
        cursor = conn.cursor()
        
        # Fetch assets and associated zones
        cursor.execute("""
            SELECT a.*, z.current_water_depth_cm, z.drainage_capacity_m3s, z.name as zone_name
            FROM drainage_assets a
            JOIN catchment_zones z ON a.zone_id = z.id
        """)
        assets = [dict(r) for r in cursor.fetchall()]
        
        for asset in assets:
            water_depth = asset["current_water_depth_cm"]
            capacity = asset["rated_capacity_m3s"]
            status = asset["current_status"]
            
            # Condition 1: Critical waterlogging (>40cm) and pump is OPERATIONAL but not RUNNING
            if water_depth >= 38.0 and status == "OPERATIONAL":
                rec_id = f"REC_{asset['id']}_{int(time.time()) % 10000}"
                rationale = (
                    f"Water depth in {asset['zone_name']} reached {water_depth:.1f} cm. "
                    f"Engage {asset['name']} (rated {capacity:.1f} m³/s) to relieve urban basin pressure."
                )
                cursor.execute("""
                    INSERT OR REPLACE INTO pump_recommendations (
                        id, asset_id, zone_id, recommended_action, urgency, rationale,
                        inflow_rate_m3s, status, created_at
                    ) VALUES (?, ?, ?, 'START_PUMP', 'URGENT', ?, ?, 'PENDING', ?)
                """, (rec_id, asset["id"], asset["zone_id"], rationale, round(water_depth * 0.6, 2), now_iso))
                recommendations_generated.append({"asset_id": asset["id"], "action": "START_PUMP", "rationale": rationale})
                
            # Condition 2: Water receding (<15cm) and pump is RUNNING
            elif water_depth < 15.0 and status == "RUNNING":
                rec_id = f"REC_{asset['id']}_{int(time.time()) % 10000}"
                rationale = f"Water depth normalized to {water_depth:.1f} cm. Disengage {asset['name']} to conserve power."
                cursor.execute("""
                    INSERT OR REPLACE INTO pump_recommendations (
                        id, asset_id, zone_id, recommended_action, urgency, rationale,
                        inflow_rate_m3s, status, created_at
                    ) VALUES (?, ?, ?, 'STOP_PUMP', 'ADVISORY', ?, ?, 'PENDING', ?)
                """, (rec_id, asset["id"], asset["zone_id"], rationale, round(water_depth * 0.2, 2), now_iso))
                recommendations_generated.append({"asset_id": asset["id"], "action": "STOP_PUMP", "rationale": rationale})
                
        conn.commit()
        conn.close()
        
    return recommendations_generated

def simulate_sensor_tick(rainfall_intensity_mmh: float):
    """
    Generates dynamic fluctuations for all sensors based on simulated rainfall.
    """
    with _lock:
        conn = get_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT id, zone_id, current_water_level_cm FROM sensor_devices")
        devices = [dict(r) for r in cursor.fetchall()]
        
        now_iso = datetime.utcnow().isoformat()
        
        for dev in devices:
            base_level = dev["current_water_level_cm"]
            noise = random.uniform(-0.8, 1.2)
            # Higher rain increases rate of rise
            rain_delta = (rainfall_intensity_mmh / 60.0) * 0.4
            new_level = round(max(2.0, min(140.0, base_level + noise + rain_delta)), 1)
            new_flow = round(max(0.5, new_level * 0.18 + random.uniform(-0.3, 0.3)), 2)
            
            cursor.execute("""
                UPDATE sensor_devices
                SET current_water_level_cm = ?,
                    current_flow_rate_m3s = ?,
                    last_heartbeat = ?
                WHERE id = ?
            """, (new_level, new_flow, now_iso, dev["id"]))
            
        conn.commit()
        conn.close()
