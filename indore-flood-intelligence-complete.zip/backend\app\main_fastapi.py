"""
FastAPI Production Application for Indore Flood Intelligence (IFI).
Provides Swagger / OpenAPI interactive documentation at /docs and /redoc.
"""

from fastapi import FastAPI, HTTPException, Depends, Header
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from datetime import datetime

from .database import get_connection, init_db
from .seed_data import seed_all_data
from .auth import authenticate_user, create_access_token, create_demo_user, verify_token
from .flood_engine import run_flood_simulation
from .routing_engine import calculate_flood_aware_route
from .iot_simulator import ingest_telemetry, evaluate_pump_recommendations

app = FastAPI(
    title="Indore Flood Intelligence (IFI) API",
    description="AI-Powered Urban Drainage & Flash Flood Predictive Management System for Indore Municipal Corporation",
    version="1.2.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
def on_startup():
    init_db()
    seed_all_data()

# ---------------- Pydantic Models ----------------
class LoginRequest(BaseModel):
    email: str
    password: str

class DemoSessionRequest(BaseModel):
    role: str = "citizen"

class SimulationRequest(BaseModel):
    scenario_name: str = "Cloudburst Scenario"
    rainfall_rate_mmh: float = 85.0
    soil_moisture_pct: float = 75.0

class RouteRequest(BaseModel):
    origin: Dict[str, float]
    destination: Dict[str, float]
    travel_mode: str = "vehicle"

class SOSRequest(BaseModel):
    citizen_name: str
    phone: str
    location: Dict[str, Any]
    people_stranded: int = 1
    has_medical_emergency: bool = False
    severity: str = "CRITICAL"
    notes: Optional[str] = None

class StatusUpdateRequest(BaseModel):
    status: str
    notes: Optional[str] = None

class TelemetryRequest(BaseModel):
    device_id: str
    water_level_cm: float
    flow_rate_m3s: Optional[float] = 0.0
    battery_voltage: Optional[float] = 3.8
    timestamp: Optional[float] = None

# ---------------- Endpoints ----------------
@app.get("/health")
def health_check():
    return {"status": "healthy", "service": "Indore Flood Intelligence", "version": "1.2.0"}

@app.post("/api/v1/auth/login")
def login(req: LoginRequest):
    user = authenticate_user(req.email, req.password)
    if not user:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    token = create_access_token(user["id"], user["email"], user["role"], user["full_name"], user.get("organization", "Indore"))
    return {"access_token": token, "token_type": "bearer", "user": user}

@app.post("/api/v1/auth/demo-session")
def demo_session(req: DemoSessionRequest):
    return create_demo_user(req.role)

@app.get("/api/v1/flood/status")
def get_flood_status():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM catchment_zones")
    zones = [dict(r) for r in cursor.fetchall()]
    conn.close()
    return {"zones": zones, "timestamp": datetime.utcnow().isoformat()}

@app.post("/api/v1/flood/simulate")
def simulate_flood(req: SimulationRequest):
    return run_flood_simulation(req.scenario_name, req.rainfall_rate_mmh, req.soil_moisture_pct)

@app.post("/api/v1/routing/calculate")
def calculate_route(req: RouteRequest):
    orig = req.origin
    dest = req.destination
    return calculate_flood_aware_route(orig.get("lat", 22.7196), orig.get("lng", 75.8577), dest.get("lat", 22.7533), dest.get("lng", 75.8937), travel_mode=req.travel_mode)

@app.post("/api/v1/iot/telemetry")
def submit_telemetry(req: TelemetryRequest):
    res = ingest_telemetry(req.dict())
    if res.get("status") != "ACCEPTED":
        raise HTTPException(status_code=422, detail=res)
    return res
