export type Role = 'citizen' | 'municipal' | 'field_engineer' | 'firefighter';

export type HazardLevel = 'LOW' | 'MODERATE' | 'HIGH' | 'CRITICAL';

export interface User {
  id: string;
  email: string;
  name: string;
  role: Role;
  organization?: string;
  phone?: string;
}

export interface CatchmentZone {
  id: string;
  name: string;
  description: string;
  centroid_lat: number;
  centroid_lng: number;
  elevation_m: number;
  current_hazard_level: HazardLevel;
  current_water_depth_cm: number;
  soil_saturation_pct: number;
  polygon_geojson: [number, number][];
  forecast_1h?: ForecastHorizon;
  forecast_2h?: ForecastHorizon;
  forecast_3h?: ForecastHorizon;
}

export interface ForecastHorizon {
  zone_id: string;
  name: string;
  hazard_level: HazardLevel;
  water_depth_cm: number;
  depth_ci_lower: number;
  depth_ci_upper: number;
  confidence_pct: number;
  inflow_m3s: number;
  drainage_capacity_util_pct: number;
  soil_saturation_pct: number;
}

export interface SensorDevice {
  id: string;
  zone_id: string;
  zone_name?: string;
  name: string;
  sensor_type: string;
  latitude: number;
  longitude: number;
  warning_threshold_cm: number;
  critical_threshold_cm: number;
  is_active: number | boolean;
  battery_pct: number;
  current_water_level_cm: number;
  current_flow_rate_m3s: number;
  last_heartbeat: string;
}

export interface DrainageAsset {
  id: string;
  zone_id: string;
  zone_name?: string;
  name: string;
  asset_type: 'stormwater_pump' | 'sluice_gate' | 'culvert' | 'retention_basin';
  latitude: number;
  longitude: number;
  rated_capacity_m3s: number;
  current_status: 'OPERATIONAL' | 'RUNNING' | 'DEGRADED' | 'FAULT';
  silt_blockage_pct: number;
  current_water_depth_cm?: number;
  last_inspected_at: string;
}

export type IncidentSeverity = 'LOW' | 'MODERATE' | 'HIGH' | 'CRITICAL';
export type IncidentStatus = 'REPORTED' | 'VERIFIED' | 'DISPATCHED' | 'ON_SCENE' | 'EVACUATING' | 'RESOLVED';
export type IncidentType = 'EMERGENCY_SOS' | 'WATERLOGGING_REPORT' | 'DRAIN_OVERFLOW' | 'ROAD_BLOCKED';

export interface Incident {
  id: string;
  tracking_code: string;
  reported_by_name: string;
  phone?: string;
  incident_type: IncidentType;
  latitude: number;
  longitude: number;
  landmark_address: string;
  severity: IncidentSeverity;
  people_stranded: number;
  medical_emergency: number | boolean;
  status: IncidentStatus;
  assigned_unit?: string;
  assigned_personnel_id?: string;
  notes?: string;
  resolution_notes?: string;
  created_at: string;
  updated_at: string;
}

export interface WorkOrder {
  id: string;
  asset_id: string;
  asset_name?: string;
  asset_type?: string;
  assigned_to?: string;
  title: string;
  description: string;
  priority: 'ROUTINE' | 'URGENT' | 'EMERGENCY';
  status: 'PENDING' | 'IN_PROGRESS' | 'COMPLETED';
  initial_silt_pct?: number;
  final_silt_pct?: number;
  inspection_notes?: string;
  latitude?: number;
  longitude?: number;
  created_at: string;
  completed_at?: string;
}

export interface RoadSegment {
  id: string;
  name: string;
  zone_id: string;
  start_lat: number;
  start_lng: number;
  end_lat: number;
  end_lng: number;
  length_km: number;
  base_speed_kmh: number;
  elevation_m: number;
  current_water_depth_cm: number;
  is_blocked: number | boolean;
}

export interface RouteOption {
  route_id: string;
  name: string;
  distance_km: number;
  estimated_minutes: number;
  max_flood_depth_cm: number;
  hazard_risk_score: number;
  is_emergency_clearance_required?: boolean;
  warning?: string;
  path_coordinates: [number, number][];
  turn_by_turn: string[];
}

export interface RouteResponse {
  origin: { lat: number; lng: number; nearest_node?: string };
  destination: { lat: number; lng: number; nearest_node?: string };
  primary_route: RouteOption;
  alternative_routes: RouteOption[];
  disclaimer: string;
}

export interface PumpRecommendation {
  id: string;
  asset_id: string;
  asset_name?: string;
  zone_id: string;
  zone_name?: string;
  recommended_action: 'START_PUMP' | 'STOP_PUMP' | 'INCREASE_RPM' | 'CLEAR_INLET';
  urgency: 'ADVISORY' | 'URGENT' | 'CRITICAL';
  rationale: string;
  inflow_rate_m3s: number;
  status: 'PENDING' | 'ACCEPTED' | 'OVERRIDDEN';
  operator_override_notes?: string;
  created_at: string;
}

export interface EmergencyShelter {
  id: string;
  name: string;
  latitude: number;
  longitude: number;
  address: string;
  capacity: number;
  current_occupancy: number;
  contact_phone: string;
  facilities: string;
  is_active: number | boolean;
}

export interface AlertNotification {
  id: string;
  title: string;
  severity: IncidentSeverity;
  target_zones: string;
  message: string;
  instructions: string;
  created_at: string;
  expires_at: string;
  is_active: number | boolean;
}

export interface AuditLog {
  id: number;
  user_name: string;
  role: string;
  action: string;
  entity_type: string;
  entity_id: string;
  details: string;
  timestamp: string;
}

export interface FloodStatusSummary {
  scenario_name: string;
  rainfall_rate_mmh: number;
  rainfall_24h_accum_mm: number;
  city_hazard_level: HazardLevel;
  city_max_depth_cm: number;
  zones: CatchmentZone[];
  active_alerts_count: number;
  timestamp: string;
}
