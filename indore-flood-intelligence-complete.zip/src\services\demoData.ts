import {
  CatchmentZone, SensorDevice, DrainageAsset, Incident,
  WorkOrder, RoadSegment, PumpRecommendation, EmergencyShelter,
  AlertNotification, FloodStatusSummary
} from '../types';

export const INITIAL_ZONES: CatchmentZone[] = [
  {
    id: 'zone_rajwada',
    name: 'Rajwada & Sarafa Basin',
    description: 'Historic commercial basin with dense impervious cover. Natural stormwater collection basin near Kahn River.',
    centroid_lat: 22.7196,
    centroid_lng: 75.8577,
    elevation_m: 546.0,
    current_hazard_level: 'HIGH',
    current_water_depth_cm: 42.5,
    soil_saturation_pct: 84.0,
    polygon_geojson: [
      [22.7150, 75.8520], [22.7250, 75.8520], [22.7260, 75.8640],
      [22.7160, 75.8650], [22.7150, 75.8520]
    ],
    forecast_1h: {
      zone_id: 'zone_rajwada',
      name: 'Rajwada Basin',
      hazard_level: 'CRITICAL',
      water_depth_cm: 54.2,
      depth_ci_lower: 48.0,
      depth_ci_upper: 60.5,
      confidence_pct: 88.5,
      inflow_m3s: 48.2,
      drainage_capacity_util_pct: 150.6,
      soil_saturation_pct: 92.0
    },
    forecast_2h: {
      zone_id: 'zone_rajwada',
      name: 'Rajwada Basin',
      hazard_level: 'CRITICAL',
      water_depth_cm: 61.0,
      depth_ci_lower: 52.0,
      depth_ci_upper: 70.0,
      confidence_pct: 82.0,
      inflow_m3s: 42.0,
      drainage_capacity_util_pct: 131.2,
      soil_saturation_pct: 98.0
    },
    forecast_3h: {
      zone_id: 'zone_rajwada',
      name: 'Rajwada Basin',
      hazard_level: 'HIGH',
      water_depth_cm: 46.5,
      depth_ci_lower: 38.0,
      depth_ci_upper: 55.0,
      confidence_pct: 76.0,
      inflow_m3s: 28.0,
      drainage_capacity_util_pct: 87.5,
      soil_saturation_pct: 94.0
    }
  },
  {
    id: 'zone_vijay_nagar',
    name: 'Vijay Nagar & AB Road',
    description: 'Major arterial corridor and corporate sector. Surface water accumulates at lower vehicular underpasses.',
    centroid_lat: 22.7533,
    centroid_lng: 75.8937,
    elevation_m: 558.0,
    current_hazard_level: 'MODERATE',
    current_water_depth_cm: 18.0,
    soil_saturation_pct: 68.0,
    polygon_geojson: [
      [22.7440, 75.8820], [22.7630, 75.8840], [22.7650, 75.9040],
      [22.7450, 75.9020], [22.7440, 75.8820]
    ]
  },
  {
    id: 'zone_palasia',
    name: 'Palasia & Greater Kailash',
    description: 'High-density residential and retail district. Intersects secondary stormwater trunks.',
    centroid_lat: 22.7244,
    centroid_lng: 75.8839,
    elevation_m: 552.0,
    current_hazard_level: 'LOW',
    current_water_depth_cm: 12.0,
    soil_saturation_pct: 56.0,
    polygon_geojson: [
      [22.7180, 75.8740], [22.7310, 75.8750], [22.7320, 75.8940],
      [22.7190, 75.8930], [22.7180, 75.8740]
    ]
  },
  {
    id: 'zone_bhanwarkuan',
    name: 'Bhanwarkuan & DAVV University',
    description: 'Educational corridor. Natural topographic depression along Khandwa Road with heavy runoff from western ridge.',
    centroid_lat: 22.6926,
    centroid_lng: 75.8676,
    elevation_m: 548.0,
    current_hazard_level: 'HIGH',
    current_water_depth_cm: 38.6,
    soil_saturation_pct: 82.0,
    polygon_geojson: [
      [22.6840, 75.8570], [22.7020, 75.8580], [22.7030, 75.8780],
      [22.6850, 75.8770], [22.6840, 75.8570]
    ]
  },
  {
    id: 'zone_chhavani',
    name: 'Chhavani & Siyaganj Wholesale',
    description: 'Wholesale markets adjacent to Kahn river bank. Fluvial backwater flooding risk during peak discharge.',
    centroid_lat: 22.7121,
    centroid_lng: 75.8643,
    elevation_m: 547.0,
    current_hazard_level: 'HIGH',
    current_water_depth_cm: 44.0,
    soil_saturation_pct: 86.0,
    polygon_geojson: [
      [22.7050, 75.8580], [22.7180, 75.8590], [22.7190, 75.8710],
      [22.7060, 75.8700], [22.7050, 75.8580]
    ]
  },
  {
    id: 'zone_annapurna',
    name: 'Annapurna & West Indore',
    description: 'Residential sector with established lateral storm conduits draining towards Saraswati river.',
    centroid_lat: 22.7012,
    centroid_lng: 75.8398,
    elevation_m: 554.0,
    current_hazard_level: 'LOW',
    current_water_depth_cm: 10.0,
    soil_saturation_pct: 52.0,
    polygon_geojson: [
      [22.6920, 75.8290], [22.7110, 75.8300], [22.7120, 75.8490],
      [22.6930, 75.8480], [22.6920, 75.8290]
    ]
  },
  {
    id: 'zone_sukhlia',
    name: 'Sukhlia & MR 10 Northern Sector',
    description: 'Modern development sector featuring high elevation and broad roadside drainage swales.',
    centroid_lat: 22.7621,
    centroid_lng: 75.8710,
    elevation_m: 560.0,
    current_hazard_level: 'LOW',
    current_water_depth_cm: 8.0,
    soil_saturation_pct: 48.0,
    polygon_geojson: [
      [22.7530, 75.8590], [22.7720, 75.8600], [22.7730, 75.8820],
      [22.7540, 75.8810], [22.7530, 75.8590]
    ]
  },
  {
    id: 'zone_regional_park',
    name: 'Pipliyapala & Bilawali Retention Lakes',
    description: 'Primary urban stormwater retention waterbodies buffering flood flows prior to Kahn river outfall.',
    centroid_lat: 22.6789,
    centroid_lng: 75.8540,
    elevation_m: 545.0,
    current_hazard_level: 'MODERATE',
    current_water_depth_cm: 24.0,
    soil_saturation_pct: 70.0,
    polygon_geojson: [
      [22.6680, 75.8420], [22.6900, 75.8440], [22.6910, 75.8660],
      [22.6690, 75.8640], [22.6680, 75.8420]
    ]
  }
];

export const INITIAL_SENSORS: SensorDevice[] = [
  { id: 'ESP32_SN_001', zone_id: 'zone_rajwada', zone_name: 'Rajwada Basin', name: 'Rajwada Chowk Drain Gauge', sensor_type: 'ultrasonic_depth', latitude: 22.7196, longitude: 75.8577, warning_threshold_cm: 30.0, critical_threshold_cm: 50.0, is_active: 1, battery_pct: 96.0, current_water_level_cm: 42.5, current_flow_rate_m3s: 5.8, last_heartbeat: new Date().toISOString() },
  { id: 'ESP32_SN_002', zone_id: 'zone_rajwada', zone_name: 'Rajwada Basin', name: 'Kahn Outfall Sluice Gauge', sensor_type: 'ultrasonic_depth', latitude: 22.7215, longitude: 75.8595, warning_threshold_cm: 35.0, critical_threshold_cm: 55.0, is_active: 1, battery_pct: 94.0, current_water_level_cm: 48.2, current_flow_rate_m3s: 8.4, last_heartbeat: new Date().toISOString() },
  { id: 'ESP32_SN_003', zone_id: 'zone_vijay_nagar', zone_name: 'Vijay Nagar', name: 'Vijay Nagar Underpass Gauge', sensor_type: 'ultrasonic_depth', latitude: 22.7533, longitude: 75.8937, warning_threshold_cm: 25.0, critical_threshold_cm: 45.0, is_active: 1, battery_pct: 99.0, current_water_level_cm: 18.0, current_flow_rate_m3s: 3.2, last_heartbeat: new Date().toISOString() },
  { id: 'ESP32_SN_004', zone_id: 'zone_palasia', zone_name: 'Palasia', name: 'Palasia Square Storm Culvert', sensor_type: 'ultrasonic_depth', latitude: 22.7244, longitude: 75.8839, warning_threshold_cm: 28.0, critical_threshold_cm: 48.0, is_active: 1, battery_pct: 92.0, current_water_level_cm: 12.4, current_flow_rate_m3s: 2.1, last_heartbeat: new Date().toISOString() },
  { id: 'ESP32_SN_005', zone_id: 'zone_bhanwarkuan', zone_name: 'Bhanwarkuan', name: 'Bhanwarkuan Main Nullah', sensor_type: 'ultrasonic_depth', latitude: 22.6926, longitude: 75.8676, warning_threshold_cm: 30.0, critical_threshold_cm: 50.0, is_active: 1, battery_pct: 88.0, current_water_level_cm: 38.6, current_flow_rate_m3s: 6.7, last_heartbeat: new Date().toISOString() },
  { id: 'ESP32_SN_006', zone_id: 'zone_chhavani', zone_name: 'Chhavani', name: 'Chhavani River Confluence', sensor_type: 'doppler_flow', latitude: 22.7121, longitude: 75.8643, warning_threshold_cm: 35.0, critical_threshold_cm: 55.0, is_active: 1, battery_pct: 95.0, current_water_level_cm: 44.1, current_flow_rate_m3s: 9.2, last_heartbeat: new Date().toISOString() },
  { id: 'ESP32_SN_007', zone_id: 'zone_annapurna', zone_name: 'Annapurna', name: 'Saraswati River Gauge Station', sensor_type: 'doppler_flow', latitude: 22.7012, longitude: 75.8398, warning_threshold_cm: 25.0, critical_threshold_cm: 45.0, is_active: 1, battery_pct: 97.0, current_water_level_cm: 10.5, current_flow_rate_m3s: 1.8, last_heartbeat: new Date().toISOString() },
  { id: 'ESP32_SN_008', zone_id: 'zone_regional_park', zone_name: 'Regional Park', name: 'Pipliyapala Lake Sluice Weirs', sensor_type: 'ultrasonic_depth', latitude: 22.6789, longitude: 75.8540, warning_threshold_cm: 40.0, critical_threshold_cm: 65.0, is_active: 1, battery_pct: 100.0, current_water_level_cm: 24.0, current_flow_rate_m3s: 14.5, last_heartbeat: new Date().toISOString() },
  { id: 'ESP32_SN_009', zone_id: 'zone_regional_park', zone_name: 'Bilawali Lake', name: 'Bilawali Lake Inflow Canal', sensor_type: 'doppler_flow', latitude: 22.6710, longitude: 75.8490, warning_threshold_cm: 40.0, critical_threshold_cm: 65.0, is_active: 1, battery_pct: 91.0, current_water_level_cm: 22.8, current_flow_rate_m3s: 12.1, last_heartbeat: new Date().toISOString() },
  { id: 'ESP32_SN_010', zone_id: 'zone_sukhlia', zone_name: 'Sukhlia', name: 'MR 10 Railway Crossing Drain', sensor_type: 'ultrasonic_depth', latitude: 22.7621, longitude: 75.8710, warning_threshold_cm: 25.0, critical_threshold_cm: 45.0, is_active: 1, battery_pct: 93.0, current_water_level_cm: 8.2, current_flow_rate_m3s: 1.2, last_heartbeat: new Date().toISOString() },
  { id: 'ESP32_SN_011', zone_id: 'zone_annapurna', zone_name: 'Annapurna', name: 'Annapurna Temple Storm Trunk', sensor_type: 'ultrasonic_depth', latitude: 22.6980, longitude: 75.8420, warning_threshold_cm: 25.0, critical_threshold_cm: 45.0, is_active: 1, battery_pct: 89.0, current_water_level_cm: 9.4, current_flow_rate_m3s: 1.4, last_heartbeat: new Date().toISOString() },
  { id: 'ESP32_SN_012', zone_id: 'zone_rajwada', zone_name: 'Rajwada Basin', name: 'Malharganj Drainage Outfall', sensor_type: 'ultrasonic_depth', latitude: 22.7230, longitude: 75.8540, warning_threshold_cm: 30.0, critical_threshold_cm: 50.0, is_active: 1, battery_pct: 95.0, current_water_level_cm: 41.0, current_flow_rate_m3s: 5.2, last_heartbeat: new Date().toISOString() },
];

export const INITIAL_ASSETS: DrainageAsset[] = [
  { id: 'PUMP_KAHN_01', zone_id: 'zone_rajwada', zone_name: 'Rajwada Basin', name: 'Kahn Outfall Heavy Storm Pump #1', asset_type: 'stormwater_pump', latitude: 22.7215, longitude: 75.8595, rated_capacity_m3s: 15.0, current_status: 'RUNNING', silt_blockage_pct: 12.0, current_water_depth_cm: 48.0, last_inspected_at: new Date().toISOString() },
  { id: 'PUMP_KAHN_02', zone_id: 'zone_rajwada', zone_name: 'Rajwada Basin', name: 'Kahn Outfall Heavy Storm Pump #2', asset_type: 'stormwater_pump', latitude: 22.7216, longitude: 75.8596, rated_capacity_m3s: 15.0, current_status: 'OPERATIONAL', silt_blockage_pct: 10.0, current_water_depth_cm: 48.0, last_inspected_at: new Date().toISOString() },
  { id: 'PUMP_RAJWADA_01', zone_id: 'zone_rajwada', zone_name: 'Rajwada Basin', name: 'Rajwada Low Basin Sump Pump', asset_type: 'stormwater_pump', latitude: 22.7196, longitude: 75.8577, rated_capacity_m3s: 10.0, current_status: 'RUNNING', silt_blockage_pct: 25.0, current_water_depth_cm: 42.5, last_inspected_at: new Date().toISOString() },
  { id: 'PUMP_VIJAY_01', zone_id: 'zone_vijay_nagar', zone_name: 'Vijay Nagar', name: 'Vijay Nagar Underpass Ejector', asset_type: 'stormwater_pump', latitude: 22.7533, longitude: 75.8937, rated_capacity_m3s: 12.0, current_status: 'OPERATIONAL', silt_blockage_pct: 8.0, current_water_depth_cm: 18.0, last_inspected_at: new Date().toISOString() },
  { id: 'PUMP_BHANWAR_01', zone_id: 'zone_bhanwarkuan', zone_name: 'Bhanwarkuan', name: 'Bhanwarkuan Relief Pump', asset_type: 'stormwater_pump', latitude: 22.6926, longitude: 75.8676, rated_capacity_m3s: 8.0, current_status: 'RUNNING', silt_blockage_pct: 30.0, current_water_depth_cm: 38.6, last_inspected_at: new Date().toISOString() },
  { id: 'GATE_PIPLIYA_01', zone_id: 'zone_regional_park', zone_name: 'Regional Park', name: 'Pipliyapala Lake Sluice Gate', asset_type: 'sluice_gate', latitude: 22.6789, longitude: 75.8540, rated_capacity_m3s: 25.0, current_status: 'OPERATIONAL', silt_blockage_pct: 5.0, current_water_depth_cm: 24.0, last_inspected_at: new Date().toISOString() },
  { id: 'GATE_BILAWALI_01', zone_id: 'zone_regional_park', zone_name: 'Bilawali Lake', name: 'Bilawali Spillway Diversion Gate', asset_type: 'sluice_gate', latitude: 22.6710, longitude: 75.8490, rated_capacity_m3s: 30.0, current_status: 'OPERATIONAL', silt_blockage_pct: 7.0, current_water_depth_cm: 22.8, last_inspected_at: new Date().toISOString() },
  { id: 'PUMP_CHHAVANI_01', zone_id: 'zone_chhavani', zone_name: 'Chhavani', name: 'Chhavani Market Drainage Sump', asset_type: 'stormwater_pump', latitude: 22.7121, longitude: 75.8643, rated_capacity_m3s: 8.0, current_status: 'RUNNING', silt_blockage_pct: 22.0, current_water_depth_cm: 44.0, last_inspected_at: new Date().toISOString() },
];

export const INITIAL_INCIDENTS: Incident[] = [
  {
    id: 'INC_SOS_001',
    tracking_code: 'IND-SOS-1042',
    reported_by_name: 'Sunita Jain',
    phone: '+91 98260 55667',
    incident_type: 'EMERGENCY_SOS',
    latitude: 22.7185,
    longitude: 75.8562,
    landmark_address: 'Sarafa Bazaar, Near Gopal Mandir',
    severity: 'CRITICAL',
    people_stranded: 4,
    medical_emergency: 1,
    status: 'DISPATCHED',
    assigned_unit: 'Palasia Fire Rescue Unit 1',
    notes: 'Ground floor flooded with 45cm water. Elderly grandmother requires wheelchair assistance.',
    resolution_notes: 'Rescue boat dispatched from Palasia Fire HQ.',
    created_at: new Date(Date.now() - 25 * 60000).toISOString(),
    updated_at: new Date(Date.now() - 10 * 60000).toISOString()
  },
  {
    id: 'INC_SOS_002',
    tracking_code: 'IND-SOS-1043',
    reported_by_name: 'Mohammad Farooq',
    phone: '+91 94250 22334',
    incident_type: 'EMERGENCY_SOS',
    latitude: 22.6930,
    longitude: 75.8660,
    landmark_address: 'Bhanwarkuan Square, Near Petrol Pump',
    severity: 'HIGH',
    people_stranded: 2,
    medical_emergency: 0,
    status: 'REPORTED',
    notes: 'Car stalled in middle of intersection, water touching car window sill.',
    created_at: new Date(Date.now() - 15 * 60000).toISOString(),
    updated_at: new Date(Date.now() - 15 * 60000).toISOString()
  },
  {
    id: 'INC_REP_001',
    tracking_code: 'IND-REP-2011',
    reported_by_name: 'Ramesh Patidar',
    phone: '+91 98262 99001',
    incident_type: 'WATERLOGGING_REPORT',
    latitude: 22.7125,
    longitude: 75.8638,
    landmark_address: 'Chhavani Main Gate, Siyaganj',
    severity: 'MODERATE',
    people_stranded: 0,
    medical_emergency: 0,
    status: 'VERIFIED',
    assigned_unit: 'IMC Drainage Ward Team 4',
    notes: 'Main storm drain backed up due to plastic crate obstruction.',
    created_at: new Date(Date.now() - 40 * 60000).toISOString(),
    updated_at: new Date(Date.now() - 20 * 60000).toISOString()
  }
];

export const INITIAL_SHELTERS: EmergencyShelter[] = [
  { id: 'SHELTER_01', name: 'Holkar Stadium Relief Camp', latitude: 22.7258, longitude: 75.8778, address: 'MG Road, Race Course Road', capacity: 2500, current_occupancy: 340, contact_phone: '+91 731 2541100', facilities: 'Medical Aid, Purified Water, Food Rations, Power Backup', is_active: 1 },
  { id: 'SHELTER_02', name: 'Nehru Stadium Evacuation Center', latitude: 22.7130, longitude: 75.8820, address: 'Residency Area, Near Zoo', capacity: 1800, current_occupancy: 210, contact_phone: '+91 731 2512345', facilities: 'First Aid, Dormitory, High Ground Kitchen, Ambulance Bay', is_active: 1 },
  { id: 'SHELTER_03', name: 'Gandhi Hall Civic Relief Hub', latitude: 22.7210, longitude: 75.8620, address: 'Mahatma Gandhi Road', capacity: 800, current_occupancy: 150, contact_phone: '+91 731 2534567', facilities: 'Drinking Water, Restrooms, Temporary Beds, VHF Radio Link', is_active: 1 },
  { id: 'SHELTER_04', name: 'Scheme 54 Community Hall', latitude: 22.7550, longitude: 75.8900, address: 'Near Meghdoot Garden, Vijay Nagar', capacity: 1200, current_occupancy: 80, contact_phone: '+91 731 2556789', facilities: 'Kitchen Facility, Sanitation, Family Dorms, Wi-Fi', is_active: 1 },
  { id: 'SHELTER_05', name: 'DAVV University Auditorium Shelter', latitude: 22.6950, longitude: 75.8720, address: 'Takshashila Campus, Khandwa Road', capacity: 1500, current_occupancy: 195, contact_phone: '+91 731 2468901', facilities: 'Medical Station, Hot Meals, Charging Kiosks, Child Care', is_active: 1 },
  { id: 'SHELTER_06', name: 'Annapurna Community Relief Center', latitude: 22.7030, longitude: 75.8380, address: 'Annapurna Road, Near Temple', capacity: 950, current_occupancy: 110, contact_phone: '+91 731 2489012', facilities: 'Dry Rations, Medical Staff, Clean Water, Sanitized Beds', is_active: 1 }
];

export const INITIAL_WORK_ORDERS: WorkOrder[] = [
  { id: 'WO_101', asset_id: 'PUMP_KAHN_01', asset_name: 'Kahn Outfall Heavy Storm Pump #1', asset_type: 'stormwater_pump', assigned_to: 'Vikram Singh', title: 'Desilt Sump Basin & Check Impeller', description: 'Heavy silt load reported after 45mm rainfall. Inspect suction screen.', priority: 'URGENT', status: 'IN_PROGRESS', initial_silt_pct: 25.0, inspection_notes: 'Suction screen partially obstructed with debris. Commencing clearing.', latitude: 22.7215, longitude: 75.8595, created_at: new Date(Date.now() - 120 * 60000).toISOString() },
  { id: 'WO_102', asset_id: 'PUMP_BHANWAR_01', asset_name: 'Bhanwarkuan Relief Pump', asset_type: 'stormwater_pump', assigned_to: 'Vikram Singh', title: 'Clear Debris Grating & Flow Calibration', description: 'Preventive inspection and clearing of inlet channel.', priority: 'ROUTINE', status: 'PENDING', initial_silt_pct: 30.0, inspection_notes: 'Pending technician arrival on site.', latitude: 22.6926, longitude: 75.8676, created_at: new Date(Date.now() - 60 * 60000).toISOString() },
  { id: 'WO_103', asset_id: 'GATE_PIPLIYA_01', asset_name: 'Pipliyapala Lake Sluice Gate', asset_type: 'sluice_gate', assigned_to: 'Vikram Singh', title: 'Hydraulic Sluice Actuator Lubrication', description: 'Monthly service of retention basin control gates.', priority: 'ROUTINE', status: 'COMPLETED', initial_silt_pct: 12.0, final_silt_pct: 5.0, inspection_notes: 'Hydraulic cylinders tested, actuator functioning within 0.2s tolerance.', latitude: 22.6789, longitude: 75.8540, created_at: new Date(Date.now() - 360 * 60000).toISOString(), completed_at: new Date(Date.now() - 30 * 60000).toISOString() }
];

export const INITIAL_PUMP_RECS: PumpRecommendation[] = [
  { id: 'REC_001', asset_id: 'PUMP_KAHN_02', asset_name: 'Kahn Outfall Heavy Storm Pump #2', zone_id: 'zone_rajwada', zone_name: 'Rajwada Basin', recommended_action: 'START_PUMP', urgency: 'URGENT', rationale: 'Kahn River inflow at 28.4 m³/s exceeds 85% single-pump conveyance. Engage secondary 15 m³/s pump to avert bank overflow.', inflow_rate_m3s: 28.4, status: 'PENDING', created_at: new Date(Date.now() - 10 * 60000).toISOString() },
  { id: 'REC_002', asset_id: 'PUMP_BHANWAR_01', asset_name: 'Bhanwarkuan Relief Pump', zone_id: 'zone_bhanwarkuan', zone_name: 'Bhanwarkuan', recommended_action: 'INCREASE_RPM', urgency: 'ADVISORY', rationale: 'Water level at Bhanwarkuan gauge reached 38.6cm (warning threshold 30cm). Increase ejector discharge to 100%.', inflow_rate_m3s: 14.2, status: 'PENDING', created_at: new Date(Date.now() - 18 * 60000).toISOString() }
];

export const INITIAL_ALERTS: AlertNotification[] = [
  { id: 'ALERT_001', title: 'FLASH FLOOD WARNING: Rajwada & Sarafa Basin', severity: 'CRITICAL', target_zones: 'Rajwada, Sarafa, Chhavani', message: 'Intense precipitation (45mm/h) has triggered waterlogging in historic low-lying areas. Avoid underpasses and MG Road.', instructions: 'Evacuate basement commercial shops. Follow flood-aware routes to Holkar Stadium or Gandhi Hall shelters.', created_at: new Date(Date.now() - 30 * 60000).toISOString(), expires_at: new Date(Date.now() + 300 * 60000).toISOString(), is_active: 1 },
  { id: 'ALERT_002', title: 'Heavy Rain Advisory: Bhanwarkuan & University Corridor', severity: 'HIGH', target_zones: 'Bhanwarkuan, Khandwa Road', message: 'Water level rising rapidly along BRTS corridor. Drive cautiously.', instructions: 'Avoid waterlogged junctions. Use alternative Ring Road routes.', created_at: new Date(Date.now() - 50 * 60000).toISOString(), expires_at: new Date(Date.now() + 180 * 60000).toISOString(), is_active: 1 }
];
