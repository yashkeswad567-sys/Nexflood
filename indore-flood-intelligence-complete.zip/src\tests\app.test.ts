import { describe, it, expect } from 'vitest';
import { INITIAL_ZONES, INITIAL_SENSORS, INITIAL_ASSETS, INITIAL_SHELTERS } from '../services/demoData';

describe('Indore Flood Intelligence Frontend Architecture', () => {
  it('loads authentic Indore catchment zones with valid polygons', () => {
    expect(INITIAL_ZONES.length).toBe(8);
    const rajwada = INITIAL_ZONES.find(z => z.id === 'zone_rajwada');
    expect(rajwada).toBeDefined();
    expect(rajwada?.polygon_geojson.length).toBeGreaterThan(3);
    expect(rajwada?.elevation_m).toBe(546.0);
  });

  it('verifies 12 IoT sensor telemetry stations across Indore basins', () => {
    expect(INITIAL_SENSORS.length).toBe(12);
    const kahnSensor = INITIAL_SENSORS.find(s => s.id === 'ESP32_SN_002');
    expect(kahnSensor).toBeDefined();
    expect(kahnSensor?.warning_threshold_cm).toBe(35.0);
    expect(kahnSensor?.critical_threshold_cm).toBe(55.0);
  });

  it('validates 8 municipal storm pumps and lake retention sluice gates', () => {
    expect(INITIAL_ASSETS.length).toBe(8);
    const kahnPump = INITIAL_ASSETS.find(a => a.id === 'PUMP_KAHN_01');
    expect(kahnPump?.rated_capacity_m3s).toBe(15.0);
    expect(kahnPump?.current_status).toBe('RUNNING');
  });

  it('verifies 6 high ground emergency relief centers', () => {
    expect(INITIAL_SHELTERS.length).toBe(6);
    const holkar = INITIAL_SHELTERS.find(s => s.id === 'SHELTER_01');
    expect(holkar?.name).toContain('Holkar Stadium');
    expect(holkar?.capacity).toBe(2500);
  });

  it('validates MapLibre GL JS OpenStreetMap geospatial coordinate normalization', () => {
    // Test [lat, lng] to [lng, lat] coordinate flip
    const latLng: [number, number] = [22.7196, 75.8577];
    const isLatLng = latLng[0] < 50 && latLng[1] > 50;
    const normalized = isLatLng ? [latLng[1], latLng[0]] : latLng;
    expect(normalized[0]).toBe(75.8577); // Longitude first for RFC 7946 / MapLibre
    expect(normalized[1]).toBe(22.7196); // Latitude second
  });
});
