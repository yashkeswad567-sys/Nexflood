import React from 'react';
import { User, Shield, Building2, Mail, Phone, Key, LogOut } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';

export const UserProfilePage: React.FC = () => {
  const { user, role, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-3xl mx-auto space-y-6">
      
      <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
        
        {/* User Card Header */}
        <div className="flex items-center gap-4 border-b border-slate-100 dark:border-slate-800 pb-6">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-sky-600 via-blue-600 to-indigo-600 flex items-center justify-center text-white text-2xl font-bold shadow-lg shadow-sky-500/20">
            {user?.name.charAt(0) || 'U'}
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-900 dark:text-white">{user?.name || 'Authorized User'}</h1>
            <p className="text-xs text-slate-500">{user?.organization || 'Indore Municipal Corporation'}</p>
            <div className="inline-flex items-center gap-1.5 mt-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-sky-500/10 text-sky-500 uppercase border border-sky-500/20">
              <Shield className="w-3 h-3" />
              <span>Role: {role.replace('_', ' ')}</span>
            </div>
          </div>
        </div>

        {/* User Attributes */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
          
          <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 flex items-start gap-3">
            <Mail className="w-4 h-4 text-slate-400 mt-0.5" />
            <div>
              <span className="text-slate-400 text-[10px] block uppercase font-bold">Email Address</span>
              <span className="font-semibold text-slate-800 dark:text-slate-200">{user?.email || 'user@indore.gov.in'}</span>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 flex items-start gap-3">
            <Building2 className="w-4 h-4 text-slate-400 mt-0.5" />
            <div>
              <span className="text-slate-400 text-[10px] block uppercase font-bold">Organization</span>
              <span className="font-semibold text-slate-800 dark:text-slate-200">{user?.organization || 'IMC Smart City'}</span>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 flex items-start gap-3">
            <Phone className="w-4 h-4 text-slate-400 mt-0.5" />
            <div>
              <span className="text-slate-400 text-[10px] block uppercase font-bold">Emergency Phone</span>
              <span className="font-semibold text-slate-800 dark:text-slate-200">{user?.phone || '+91 731 2537253'}</span>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 flex items-start gap-3">
            <Key className="w-4 h-4 text-slate-400 mt-0.5" />
            <div>
              <span className="text-slate-400 text-[10px] block uppercase font-bold">Session Security</span>
              <span className="font-semibold text-emerald-500 font-mono">HMAC-SHA256 Signed</span>
            </div>
          </div>

        </div>

        {/* Action Button */}
        <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex justify-between items-center">
          <span className="text-xs text-slate-400">Authenticated via Indore Citizen & Disaster Network</span>
          <button
            onClick={handleLogout}
            className="px-4 py-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-600 dark:text-rose-400 text-xs font-bold transition-colors flex items-center gap-2"
          >
            <LogOut className="w-4 h-4" />
            <span>End Session</span>
          </button>
        </div>

      </div>

    </div>
  );
};
