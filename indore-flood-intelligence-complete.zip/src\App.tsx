import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { ThemeProvider } from './context/ThemeContext';
import { AuthProvider } from './context/AuthContext';
import { FloodDataProvider } from './context/FloodDataContext';
import { Navbar } from './components/layout/Navbar';
import { Sidebar } from './components/layout/Sidebar';

import { LandingPage } from './pages/LandingPage';
import { LoginPage } from './pages/LoginPage';
import { CitizenDashboard } from './pages/CitizenDashboard';
import { MunicipalDashboard } from './pages/MunicipalDashboard';
import { FieldEngineerDashboard } from './pages/FieldEngineerDashboard';
import { FirefighterDashboard } from './pages/FirefighterDashboard';
import { DigitalTwinPage } from './pages/DigitalTwinPage';
import { RoutePlannerPage } from './pages/RoutePlannerPage';
import { SettingsPage } from './pages/SettingsPage';
import { UserProfilePage } from './pages/UserProfilePage';

const AppLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  return (
    <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors">
      <Navbar />
      <div className="flex-1 flex w-full">
        <Sidebar />
        <main className="flex-1 overflow-x-hidden min-h-[calc(100vh-4rem)]">
          {children}
        </main>
      </div>
    </div>
  );
};

export const App: React.FC = () => {
  return (
    <ThemeProvider>
      <AuthProvider>
        <FloodDataProvider>
          <BrowserRouter>
            <Routes>
              
              {/* Public Landing */}
              <Route path="/" element={<AppLayout><LandingPage /></AppLayout>} />
              <Route path="/login" element={<AppLayout><LoginPage /></AppLayout>} />

              {/* 4 Role-Based Dashboards */}
              <Route path="/dashboard/citizen" element={<AppLayout><CitizenDashboard /></AppLayout>} />
              <Route path="/dashboard/municipal" element={<AppLayout><MunicipalDashboard /></AppLayout>} />
              <Route path="/dashboard/field-engineer" element={<AppLayout><FieldEngineerDashboard /></AppLayout>} />
              <Route path="/dashboard/firefighter" element={<AppLayout><FirefighterDashboard /></AppLayout>} />

              {/* Specialized Modules */}
              <Route path="/digital-twin" element={<AppLayout><DigitalTwinPage /></AppLayout>} />
              <Route path="/route-planner" element={<AppLayout><RoutePlannerPage /></AppLayout>} />
              <Route path="/settings" element={<AppLayout><SettingsPage /></AppLayout>} />
              <Route path="/profile" element={<AppLayout><UserProfilePage /></AppLayout>} />

              {/* Fallback */}
              <Route path="*" element={<Navigate to="/" replace />} />

            </Routes>
          </BrowserRouter>
        </FloodDataProvider>
      </AuthProvider>
    </ThemeProvider>
  );
};

export default App;
