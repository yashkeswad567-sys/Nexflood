"""
Hydrological & AI Flood Prediction Engine for Indore Flood Intelligence (IFI).
Combines physics-informed rainfall-runoff dynamics (Rational Method + SCS-CN)
with multi-horizon forecasting (1h, 2h, 3h), uncertainty bounds, and road inundation mapping.
"""

import math
import json
from datetime import datetime
from typing import Dict, Any, List, Tuple
from .database import get_connection, _lock, log_audit

MODEL_VERSION = "ifi-hybrid-v1.2.0-baseline"

def calculate_scs_runoff(precipitation_mm: float, curve_number: float) -> float:
    """
    Computes cumulative direct runoff depth Q (mm) using the SCS Curve Number method.
    P = storm precipitation (mm)
    CN = Soil Conservation Service Curve Number (dimensionless, 30-100)
    """
    if precipitation_mm <= 0 or curve_number <= 0:
        return 0.0
    
    # Potential maximum soil retention S (mm)
    s = (25400.0 / curve_number) - 254.0
    
    # Initial abstraction Ia (surface storage, interception, initial infiltration)
    ia = 0.2 * s
    
    if precipitation_mm <= ia:
        return 0.0
    
    numerator = (precipitation_mm - ia) ** 2
    denominator = (precipitation_mm - ia) + s
    if denominator <= 0:
        return 0.0
    return numerator / denominator

def calculate_peak_discharge(rainfall_intensity_mmh: float, runoff_coeff: float, area_km2: float) -> float:
    """
    Computes peak runoff rate Qp (m3/s) using the Rational Method:
    Q = 0.278 * C * I * A
    """
    return 0.278 * runoff_coeff * rainfall_intensity_mmh * area_km2

def compute_zone_hazard(
    rainfall_rate_mmh: float,
    rainfall_accum_mm: float,
    zone: Dict[str, Any],
    horizon_hours: float = 0.0
) -> Dict[str, Any]:
    """
    Calculates water depth and hazard index for a specific catchment zone
    at a given forecast horizon (0 = now, 1 = +1h, 2 = +2h, 3 = +3h).
    """
    # Decay or surge rainfall depending on forecast horizon
    # In flash flood hydrograph: peak occurs at horizon ~1h-1.5h, then recessional limb
    if horizon_hours == 0:
        horizon_factor = 1.0
    elif horizon_hours == 1:
        horizon_factor = 1.25  # Hydrograph peak buildup
    elif horizon_hours == 2:
        horizon_factor = 1.10  # High sustained ponding
    else:
        horizon_factor = 0.85  # Drainage starting to convey excess water
        
    eff_rainfall_rate = rainfall_rate_mmh * horizon_factor
    eff_accum_rain = rainfall_accum_mm + (eff_rainfall_rate * max(1.0, horizon_hours))
    
    # Rational method peak inflow
    inflow_m3s = calculate_peak_discharge(
        rainfall_intensity_mmh=eff_rainfall_rate,
        runoff_coeff=zone["impervious_surface_ratio"],
        area_km2=zone["catchment_area_km2"]
    )
    
    # Outflow capacity adjusted for drainage basin elevation and channel sizing
    rated_capacity = zone["drainage_capacity_m3s"]
    excess_flow = max(0.0, inflow_m3s - rated_capacity)
    
    # SCS-CN direct runoff depth in mm
    scs_runoff_mm = calculate_scs_runoff(eff_accum_rain, zone["soil_curve_number"])
    
    # Elevation depression factor (lower elevation = higher ponding risk)
    # Indore baseline elevation is ~553m AMSL
    elevation_factor = max(0.6, min(1.8, (560.0 - zone["elevation_m"]) / 12.0 + 0.8))
    
    # Base water depth (cm)
    water_depth_cm = (scs_runoff_mm * 0.45 * elevation_factor) + (excess_flow * 0.85)
    water_depth_cm = round(max(0.0, min(150.0, water_depth_cm)), 1)
    
    # Soil saturation percentage
    saturation_pct = min(100.0, round(40.0 + (eff_accum_rain * 0.6) + (zone["impervious_surface_ratio"] * 20.0), 1))
    
    # Drainage capacity utilization
    util_pct = round(min(180.0, (inflow_m3s / max(1.0, rated_capacity)) * 100.0), 1)
    
    # Hazard classification
    if water_depth_cm < 15.0:
        hazard_level = "LOW"
    elif water_depth_cm < 30.0:
        hazard_level = "MODERATE"
    elif water_depth_cm < 50.0:
        hazard_level = "HIGH"
    else:
        hazard_level = "CRITICAL"
        
    # Uncertainty confidence interval (90% CI)
    ci_spread = round(water_depth_cm * (0.08 + (horizon_hours * 0.05)), 1)
    depth_ci_lower = max(0.0, round(water_depth_cm - ci_spread, 1))
    depth_ci_upper = round(water_depth_cm + ci_spread, 1)
    confidence_pct = round(max(65.0, 94.0 - (horizon_hours * 5.5)), 1)
    
    return {
        "zone_id": zone["id"],
        "name": zone["name"],
        "hazard_level": hazard_level,
        "water_depth_cm": water_depth_cm,
        "depth_ci_lower": depth_ci_lower,
        "depth_ci_upper": depth_ci_upper,
        "confidence_pct": confidence_pct,
        "inflow_m3s": round(inflow_m3s, 2),
        "drainage_capacity_util_pct": util_pct,
        "soil_saturation_pct": saturation_pct
    }

def run_flood_simulation(scenario_name: str, rainfall_rate_mmh: float, soil_moisture_pct: float = 75.0) -> Dict[str, Any]:
    """
    Executes a complete flood simulation across all Indore catchment zones,
    updates database records, flags impassable roads, and computes multi-horizon forecasts.
    """
    accum_rain_24h = rainfall_rate_mmh * 1.8 + 15.0
    now_iso = datetime.utcnow().isoformat()
    
    with _lock:
        conn = get_connection()
        cursor = conn.cursor()
        
        # Update simulation state
        cursor.execute("UPDATE system_state SET value = ?, updated_at = ? WHERE key = 'scenario_name'", (scenario_name, now_iso))
        cursor.execute("UPDATE system_state SET value = ?, updated_at = ? WHERE key = 'rainfall_rate_mmh'", (str(rainfall_rate_mmh), now_iso))
        cursor.execute("UPDATE system_state SET value = ?, updated_at = ? WHERE key = 'soil_moisture_pct'", (str(soil_moisture_pct), now_iso))
        
        # Load all zones
        cursor.execute("SELECT * FROM catchment_zones")
        zones_rows = [dict(r) for r in cursor.fetchall()]
        
        zone_results = []
        city_max_depth = 0.0
        
        for z in zones_rows:
            now_pred = compute_zone_hazard(rainfall_rate_mmh, accum_rain_24h, z, horizon_hours=0.0)
            h1_pred = compute_zone_hazard(rainfall_rate_mmh, accum_rain_24h, z, horizon_hours=1.0)
            h2_pred = compute_zone_hazard(rainfall_rate_mmh, accum_rain_24h, z, horizon_hours=2.0)
            h3_pred = compute_zone_hazard(rainfall_rate_mmh, accum_rain_24h, z, horizon_hours=3.0)
            
            # Update zone in database
            cursor.execute("""
                UPDATE catchment_zones
                SET current_hazard_level = ?,
                    current_water_depth_cm = ?,
                    soil_saturation_pct = ?,
                    updated_at = ?
                WHERE id = ?
            """, (
                now_pred["hazard_level"],
                now_pred["water_depth_cm"],
                now_pred["soil_saturation_pct"],
                now_iso,
                z["id"]
            ))
            
            # Update IoT sensors located in this zone
            cursor.execute("""
                UPDATE sensor_devices
                SET current_water_level_cm = ?,
                    current_flow_rate_m3s = ?,
                    last_heartbeat = ?
                WHERE zone_id = ?
            """, (
                now_pred["water_depth_cm"] + 2.5,
                now_pred["inflow_m3s"] * 0.4,
                now_iso,
                z["id"]
            ))
            
            # Update roads within this zone
            # If water depth > 30cm, road is impassable (blocked)
            is_blocked = 1 if now_pred["water_depth_cm"] >= 30.0 else 0
            cursor.execute("""
                UPDATE road_segments
                SET current_water_depth_cm = ?,
                    is_blocked = ?
                WHERE zone_id = ?
            """, (now_pred["water_depth_cm"], is_blocked, z["id"]))
            
            city_max_depth = max(city_max_depth, now_pred["water_depth_cm"])
            
            zone_results.append({
                "zone_id": z["id"],
                "name": z["name"],
                "centroid_lat": z["centroid_lat"],
                "centroid_lng": z["centroid_lng"],
                "elevation_m": z["elevation_m"],
                "polygon_geojson": json.loads(z["polygon_geojson"]),
                "current": now_pred,
                "forecast_1h": h1_pred,
                "forecast_2h": h2_pred,
                "forecast_3h": h3_pred,
            })
            
        conn.commit()
        conn.close()
        
    # City-wide aggregate hazard level
    if city_max_depth < 15.0:
        city_hazard = "LOW"
    elif city_max_depth < 30.0:
        city_hazard = "MODERATE"
    elif city_max_depth < 50.0:
        city_hazard = "HIGH"
    else:
        city_hazard = "CRITICAL"
        
    log_audit("RUN_SIMULATION", "SYSTEM_SCENARIO", scenario_name, f"Rainfall: {rainfall_rate_mmh} mm/h. City Hazard: {city_hazard}")
    
    return {
        "scenario_name": scenario_name,
        "rainfall_rate_mmh": rainfall_rate_mmh,
        "rainfall_24h_accum_mm": accum_rain_24h,
        "city_hazard_level": city_hazard,
        "city_max_water_depth_cm": city_max_depth,
        "model_version": MODEL_VERSION,
        "timestamp": now_iso,
        "zones": zone_results
    }
