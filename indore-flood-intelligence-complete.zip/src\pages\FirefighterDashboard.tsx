import React, { useState } from 'react';
import {
  Flame, ShieldAlert, Navigation, Clock, CheckCircle2,
  Users, HeartPulse, Radio, AlertTriangle, Phone, Compass,
  Truck, Anchor, LifeBuoy, RefreshCw, Send, Check
} from 'lucide-react';
import { useFloodData } from '../context/FloodDataContext';
import { Incident, RouteResponse } from '../types';
import { api } from '../services/api';
import { IndoreMapView } from '../components/map/IndoreMapView';

export const FirefighterDashboard: React.FC = () => {
  const { floodStatus, incidents, shelters, updateIncidentStatus, refreshData, isLoading } = useFloodData();
  const zones = floodStatus?.zones || [];

  // Active Incident Selection
  const [selectedIncident, setSelectedIncident] = useState<Incident | null>(
    incidents.find(i => i.status !== 'RESOLVED') || incidents[0] || null
  );

  // Response Route State
  const [routeResult, setRouteResult] = useState<RouteResponse | null>(null);
  const [isNavigating, setIsNavigating] = useState<boolean>(false);

  // Station Apparatus Status
  const [boatAvailable, setBoatAvailable] = useState<boolean>(true);
  const [tenderAvailable, setTenderAvailable] = useState<boolean>(true);
  const [teamReady, setTeamReady] = useState<boolean>(true);

  // Communication Log
  const [commNote, setCommNote] = useState<string>('Rescue Boat 2 en route via MG Road Bypass.');
  const [commLogs, setCommLogs] = useState<string[]>([
    '04:30 - Dispatch order received from IMC Municipal Control.',
    '04:32 - 3-person water rescue team deployed with inflatable Zodiac boat.',
    '04:35 - Flood-aware route navigation loaded. Avoiding Rajwada low underpass.'
  ]);

  // Handle Calculate Emergency Route to Selected Incident
  const handleCalculateRescueRoute = async (inc: Incident) => {
    setIsNavigating(true);
    try {
      // Fire Station HQ: Palasia (22.7244, 75.8839) -> Incident
      const res = await api.calculateRoute(22.7244, 75.8839, inc.latitude, inc.longitude, 'rescue_boat');
      setRouteResult(res);
    } catch (e) {
      console.error(e);
    } finally {
      setIsNavigating(false);
    }
  };

  // Handle Advance Incident Lifecycle
  const handleAdvanceStatus = async (newStatus: string) => {
    if (!selectedIncident) return;
    await updateIncidentStatus(selectedIncident.id, newStatus, `Field team status: ${newStatus}`);
    
    // Add to comm log
    const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    setCommLogs(prev => [`${time} - Unit advanced status to: ${newStatus}`, ...prev]);

    // Update local selection
    setSelectedIncident(prev => prev ? { ...prev, status: newStatus as any } : null);
  };

  const activeRescues = incidents.filter(i => i.status !== 'RESOLVED');

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6">
      
      {/* Firefighter HQ Banner */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-5 rounded-2xl bg-gradient-to-r from-rose-950 via-slate-900 to-rose-900 border border-rose-900/40 text-white shadow-xl">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded text-[10px] font-extrabold uppercase tracking-wider bg-rose-500/20 text-rose-300 border border-rose-500/30">
              Fire & Emergency Rescue Service
            </span>
            <span className="text-xs text-rose-200">Indore Municipal Corporation (HQ Palasia)</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-extrabold tracking-tight mt-1 flex items-center gap-2">
            <Flame className="w-6 h-6 text-rose-500 animate-pulse" />
            <span>Emergency Dispatch & Water Rescue Command</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-1">
            Real-time citizen SOS distress calls, flood-aware response navigation & rescue progress lifecycle.
          </p>
        </div>

        {/* Readiness Badge */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-bold">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
            <span>STATION READY (CODE 1)</span>
          </div>
          <button
            onClick={() => refreshData()}
            className="p-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Station Equipment & Team Availability Toggles */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        
        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-rose-500/10 text-rose-500">
              <Anchor className="w-5 h-5" />
            </div>
            <div>
              <div className="font-bold text-xs">Rescue Boat 2 (Zodiac)</div>
              <div className="text-[11px] text-slate-500">Water rescue apparatus</div>
            </div>
          </div>
          <button
            onClick={() => setBoatAvailable(!boatAvailable)}
            className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors ${boatAvailable ? 'bg-emerald-500/10 text-emerald-500' : 'bg-slate-200 dark:bg-slate-800 text-slate-400'}`}
          >
            {boatAvailable ? 'DEPLOYED' : 'STANDBY'}
          </button>
        </div>

        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-amber-500/10 text-amber-500">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <div className="font-bold text-xs">Heavy Tender #4</div>
              <div className="text-[11px] text-slate-500">High ground clearance 4x4</div>
            </div>
          </div>
          <button
            onClick={() => setTenderAvailable(!tenderAvailable)}
            className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors ${tenderAvailable ? 'bg-emerald-500/10 text-emerald-500' : 'bg-slate-200 dark:bg-slate-800 text-slate-400'}`}
          >
            {tenderAvailable ? 'READY' : 'MAINTENANCE'}
          </button>
        </div>

        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-sky-500/10 text-sky-500">
              <LifeBuoy className="w-5 h-5" />
            </div>
            <div>
              <div className="font-bold text-xs">Crew Duty Status</div>
              <div className="text-[11px] text-slate-500">4 Divers & 2 Medics</div>
            </div>
          </div>
          <button
            onClick={() => setTeamReady(!teamReady)}
            className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors ${teamReady ? 'bg-emerald-500/10 text-emerald-500' : 'bg-slate-200 dark:bg-slate-800 text-slate-400'}`}
          >
            {teamReady ? 'ACTIVE' : 'REST'}
          </button>
        </div>

      </div>

      {/* Main Grid: Active SOS Queue + Incident Operational Center */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Incident Queue */}
        <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ShieldAlert className="w-5 h-5 text-rose-500" />
              <h3 className="font-bold text-sm text-slate-900 dark:text-slate-100">Emergency Distress Rescue Queue</h3>
            </div>
            <span className="text-xs font-mono font-bold text-rose-500">{activeRescues.length} Active</span>
          </div>

          <div className="space-y-3">
            {incidents.map((inc) => {
              const isSelected = selectedIncident?.id === inc.id;
              const isSOS = inc.incident_type === 'EMERGENCY_SOS';

              return (
                <div
                  key={inc.id}
                  onClick={() => {
                    setSelectedIncident(inc);
                    handleCalculateRescueRoute(inc);
                  }}
                  className={`p-4 rounded-xl border transition-all cursor-pointer ${
                    isSelected
                      ? 'border-rose-500 bg-rose-50/20 dark:bg-rose-950/20 shadow-md'
                      : 'border-slate-200 dark:border-slate-800 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-xs">{inc.tracking_code}</span>
                      <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded uppercase ${
                        inc.severity === 'CRITICAL' ? 'bg-rose-500/10 text-rose-500' : 'bg-amber-500/10 text-amber-500'
                      }`}>
                        {inc.severity}
                      </span>
                    </div>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                      {inc.status}
                    </span>
                  </div>

                  <p className="font-bold text-xs text-slate-900 dark:text-white mt-1">{inc.landmark_address}</p>
                  <p className="text-xs text-slate-500 line-clamp-1">{inc.notes}</p>

                  <div className="flex items-center justify-between text-xs text-slate-400 pt-2 mt-2 border-t border-slate-100 dark:border-slate-800">
                    <span className="text-rose-500 font-bold">{inc.people_stranded} People Stranded</span>
                    <span className="text-slate-500">{inc.phone}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Selected Incident Mission Control & Dynamic Navigation */}
        <div className="space-y-4">
          
          {selectedIncident ? (
            <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
              
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-rose-500">Live Rescue Mission</span>
                  <h3 className="font-bold text-sm text-slate-900 dark:text-slate-100">{selectedIncident.landmark_address}</h3>
                </div>
                <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800">
                  {selectedIncident.tracking_code}
                </span>
              </div>

              {/* Citizen Contact & Details */}
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60">
                  <span className="text-slate-400 block text-[11px]">Caller Contact</span>
                  <span className="font-bold text-slate-900 dark:text-white block mt-0.5">{selectedIncident.reported_by_name}</span>
                  <span className="text-slate-500">{selectedIncident.phone}</span>
                </div>
                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60">
                  <span className="text-slate-400 block text-[11px]">Stranded Headcount</span>
                  <span className="font-bold text-rose-500 text-lg block">{selectedIncident.people_stranded} People</span>
                </div>
              </div>

              {/* Rescue Lifecycle Action Buttons */}
              <div>
                <span className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-2">
                  Advance Rescue Progress Lifecycle:
                </span>
                
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  <button
                    onClick={() => handleAdvanceStatus('DISPATCHED')}
                    className={`p-2 rounded-xl text-xs font-bold transition-all text-center ${
                      selectedIncident.status === 'DISPATCHED' ? 'bg-sky-600 text-white shadow-sm' : 'border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800'
                    }`}
                  >
                    1. Dispatched
                  </button>

                  <button
                    onClick={() => handleAdvanceStatus('ON_SCENE')}
                    className={`p-2 rounded-xl text-xs font-bold transition-all text-center ${
                      selectedIncident.status === 'ON_SCENE' ? 'bg-amber-600 text-white shadow-sm' : 'border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800'
                    }`}
                  >
                    2. On Scene
                  </button>

                  <button
                    onClick={() => handleAdvanceStatus('EVACUATING')}
                    className={`p-2 rounded-xl text-xs font-bold transition-all text-center ${
                      selectedIncident.status === 'EVACUATING' ? 'bg-orange-600 text-white shadow-sm' : 'border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800'
                    }`}
                  >
                    3. Evacuating
                  </button>

                  <button
                    onClick={() => handleAdvanceStatus('RESOLVED')}
                    className={`p-2 rounded-xl text-xs font-bold transition-all text-center ${
                      selectedIncident.status === 'RESOLVED' ? 'bg-emerald-600 text-white shadow-sm' : 'border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800'
                    }`}
                  >
                    4. Completed
                  </button>
                </div>
              </div>

              {/* Dynamic Flood-Aware Route to Incident */}
              <div className="p-4 rounded-xl bg-sky-50/40 dark:bg-sky-950/20 border border-sky-500/20 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Navigation className="w-4 h-4 text-sky-500" />
                    <span className="font-bold text-xs">Response Navigation Route</span>
                  </div>
                  <button
                    onClick={() => handleCalculateRescueRoute(selectedIncident)}
                    className="text-[11px] font-bold text-sky-600 hover:text-sky-500"
                  >
                    {isNavigating ? 'Recalculating...' : 'Refresh Route'}
                  </button>
                </div>

                {routeResult ? (
                  <div className="space-y-3 text-xs">
                    <div className="flex justify-between font-semibold">
                      <span>ETA to Scene: <strong className="text-sky-500">{routeResult.primary_route.estimated_minutes} min</strong></span>
                      <span>Distance: <strong>{routeResult.primary_route.distance_km} km</strong></span>
                    </div>
                    <div className="text-[11px] text-slate-500">
                      Route Path: {routeResult.primary_route.turn_by_turn[0]} &rarr; {routeResult.primary_route.turn_by_turn[1] || 'Scene'}
                    </div>

                    {/* Tactical Route Map */}
                    <div className="pt-2">
                      <IndoreMapView
                        zones={zones}
                        incidents={incidents}
                        shelters={shelters}
                        activeRoute={routeResult.primary_route}
                        alternativeRoute={routeResult.alternative_routes ? routeResult.alternative_routes[0] : null}
                        height="280px"
                      />
                    </div>
                  </div>
                ) : (
                  <button
                    onClick={() => handleCalculateRescueRoute(selectedIncident)}
                    className="w-full py-2 rounded-lg bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs transition-colors"
                  >
                    Load Flood-Aware Route
                  </button>
                )}
              </div>

            </div>
          ) : (
            <div className="p-8 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-center text-xs text-slate-400">
              Select an incident from the queue to view details and launch navigation.
            </div>
          )}

          {/* Operational Field Communication Log */}
          <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3 text-xs">
            <div className="flex items-center gap-2">
              <Radio className="w-4 h-4 text-indigo-500" />
              <h4 className="font-bold text-slate-900 dark:text-slate-100">Field Communication Radio Log</h4>
            </div>

            <div className="space-y-1.5 font-mono text-[11px] text-slate-500 max-h-32 overflow-y-auto">
              {commLogs.map((log, idx) => (
                <div key={idx} className="p-1.5 rounded bg-slate-50 dark:bg-slate-800/40">
                  {log}
                </div>
              ))}
            </div>

            <div className="flex items-center gap-2 pt-2">
              <input
                type="text"
                value={commNote}
                onChange={(e) => setCommNote(e.target.value)}
                placeholder="Log field update..."
                className="flex-1 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs"
              />
              <button
                onClick={() => {
                  if (!commNote) return;
                  const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                  setCommLogs(prev => [`${time} - ${commNote}`, ...prev]);
                  setCommNote('');
                }}
                className="p-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
