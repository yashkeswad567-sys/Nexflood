"""
Unit and Integration Tests for IoT Ingestion, Telemetry Validation & Pump Recommendations.
"""

import unittest
import sys
import os
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
from backend.app.iot_simulator import (
    validate_telemetry_payload, ingest_telemetry, evaluate_pump_recommendations
)
from backend.app.database import init_db
from backend.app.seed_data import seed_all_data

class TestIoTTelemetry(unittest.TestCase):
    
    @classmethod
    def setUpClass(cls):
        init_db()
        seed_all_data()

    def test_validation_bounds(self):
        # Valid payload
        valid_payload = {
            "device_id": "ESP32_SN_001",
            "water_level_cm": 28.5,
            "battery_voltage": 3.9,
            "timestamp": time.time()
        }
        is_val, msg = validate_telemetry_payload(valid_payload)
        self.assertTrue(is_val)

        # Negative water level rejected
        invalid_negative = {
            "device_id": "ESP32_SN_001",
            "water_level_cm": -5.0
        }
        is_val, msg = validate_telemetry_payload(invalid_negative)
        self.assertFalse(is_val)

        # Impossible water depth (>500cm) rejected
        invalid_too_high = {
            "device_id": "ESP32_SN_001",
            "water_level_cm": 999.0
        }
        is_val, msg = validate_telemetry_payload(invalid_too_high)
        self.assertFalse(is_val)

        # Future timestamp rejected
        invalid_future = {
            "device_id": "ESP32_SN_001",
            "water_level_cm": 20.0,
            "timestamp": time.time() + 86400 # Tomorrow
        }
        is_val, msg = validate_telemetry_payload(invalid_future)
        self.assertFalse(is_val)

    def test_telemetry_ingestion(self):
        payload = {
            "device_id": "ESP32_SN_001",
            "water_level_cm": 35.0,
            "flow_rate_m3s": 4.5,
            "battery_voltage": 3.85,
            "timestamp": time.time()
        }
        res = ingest_telemetry(payload)
        self.assertEqual(res["status"], "ACCEPTED")
        self.assertEqual(res["device_id"], "ESP32_SN_001")
        self.assertEqual(res["water_level_cm"], 35.0)

    def test_pump_recommendations_generation(self):
        recs = evaluate_pump_recommendations()
        self.assertIsInstance(recs, list)

if __name__ == "__main__":
    unittest.main()
