"""
Authentication and Role-Based Access Control (RBAC) for Indore Flood Intelligence (IFI).
Provides token issuance, demo sessions, and permission verification.
"""

import hmac
import hashlib
import base64
import json
import time
from typing import Dict, Any, Optional
from .database import get_connection

SECRET_KEY = "indore-flood-intelligence-secret-key-prod-2026"

ROLE_PERMISSIONS = {
    "citizen": ["read_flood_status", "read_shelters", "read_alerts", "plan_routes", "submit_sos", "report_incident", "track_sos"],
    "municipal": ["read_flood_status", "read_shelters", "read_alerts", "plan_routes", "submit_sos", "report_incident", "track_sos", "simulate_scenarios", "manage_assets", "view_all_incidents", "verify_incidents", "dispatch_units", "broadcast_alerts", "view_audit_logs", "execute_pump_recommendations"],
    "field_engineer": ["read_flood_status", "read_shelters", "read_alerts", "plan_routes", "view_work_orders", "update_work_orders", "submit_inspections", "view_sensor_diagnostics", "report_faults"],
    "firefighter": ["read_flood_status", "read_shelters", "read_alerts", "plan_routes", "view_dispatch_queue", "accept_incident", "update_rescue_status", "view_emergency_routes"],
}

def create_access_token(user_id: str, email: str, role: str, full_name: str, org: str) -> str:
    """Generates a secure HMAC-SHA256 signed token."""
    header = {"alg": "HS256", "typ": "JWT"}
    payload = {
        "sub": user_id,
        "email": email,
        "role": role,
        "name": full_name,
        "org": org,
        "iat": int(time.time()),
        "exp": int(time.time()) + (86400 * 7) # 7 days
    }
    
    def b64_encode(d: Dict[str, Any]) -> str:
        s = json.dumps(d, separators=(',', ':')).encode('utf-8')
        return base64.urlsafe_b64encode(s).decode('utf-8').rstrip('=')
        
    h_b64 = b64_encode(header)
    p_b64 = b64_encode(payload)
    sig = hmac.new(SECRET_KEY.encode('utf-8'), f"{h_b64}.{p_b64}".encode('utf-8'), hashlib.sha256).digest()
    sig_b64 = base64.urlsafe_b64encode(sig).decode('utf-8').rstrip('=')
    return f"{h_b64}.{p_b64}.{sig_b64}"

def verify_token(token: str) -> Optional[Dict[str, Any]]:
    """Verifies HMAC signature and expiration."""
    try:
        parts = token.split('.')
        if len(parts) != 3:
            return None
        h_b64, p_b64, sig_b64 = parts
        expected_sig = hmac.new(SECRET_KEY.encode('utf-8'), f"{h_b64}.{p_b64}".encode('utf-8'), hashlib.sha256).digest()
        calc_sig_b64 = base64.urlsafe_b64encode(expected_sig).decode('utf-8').rstrip('=')
        if not hmac.compare_digest(sig_b64, calc_sig_b64):
            return None
            
        # Decode payload
        rem = len(p_b64) % 4
        if rem > 0:
            p_b64 += '=' * (4 - rem)
        payload = json.loads(base64.urlsafe_b64decode(p_b64.encode('utf-8')).decode('utf-8'))
        
        if payload.get("exp", 0) < time.time():
            return None
            
        return payload
    except Exception:
        return None

def check_permission(user_role: str, permission: str) -> bool:
    """Checks if a user role has the required permission."""
    perms = ROLE_PERMISSIONS.get(user_role, [])
    return permission in perms

def authenticate_user(email: str, password_raw: str) -> Optional[Dict[str, Any]]:
    """Authenticates against the users table."""
    conn = get_connection()
    cursor = conn.cursor()
    pw_hash = hashlib.sha256(password_raw.encode('utf-8')).hexdigest()
    cursor.execute("SELECT * FROM users WHERE email = ? AND password_hash = ?", (email, pw_hash))
    row = cursor.fetchone()
    conn.close()
    if row:
        return dict(row)
    return None

def create_demo_user(role: str) -> Dict[str, Any]:
    """Generates an authentic demo session for one of the four roles."""
    demo_profiles = {
        "citizen": {
            "id": "demo_citizen",
            "email": "demo.citizen@indore.gov.in",
            "name": "Pooja Sharma (Citizen Demo)",
            "role": "citizen",
            "org": "Indore Citizen Portal (Ward 24)"
        },
        "municipal": {
            "id": "demo_municipal",
            "email": "demo.municipal@indore.gov.in",
            "name": "Dr. Anil Gupta (Disaster Officer Demo)",
            "role": "municipal",
            "org": "Indore Municipal Corporation (IMC) Disaster Cell"
        },
        "field_engineer": {
            "id": "demo_engineer",
            "email": "demo.engineer@indore.gov.in",
            "name": "Vikram Singh (Drainage Engineer Demo)",
            "role": "field_engineer",
            "org": "IMC Drainage & Storm Sewerage Division"
        },
        "firefighter": {
            "id": "demo_firefighter",
            "email": "demo.fire@indore.gov.in",
            "name": "Suresh Rathore (Fire Rescue Demo)",
            "role": "firefighter",
            "org": "Indore Fire & Emergency Rescue Service"
        }
    }
    
    prof = demo_profiles.get(role, demo_profiles["citizen"])
    token = create_access_token(prof["id"], prof["email"], prof["role"], prof["name"], prof["org"])
    return {
        "access_token": token,
        "token_type": "bearer",
        "user": prof
    }
