import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  ShieldAlert, Droplets, Waves, Sun, Moon, AlertTriangle,
  User as UserIcon, LogOut, RefreshCw, ChevronDown, Radio, Activity,
  Sparkles
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useTheme } from '../../context/ThemeContext';
import { useFloodData } from '../../context/FloodDataContext';
import { Role } from '../../types';
import { AIAssistantModal } from '../common/AIAssistantModal';

export const Navbar: React.FC = () => {
  const { user, role, switchDemoRole, logout, isAuthenticated } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const { floodStatus, isLoading, refreshData } = useFloodData();
  const [roleMenuOpen, setRoleMenuOpen] = useState(false);
  const [aiModalOpen, setAiModalOpen] = useState(false);
  const navigate = useNavigate();

  const hazardColor = {
    LOW: 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20',
    MODERATE: 'bg-amber-500/10 text-amber-500 border-amber-500/20',
    HIGH: 'bg-orange-500/10 text-orange-500 border-orange-500/20',
    CRITICAL: 'bg-rose-500/10 text-rose-500 border-rose-500/20 animate-pulse',
  }[floodStatus?.city_hazard_level || 'LOW'];

  const roleLabels: Record<Role, { name: string; badge: string; color: string }> = {
    citizen: { name: 'Citizen Portal', badge: 'Public', color: 'bg-sky-500/10 text-sky-400 border-sky-500/30' },
    municipal: { name: 'Municipal Command', badge: 'Disaster Cell', color: 'bg-indigo-500/10 text-indigo-400 border-indigo-500/30' },
    field_engineer: { name: 'Field Engineer', badge: 'Drainage Tech', color: 'bg-amber-500/10 text-amber-400 border-amber-500/30' },
    firefighter: { name: 'Fire & Rescue', badge: 'Emergency 101', color: 'bg-rose-500/10 text-rose-400 border-rose-500/30' },
  };

  const handleRoleSelect = async (r: Role) => {
    setRoleMenuOpen(false);
    await switchDemoRole(r);
    if (r === 'citizen') navigate('/dashboard/citizen');
    else if (r === 'municipal') navigate('/dashboard/municipal');
    else if (r === 'field_engineer') navigate('/dashboard/field-engineer');
    else if (r === 'firefighter') navigate('/dashboard/firefighter');
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b border-slate-200 dark:border-slate-800 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        
        {/* Left: Brand Identity */}
        <div className="flex items-center gap-3">
          <Link to="/" className="flex items-center gap-2.5 group">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-sky-600 via-blue-600 to-indigo-600 flex items-center justify-center text-white shadow-lg shadow-sky-500/20 group-hover:scale-105 transition-transform">
              <Waves className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-lg tracking-tight bg-gradient-to-r from-sky-600 to-indigo-600 dark:from-sky-400 dark:to-indigo-400 bg-clip-text text-transparent">
                  INDORE FLOOD INTEL
                </span>
                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded uppercase tracking-wider bg-sky-100 text-sky-800 dark:bg-sky-950 dark:text-sky-300">
                  SaaS 2.0
                </span>
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 font-medium leading-none">
                IMC Predictive Drainage Twin
              </p>
            </div>
          </Link>

          {/* Live City Hazard Badge */}
          {floodStatus && (
            <div className={`hidden md:flex items-center gap-2 ml-4 px-2.5 py-1 rounded-full border text-xs font-semibold ${hazardColor}`}>
              <Radio className="w-3.5 h-3.5 animate-ping" />
              <span>{floodStatus.city_hazard_level} RISK</span>
              <span className="opacity-40">|</span>
              <span>{floodStatus.rainfall_rate_mmh.toFixed(1)} mm/h</span>
            </div>
          )}
        </div>

        {/* Right: Controls & Role Switcher */}
        <div className="flex items-center gap-2 sm:gap-3">
          
          {/* Quick Refresh */}
          <button
            onClick={() => refreshData()}
            title="Refresh Live Telemetry"
            className={`p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors ${isLoading ? 'animate-spin text-sky-500' : ''}`}
          >
            <RefreshCw className="w-4 h-4" />
          </button>

          {/* AI Copilot Quick Button */}
          <button
            onClick={() => setAiModalOpen(true)}
            title="Open Indore Flood AI Copilot (OpenAI Powered)"
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-gradient-to-r from-sky-500/10 via-indigo-500/10 to-purple-500/10 hover:from-sky-500/20 hover:to-indigo-500/20 text-sky-600 dark:text-sky-400 border border-sky-500/30 transition-all shadow-sm"
          >
            <Sparkles className="w-3.5 h-3.5 text-sky-500 animate-pulse" />
            <span className="hidden sm:inline">AI Copilot</span>
          </button>

          {/* Digital Twin Quick Link */}
          <Link
            to="/digital-twin"
            className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-700 transition-colors"
          >
            <Activity className="w-3.5 h-3.5 text-sky-500" />
            <span>3D Digital Twin</span>
          </Link>

          {/* Theme Toggle */}
          <button
            onClick={toggleTheme}
            className="p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title={`Switch to ${theme === 'dark' ? 'Light' : 'Dark'} Mode`}
          >
            {theme === 'dark' ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-indigo-500" />}
          </button>

          {/* Role Switcher Dropdown */}
          <div className="relative">
            <button
              onClick={() => setRoleMenuOpen(!roleMenuOpen)}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border text-xs font-semibold transition-all ${roleLabels[role]?.color || ''}`}
            >
              <span className="hidden sm:inline">{roleLabels[role]?.name}</span>
              <span className="sm:hidden uppercase">{role}</span>
              <span className="text-[10px] opacity-70 px-1 py-0.2 rounded bg-white/20 dark:bg-black/20">
                {roleLabels[role]?.badge}
              </span>
              <ChevronDown className="w-3.5 h-3.5 opacity-70" />
            </button>

            {roleMenuOpen && (
              <div className="absolute right-0 mt-2 w-56 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xl shadow-black/10 py-1.5 z-50 animate-in fade-in slide-in-from-top-2">
                <div className="px-3 py-1.5 border-b border-slate-100 dark:border-slate-800">
                  <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Switch Persona Demo</p>
                </div>
                {(['citizen', 'municipal', 'field_engineer', 'firefighter'] as Role[]).map((r) => (
                  <button
                    key={r}
                    onClick={() => handleRoleSelect(r)}
                    className={`w-full text-left px-3 py-2 text-xs flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-800/60 transition-colors ${role === r ? 'font-bold text-sky-500 dark:text-sky-400' : 'text-slate-700 dark:text-slate-200'}`}
                  >
                    <span>{roleLabels[r].name}</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-500">
                      {roleLabels[r].badge}
                    </span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* User Profile / Logout */}
          {user ? (
            <div className="flex items-center gap-1.5">
              <Link
                to="/profile"
                className="p-1.5 rounded-lg text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
                title={`Logged in as ${user.name}`}
              >
                <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-sky-500 to-indigo-600 flex items-center justify-center text-white text-xs font-bold">
                  {user.name.charAt(0)}
                </div>
              </Link>
              <button
                onClick={logout}
                className="p-2 text-slate-400 hover:text-rose-500 hover:bg-rose-500/10 rounded-lg transition-colors"
                title="Log out"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <Link
              to="/login"
              className="px-3 py-1.5 text-xs font-medium text-white bg-sky-600 hover:bg-sky-500 rounded-lg shadow-sm transition-colors"
            >
              Sign In
            </Link>
          )}

        </div>
      </div>

      {/* Indore Flood AI Copilot Modal */}
      <AIAssistantModal isOpen={aiModalOpen} onClose={() => setAiModalOpen(false)} />
    </header>
  );
};
