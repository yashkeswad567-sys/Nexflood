import React, { useState, useEffect, useRef } from 'react';
import {
  Sparkles, X, Send, Bot, User, RefreshCw, AlertTriangle,
  ShieldCheck, HelpCircle, ChevronRight, Zap
} from 'lucide-react';
import { api } from '../../services/api';
import { useFloodData } from '../../context/FloodDataContext';

interface Message {
  id: string;
  sender: 'ai' | 'user';
  text: string;
  model?: string;
  source?: string;
  timestamp: string;
}

interface AIAssistantModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AIAssistantModal: React.FC<AIAssistantModalProps> = ({ isOpen, onClose }) => {
  const { floodStatus } = useFloodData();
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      sender: 'ai',
      text: 'Namaste! I am the Indore Flood Intelligence Emergency AI Copilot powered by OpenAI. Ask me about real-time ward inundation, safe travel routes, emergency shelters, or drainage pump operations.',
      model: 'gpt-4o-mini',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [aiStatus, setAiStatus] = useState<{ configured: boolean; model: string; key_preview: string }>({
    configured: true,
    model: 'gpt-4o-mini',
    key_preview: 'sk-proj-p28K...ienoA'
  });
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    api.getAIStatus().then((status) => {
      setAiStatus(status);
    });
  }, []);

  useEffect(() => {
    if (isOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isOpen]);

  const handleSend = async (questionText?: string) => {
    const textToSend = questionText || input.trim();
    if (!textToSend || loading) return;

    const userMsg: Message = {
      id: `user_${Date.now()}`,
      sender: 'user',
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!questionText) setInput('');
    setLoading(true);

    try {
      const context = {
        rainfall_rate_mmh: floodStatus?.rainfall_rate_mmh || 32.5,
        city_hazard_level: floodStatus?.city_hazard_level || 'MODERATE',
        city_max_depth_cm: floodStatus?.city_max_depth_cm || 38.0,
        active_alerts_count: floodStatus?.active_alerts_count || 2
      };

      const result = await api.askAICopilot(textToSend, context);

      const aiMsg: Message = {
        id: `ai_${Date.now()}`,
        sender: 'ai',
        text: result.response,
        model: result.model || 'gpt-4o-mini',
        source: result.source,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages((prev) => [...prev, aiMsg]);
    } catch (err) {
      const errorMsg: Message = {
        id: `err_${Date.now()}`,
        sender: 'ai',
        text: 'I encountered an issue connecting to the emergency intelligence engine. In urgent situations, dial 101 for rescue boat dispatch or move to Holkar / Nehru Stadium shelters.',
        model: 'fail-safe',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setLoading(false);
    }
  };

  const quickQuestions = [
    'Is Rajwada & Sarafa flooded right now?',
    'Where is the nearest high-ground shelter?',
    'What is the safe route from Palasia to Vijay Nagar?',
    'Are Kahn River stormwater pumps operating?'
  ];

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/50 backdrop-blur-sm animate-in fade-in">
      <div className="relative w-full max-w-xl h-[600px] max-h-[90vh] flex flex-col rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden">
        
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-sky-500 to-indigo-600 flex items-center justify-center text-white shadow-md shadow-sky-500/20">
              <Bot className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">Indore Flood AI Copilot</h3>
                <span className="flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-500 border border-emerald-500/20">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                  OpenAI Active
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                Model: <span className="font-mono text-sky-500 font-semibold">{aiStatus.model}</span> • Key: <span className="font-mono text-slate-500">{aiStatus.key_preview}</span>
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-200/50 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Live Context Banner */}
        {floodStatus && (
          <div className="px-4 py-2 bg-sky-500/5 border-b border-sky-500/10 flex items-center justify-between text-[11px]">
            <span className="text-slate-500">Live Context:</span>
            <span className="font-semibold text-slate-700 dark:text-slate-300">
              {floodStatus.city_hazard_level} Risk • {floodStatus.rainfall_rate_mmh.toFixed(1)} mm/h • Max Depth {floodStatus.city_max_depth_cm.toFixed(1)}cm
            </span>
          </div>
        )}

        {/* Message Thread */}
        <div className="flex-1 p-4 overflow-y-auto space-y-3.5 text-xs">
          {messages.map((m) => (
            <div
              key={m.id}
              className={`flex gap-2.5 ${m.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {m.sender === 'ai' && (
                <div className="w-7 h-7 rounded-lg bg-sky-100 dark:bg-sky-950/80 text-sky-600 dark:text-sky-400 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <Bot className="w-4 h-4" />
                </div>
              )}

              <div
                className={`max-w-[82%] p-3 rounded-2xl shadow-sm ${
                  m.sender === 'user'
                    ? 'bg-sky-600 text-white rounded-tr-none'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 rounded-tl-none border border-slate-200/50 dark:border-slate-700/50'
                }`}
              >
                <p className="whitespace-pre-line leading-relaxed">{m.text}</p>
                <div className="flex items-center justify-between gap-2 mt-1.5 pt-1 text-[10px] opacity-70 border-t border-black/5 dark:border-white/5">
                  <span>{m.timestamp}</span>
                  {m.model && <span className="font-mono">{m.model}</span>}
                </div>
              </div>

              {m.sender === 'user' && (
                <div className="w-7 h-7 rounded-lg bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-300 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <User className="w-4 h-4" />
                </div>
              )}
            </div>
          ))}

          {loading && (
            <div className="flex gap-2.5 items-center text-slate-400 text-xs">
              <div className="w-7 h-7 rounded-lg bg-sky-100 dark:bg-sky-950/80 text-sky-600 flex items-center justify-center flex-shrink-0">
                <RefreshCw className="w-4 h-4 animate-spin" />
              </div>
              <span className="italic">Querying OpenAI Flood Copilot...</span>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Quick Question Chips */}
        <div className="px-3 py-2 bg-slate-50/70 dark:bg-slate-800/30 border-t border-slate-100 dark:border-slate-800 flex items-center gap-1.5 overflow-x-auto no-scrollbar">
          <span className="text-[10px] font-bold text-slate-400 uppercase flex-shrink-0 mr-1">Suggestions:</span>
          {quickQuestions.map((q, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(q)}
              className="flex-shrink-0 text-[11px] px-2.5 py-1 rounded-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-sky-500 text-slate-700 dark:text-slate-300 transition-colors"
            >
              {q}
            </button>
          ))}
        </div>

        {/* Input Bar */}
        <div className="p-3 bg-white dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800 flex items-center gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Ask about Indore flood zones, safe routes, or emergency help..."
            className="flex-1 px-3.5 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs focus:outline-none focus:border-sky-500 text-slate-900 dark:text-white"
          />
          <button
            onClick={() => handleSend()}
            disabled={!input.trim() || loading}
            className="p-2.5 rounded-xl bg-sky-600 hover:bg-sky-500 disabled:opacity-50 text-white shadow-md transition-colors"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>

      </div>
    </div>
  );
};
