"""
Flood-Aware Road Routing Engine for Indore Flood Intelligence (IFI).
Computes topological road network paths using dynamic impedance weights
that factor in localized water depths, road closures, and hazard penalties.
Provides safe primary routes, faster alternatives with flood hazard warnings,
and high-clearance emergency rescue routes.
"""

import math
import heapq
from typing import Dict, Any, List, Tuple, Optional
from .database import get_connection

DISCLAIMER_TEXT = (
    "EXPERIMENTAL ROUTING ADVISORY: Real-time water depths may change rapidly during "
    "heavy precipitation. Never attempt to drive or walk through standing water. Obey municipal barriers."
)

# Core Indore road junctions (Graph Nodes)
INDORE_JUNCTIONS = {
    "J_RAJWADA": {"name": "Rajwada Chowk", "lat": 22.7196, "lng": 75.8577},
    "J_SARAFA": {"name": "Sarafa Bazaar", "lat": 22.7180, "lng": 75.8550},
    "J_MALHARGANJ": {"name": "Malharganj Circle", "lat": 22.7230, "lng": 75.8520},
    "J_HIGH_COURT": {"name": "High Court Junction", "lat": 22.7240, "lng": 75.8720},
    "J_PALASIA": {"name": "Palasia Square", "lat": 22.7244, "lng": 75.8839},
    "J_VIJAY_NAGAR": {"name": "Vijay Nagar Square", "lat": 22.7533, "lng": 75.8937},
    "J_BHANWARKUAN": {"name": "Bhanwarkuan Square", "lat": 22.6926, "lng": 75.8676},
    "J_CHHAVANI": {"name": "Chhavani Chowk", "lat": 22.7121, "lng": 75.8643},
    "J_ANNAPURNA": {"name": "Annapurna Temple Square", "lat": 22.7012, "lng": 75.8398},
    "J_MHOW_NAKA": {"name": "Mhow Naka", "lat": 22.7130, "lng": 75.8480},
    "J_MR10": {"name": "MR 10 Junction", "lat": 22.7650, "lng": 75.8500},
    "J_REGIONAL_PARK": {"name": "Regional Park / Pipliyapala", "lat": 22.6789, "lng": 75.8540},
    "J_BENGALI": {"name": "Bengali Square (Ring Road)", "lat": 22.7150, "lng": 75.9050},
}

def haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Computes great-circle distance between two GPS coordinates in km."""
    r = 6371.0
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2.0)**2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlambda / 2.0)**2
    c = 2.0 * math.atan2(math.sqrt(a), math.sqrt(1.0 - a))
    return r * c

def find_nearest_junction(lat: float, lng: float) -> str:
    """Locates the closest road network graph node to a given lat/lng."""
    closest_node = "J_RAJWADA"
    min_dist = float('inf')
    for node_id, data in INDORE_JUNCTIONS.items():
        d = haversine_km(lat, lng, data["lat"], data["lng"])
        if d < min_dist:
            min_dist = d
            closest_node = node_id
    return closest_node

def build_road_graph() -> Dict[str, List[Dict[str, Any]]]:
    """
    Constructs an adjacency list graph using live road segment database state
    including water depth, blockage flags, and zone hazards.
    """
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM road_segments")
    roads = [dict(r) for r in cursor.fetchall()]
    conn.close()
    
    # Adjacency map
    graph: Dict[str, List[Dict[str, Any]]] = {k: [] for k in INDORE_JUNCTIONS}
    
    # Predefined topological connections in Indore
    edges = [
        ("J_RAJWADA", "J_SARAFA", 0.6, 25.0, "Sarafa Lane"),
        ("J_RAJWADA", "J_MALHARGANJ", 0.9, 30.0, "Jawahar Marg"),
        ("J_RAJWADA", "J_HIGH_COURT", 1.8, 35.0, "MG Road"),
        ("J_HIGH_COURT", "J_PALASIA", 1.4, 40.0, "Sardar Patel Marg"),
        ("J_PALASIA", "J_VIJAY_NAGAR", 3.8, 50.0, "AB Road North"),
        ("J_PALASIA", "J_BHANWARKUAN", 4.2, 45.0, "AB Road South"),
        ("J_PALASIA", "J_BENGALI", 2.5, 45.0, "Palasia-Bengali Link"),
        ("J_BENGALI", "J_BHANWARKUAN", 5.1, 55.0, "Ring Road Bypass"),
        ("J_BHANWARKUAN", "J_REGIONAL_PARK", 2.2, 40.0, "Khandwa Road Trunk"),
        ("J_BHANWARKUAN", "J_CHHAVANI", 2.8, 35.0, "Sapna Sangeeta Road"),
        ("J_CHHAVANI", "J_RAJWADA", 1.5, 30.0, "Chhavani Central"),
        ("J_RAJWADA", "J_MHOW_NAKA", 1.6, 35.0, "Mhow Naka Road"),
        ("J_MHOW_NAKA", "J_ANNAPURNA", 1.8, 40.0, "Annapurna Road"),
        ("J_ANNAPURNA", "J_REGIONAL_PARK", 3.5, 45.0, "Western Bypass Link"),
        ("J_VIJAY_NAGAR", "J_MR10", 3.2, 60.0, "MR 10 Highway"),
        ("J_MR10", "J_MALHARGANJ", 4.8, 45.0, "Airport Road Feeder"),
        ("J_VIJAY_NAGAR", "J_BENGALI", 4.5, 50.0, "Eastern Ring Road"),
    ]
    
    # Map road water depths from database
    depth_by_road: Dict[str, float] = {}
    blocked_by_road: Dict[str, bool] = {}
    for r in roads:
        depth_by_road[r["id"]] = r["current_water_depth_cm"]
        blocked_by_road[r["id"]] = bool(r["is_blocked"])
        
    for u, v, dist, speed, name in edges:
        # Check if connected to low-elevation waterlogged zones
        water_depth = 0.0
        if "RAJWADA" in u or "RAJWADA" in v or "SARAFA" in u or "SARAFA" in v:
            water_depth = depth_by_road.get("ROAD_01", 38.0)
        elif "CHHAVANI" in u or "CHHAVANI" in v:
            water_depth = depth_by_road.get("ROAD_08", 32.0)
        elif "BHANWARKUAN" in u or "BHANWARKUAN" in v:
            water_depth = depth_by_road.get("ROAD_03", 28.0)
        elif "VIJAY_NAGAR" in u or "VIJAY_NAGAR" in v:
            water_depth = depth_by_road.get("ROAD_04", 12.0)
            
        edge_data_fwd = {
            "to": v,
            "dist_km": dist,
            "speed_kmh": speed,
            "name": name,
            "water_depth_cm": water_depth,
            "is_blocked": water_depth >= 35.0
        }
        edge_data_rev = {
            "to": u,
            "dist_km": dist,
            "speed_kmh": speed,
            "name": name,
            "water_depth_cm": water_depth,
            "is_blocked": water_depth >= 35.0
        }
        graph[u].append(edge_data_fwd)
        graph[v].append(edge_data_rev)
        
    return graph

def dijkstra_route(
    start_node: str,
    target_node: str,
    graph: Dict[str, List[Dict[str, Any]]],
    mode: str = "safe" # 'safe', 'shortest', 'rescue'
) -> Optional[Tuple[List[str], float, float, float]]:
    """
    Finds route using Dijkstra with mode-specific impedance cost:
    - 'safe': heavy quadratic penalty for water depth, impassable (>35cm) blocked.
    - 'shortest': ignores flood depth, finds shortest distance.
    - 'rescue': high clearance vehicle / rescue boat can navigate water up to 60cm.
    """
    queue: List[Tuple[float, str, List[str], float, float]] = [(0.0, start_node, [start_node], 0.0, 0.0)]
    visited: Dict[str, float] = {}
    
    while queue:
        cost, curr, path, total_dist, max_depth = heapq.heappop(queue)
        
        if curr == target_node:
            return path, total_dist, (total_dist / 35.0) * 60.0, max_depth
            
        if curr in visited and visited[curr] <= cost:
            continue
        visited[curr] = cost
        
        for edge in graph.get(curr, []):
            nxt = edge["to"]
            dist = edge["dist_km"]
            depth = edge["water_depth_cm"]
            
            # Impedance penalty calculation
            if mode == "safe":
                if edge["is_blocked"] or depth >= 35.0:
                    continue  # Strictly avoid impassable roads
                # Exponential penalty as water depth increases
                hazard_penalty = 1.0 + (depth / 15.0) ** 2.2
                edge_cost = dist * hazard_penalty
            elif mode == "rescue":
                if depth >= 75.0:
                    continue  # Only absolute inundation blocks rescue boat
                edge_cost = dist * (1.0 + (depth / 50.0))
            else:  # shortest
                edge_cost = dist
                
            new_max_depth = max(max_depth, depth)
            heapq.heappush(queue, (cost + edge_cost, nxt, path + [nxt], total_dist + dist, new_max_depth))
            
    return None

def calculate_flood_aware_route(
    origin_lat: float,
    origin_lng: float,
    dest_lat: float,
    dest_lng: float,
    travel_mode: str = "vehicle"
) -> Dict[str, Any]:
    """
    Main route calculation endpoint. Returns primary safe route and alternatives.
    """
    graph = build_road_graph()
    start_node = find_nearest_junction(origin_lat, origin_lng)
    target_node = find_nearest_junction(dest_lat, dest_lng)
    
    # 1. Primary Safe Route
    safe_result = dijkstra_route(start_node, target_node, graph, mode="safe")
    
    # Fallback to rescue route if all ordinary roads are inundated
    if not safe_result:
        safe_result = dijkstra_route(start_node, target_node, graph, mode="rescue")
        is_rescue_fallback = True
    else:
        is_rescue_fallback = False
        
    # 2. Shortest Alternative (even if flooded)
    shortest_result = dijkstra_route(start_node, target_node, graph, mode="shortest")
    
    def nodes_to_coords(node_list: List[str]) -> List[List[float]]:
        coords = []
        for n in node_list:
            coords.append([INDORE_JUNCTIONS[n]["lat"], INDORE_JUNCTIONS[n]["lng"]])
        return coords
        
    def generate_turn_by_turn(node_list: List[str]) -> List[str]:
        turns = []
        for i in range(len(node_list) - 1):
            u, v = node_list[i], node_list[i+1]
            u_name = INDORE_JUNCTIONS[u]["name"]
            v_name = INDORE_JUNCTIONS[v]["name"]
            turns.append(f"Proceed from {u_name} toward {v_name}")
        turns.append(f"Arrive at destination near {INDORE_JUNCTIONS[node_list[-1]]['name']}")
        return turns

    primary_path, primary_dist, primary_mins, primary_depth = safe_result if safe_result else ([start_node, target_node], 5.0, 15.0, 0.0)
    
    primary_hazard_score = round(min(100.0, (primary_depth / 45.0) * 100.0), 1)
    
    alternatives = []
    if shortest_result and shortest_result[0] != primary_path:
        alt_path, alt_dist, alt_mins, alt_depth = shortest_result
        alt_hazard = round(min(100.0, (alt_depth / 45.0) * 100.0), 1)
        warning_msg = (
            f"Passes through {alt_depth:.1f}cm standing water near historic basin. High stalling risk!"
            if alt_depth > 25.0 else "Minor surface runoff along route."
        )
        alternatives.append({
            "route_id": "rt_alt_shortest",
            "name": "Shortest Direct Route (Higher Flood Risk)",
            "distance_km": round(alt_dist, 2),
            "estimated_minutes": round(alt_mins, 1),
            "max_flood_depth_cm": round(alt_depth, 1),
            "hazard_risk_score": alt_hazard,
            "warning": warning_msg,
            "path_coordinates": nodes_to_coords(alt_path),
            "turn_by_turn": generate_turn_by_turn(alt_path)
        })
        
    return {
        "origin": {"lat": origin_lat, "lng": origin_lng, "nearest_node": INDORE_JUNCTIONS[start_node]["name"]},
        "destination": {"lat": dest_lat, "lng": dest_lng, "nearest_node": INDORE_JUNCTIONS[target_node]["name"]},
        "primary_route": {
            "route_id": "rt_primary_safe",
            "name": "Flood-Aware Safe Route (Avoids Inundated Wards)",
            "distance_km": round(primary_dist, 2),
            "estimated_minutes": round(primary_mins, 1),
            "max_flood_depth_cm": round(primary_depth, 1),
            "hazard_risk_score": primary_hazard_score,
            "is_emergency_clearance_required": is_rescue_fallback,
            "path_coordinates": nodes_to_coords(primary_path),
            "turn_by_turn": generate_turn_by_turn(primary_path)
        },
        "alternative_routes": alternatives,
        "disclaimer": DISCLAIMER_TEXT
    }
