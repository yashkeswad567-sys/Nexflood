"""
Database management layer for Indore Flood Intelligence (IFI).
Provides SQLite persistent storage with JSON serialization, thread-safety,
and seamless PostGIS-compatible geometry abstractions.
"""

import sqlite3
import json
import os
import threading
from datetime import datetime
from typing import List, Dict, Any, Optional

DB_FILE = os.path.join(os.path.dirname(os.path.dirname(__file__)), "indore_flood.db")
_lock = threading.RLock()

def get_connection() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_FILE, check_same_thread=False, timeout=15.0)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    """Create all relational tables and indexes."""
    with _lock:
        conn = get_connection()
        cursor = conn.cursor()
        
        # 1. Users
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id TEXT PRIMARY KEY,
                email TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                full_name TEXT NOT NULL,
                role TEXT NOT NULL,
                phone TEXT,
                organization TEXT,
                created_at TEXT NOT NULL
            )
        """)
        
        # 2. Catchment Zones
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS catchment_zones (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                description TEXT,
                centroid_lat REAL NOT NULL,
                centroid_lng REAL NOT NULL,
                elevation_m REAL NOT NULL,
                catchment_area_km2 REAL NOT NULL,
                impervious_surface_ratio REAL NOT NULL,
                soil_curve_number REAL NOT NULL,
                drainage_capacity_m3s REAL NOT NULL,
                polygon_geojson TEXT NOT NULL,
                current_hazard_level TEXT DEFAULT 'LOW',
                current_water_depth_cm REAL DEFAULT 0.0,
                soil_saturation_pct REAL DEFAULT 45.0,
                updated_at TEXT NOT NULL
            )
        """)
        
        # 3. Sensor Devices
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS sensor_devices (
                id TEXT PRIMARY KEY,
                zone_id TEXT NOT NULL,
                name TEXT NOT NULL,
                sensor_type TEXT NOT NULL,
                latitude REAL NOT NULL,
                longitude REAL NOT NULL,
                warning_threshold_cm REAL DEFAULT 30.0,
                critical_threshold_cm REAL DEFAULT 50.0,
                is_active INTEGER DEFAULT 1,
                battery_pct REAL DEFAULT 98.0,
                current_water_level_cm REAL DEFAULT 12.0,
                current_flow_rate_m3s REAL DEFAULT 2.1,
                last_heartbeat TEXT NOT NULL,
                FOREIGN KEY (zone_id) REFERENCES catchment_zones (id)
            )
        """)
        
        # 4. Sensor Telemetry
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS sensor_telemetry (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                device_id TEXT NOT NULL,
                timestamp TEXT NOT NULL,
                water_level_cm REAL NOT NULL,
                flow_rate_m3s REAL,
                rainfall_rate_mmh REAL,
                battery_v REAL,
                is_valid INTEGER DEFAULT 1,
                FOREIGN KEY (device_id) REFERENCES sensor_devices (id)
            )
        """)
        
        # 5. Drainage Assets
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS drainage_assets (
                id TEXT PRIMARY KEY,
                zone_id TEXT NOT NULL,
                name TEXT NOT NULL,
                asset_type TEXT NOT NULL,
                latitude REAL NOT NULL,
                longitude REAL NOT NULL,
                rated_capacity_m3s REAL NOT NULL,
                current_status TEXT DEFAULT 'OPERATIONAL',
                silt_blockage_pct REAL DEFAULT 15.0,
                last_inspected_at TEXT NOT NULL,
                FOREIGN KEY (zone_id) REFERENCES catchment_zones (id)
            )
        """)
        
        # 6. Incidents & SOS
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS incidents (
                id TEXT PRIMARY KEY,
                tracking_code TEXT UNIQUE NOT NULL,
                reported_by_name TEXT,
                phone TEXT,
                incident_type TEXT NOT NULL,
                latitude REAL NOT NULL,
                longitude REAL NOT NULL,
                landmark_address TEXT,
                severity TEXT NOT NULL,
                people_stranded INTEGER DEFAULT 0,
                medical_emergency INTEGER DEFAULT 0,
                status TEXT DEFAULT 'REPORTED',
                assigned_unit TEXT,
                assigned_personnel_id TEXT,
                notes TEXT,
                resolution_notes TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )
        """)
        
        # 7. Work Orders
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS work_orders (
                id TEXT PRIMARY KEY,
                asset_id TEXT NOT NULL,
                assigned_to TEXT,
                title TEXT NOT NULL,
                description TEXT,
                priority TEXT DEFAULT 'ROUTINE',
                status TEXT DEFAULT 'PENDING',
                initial_silt_pct REAL,
                final_silt_pct REAL,
                inspection_notes TEXT,
                created_at TEXT NOT NULL,
                completed_at TEXT,
                FOREIGN KEY (asset_id) REFERENCES drainage_assets (id)
            )
        """)
        
        # 8. Road Segments
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS road_segments (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                zone_id TEXT NOT NULL,
                start_lat REAL NOT NULL,
                start_lng REAL NOT NULL,
                end_lat REAL NOT NULL,
                end_lng REAL NOT NULL,
                length_km REAL NOT NULL,
                base_speed_kmh REAL DEFAULT 40.0,
                elevation_m REAL NOT NULL,
                current_water_depth_cm REAL DEFAULT 0.0,
                is_blocked INTEGER DEFAULT 0,
                FOREIGN KEY (zone_id) REFERENCES catchment_zones (id)
            )
        """)
        
        # 9. Pump Recommendations
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS pump_recommendations (
                id TEXT PRIMARY KEY,
                asset_id TEXT NOT NULL,
                zone_id TEXT NOT NULL,
                recommended_action TEXT NOT NULL,
                urgency TEXT NOT NULL,
                rationale TEXT NOT NULL,
                inflow_rate_m3s REAL NOT NULL,
                status TEXT DEFAULT 'PENDING',
                operator_override_notes TEXT,
                created_at TEXT NOT NULL,
                FOREIGN KEY (asset_id) REFERENCES drainage_assets (id)
            )
        """)
        
        # 10. Emergency Shelters
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS emergency_shelters (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                latitude REAL NOT NULL,
                longitude REAL NOT NULL,
                address TEXT NOT NULL,
                capacity INTEGER NOT NULL,
                current_occupancy INTEGER DEFAULT 0,
                contact_phone TEXT,
                facilities TEXT NOT NULL,
                is_active INTEGER DEFAULT 1
            )
        """)
        
        # 11. Alerts & Broadcasts
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS alerts (
                id TEXT PRIMARY KEY,
                title TEXT NOT NULL,
                severity TEXT NOT NULL,
                target_zones TEXT NOT NULL,
                message TEXT NOT NULL,
                instructions TEXT NOT NULL,
                created_at TEXT NOT NULL,
                expires_at TEXT NOT NULL,
                is_active INTEGER DEFAULT 1
            )
        """)
        
        # 12. Audit Logs
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS audit_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_name TEXT,
                role TEXT,
                action TEXT NOT NULL,
                entity_type TEXT NOT NULL,
                entity_id TEXT NOT NULL,
                details TEXT,
                timestamp TEXT NOT NULL
            )
        """)
        
        # 13. System State (Current Simulation Scenario)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS system_state (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )
        """)
        
        conn.commit()
        conn.close()

def log_audit(action: str, entity_type: str, entity_id: str, details: str = "", user_name: str = "System", role: str = "system"):
    """Thread-safe audit logging helper."""
    with _lock:
        try:
            conn = get_connection()
            conn.execute(
                "INSERT INTO audit_logs (user_name, role, action, entity_type, entity_id, details, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (user_name, role, action, entity_type, entity_id, details, datetime.utcnow().isoformat())
            )
            conn.commit()
            conn.close()
        except Exception as e:
            print(f"[AUDIT LOG ERROR] {e}")
