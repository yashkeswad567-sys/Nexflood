import React from 'react';
import { IndoreDigitalTwin3D } from '../components/3d/IndoreDigitalTwin3D';

export const DigitalTwinPage: React.FC = () => {
  return (
    <div className="w-full">
      <IndoreDigitalTwin3D />
    </div>
  );
};
