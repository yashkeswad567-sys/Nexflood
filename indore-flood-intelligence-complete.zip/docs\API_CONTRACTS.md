# API CONTRACTS — INDORE FLOOD INTELLIGENCE (IFI)

Base URL: `/api/v1`

## 1. Authentication & Session Endpoints

### `POST /api/v1/auth/login`
- **Request**:
  ```json
  {
    "email": "user@indore.gov.in",
    "password": "secure_password",
    "role": "municipal" // citizen | municipal | field_engineer | firefighter
  }
  ```
- **Response** (200 OK):
  ```json
  {
    "access_token": "jwt_token_string",
    "token_type": "bearer",
    "user": {
      "id": "usr_01",
      "name": "Rajesh Sharma",
      "email": "sharma@indore.gov.in",
      "role": "municipal",
      "organization": "Indore Municipal Corporation (IMC)"
    }
  }
  ```

### `POST /api/v1/auth/demo-session`
- One-click demo login that creates a sandbox session without requiring credentials.
- **Request**: `{ "role": "citizen" | "municipal" | "field_engineer" | "firefighter" }`
- **Response**: `{ "access_token": "demo_token_...", "user": { ... } }`

---

## 2. Flood Prediction & Hydrology Endpoints

### `GET /api/v1/flood/current-status`
- **Response** (200 OK):
  ```json
  {
    "timestamp": "2026-11-01T04:30:00Z",
    "city_hazard_level": "MODERATE",
    "rainfall_current_mmh": 32.5,
    "rainfall_24h_accum_mm": 68.2,
    "zones": [
      {
        "zone_id": "zone_rajwada",
        "name": "Rajwada & Historic Basin",
        "hazard_level": "HIGH",
        "water_depth_cm": 42.0,
        "soil_saturation_pct": 82.0,
        "drainage_capacity_util_pct": 88.5,
        "forecast": {
          "1h_depth_cm": 54.0,
          "2h_depth_cm": 61.0,
          "3h_depth_cm": 48.0,
          "confidence_pct": 89.2
        }
      }
    ]
  }
  ```

### `POST /api/v1/flood/simulate-scenario`
- **Request**:
  ```json
  {
    "scenario_name": "Cloudburst",
    "rainfall_intensity_mmh": 85.0,
    "duration_hours": 2.0,
    "soil_moisture_initial_pct": 75.0
  }
  ```
- **Response**: Full zone predictions for 1h, 2h, and 3h horizons with affected road segments and pump activation recommendations.

---

## 3. Flood-Aware Navigation Endpoints

### `POST /api/v1/routing/calculate`
- **Request**:
  ```json
  {
    "origin": { "lat": 22.7196, "lng": 75.8577, "label": "Rajwada" },
    "destination": { "lat": 22.7533, "lng": 75.8937, "label": "Vijay Nagar" },
    "travel_mode": "vehicle", // vehicle | rescue_boat | walking
    "avoid_high_hazard": true
  }
  ```
- **Response** (200 OK):
  ```json
  {
    "primary_route": {
      "route_id": "rt_safe_01",
      "distance_km": 7.4,
      "estimated_minutes": 22.5,
      "max_flood_depth_cm": 8.0,
      "hazard_risk_score": 12.0,
      "path_coordinates": [[22.7196, 75.8577], [22.7245, 75.8650], "..."],
      "turn_by_turn": ["Depart north on MG Road", "Turn right onto AB Road Bypass"]
    },
    "alternative_routes": [
      {
        "route_id": "rt_fastest_flooded",
        "distance_km": 5.8,
        "estimated_minutes": 18.0,
        "max_flood_depth_cm": 52.0,
        "hazard_risk_score": 78.0,
        "warning": "Passes through inundated Bhanwarkuan junction (52cm water)"
      }
    ],
    "disclaimer": "Advisory only. Experimental routing. Never drive into standing water."
  }
  ```

---

## 4. Emergency Incidents & SOS Endpoints

### `POST /api/v1/incidents/sos`
- **Request**:
  ```json
  {
    "citizen_name": "Pooja Verma",
    "phone": "+91 98260 12345",
    "location": { "lat": 22.7180, "lng": 75.8550, "address": "Sarafa Bazaar, Shop #4" },
    "people_stranded": 3,
    "has_medical_emergency": true,
    "severity": "CRITICAL",
    "notes": "Water rising above knee level, elderly grandmother present"
  }
  ```
- **Response** (201 Created):
  ```json
  {
    "incident_id": "inc_sos_101",
    "tracking_code": "IND-SOS-9941",
    "status": "DISPATCHED",
    "assigned_unit": "Palasia Fire Station - Rescue Boat 2",
    "estimated_arrival_minutes": 14,
    "created_at": "2026-11-01T04:32:00Z"
  }
  ```

### `GET /api/v1/incidents`
- Lists all active incidents with filter by `status`, `severity`, or `assigned_unit`.

### `PATCH /api/v1/incidents/{incident_id}/status`
- **Request**: `{ "status": "ON_SCENE", "notes": "Boat deployed, extracting family" }`

---

## 5. IoT Telemetry Endpoints

### `POST /api/v1/iot/telemetry`
- ESP32 hardware telemetry ingestion endpoint.
- **Request**:
  ```json
  {
    "device_id": "ESP32_SN_KAHN_001",
    "sensor_type": "ultrasonic_water_level",
    "location_zone": "zone_rajwada",
    "water_level_cm": 44.8,
    "flow_rate_m3s": 14.2,
    "battery_voltage": 3.82,
    "timestamp": 1793452200
  }
  ```
- **Validation**:
  - `water_level_cm` must be between 0 and 500 cm.
  - Reject timestamps older than 2 hours or in the future.
  - If delta > 100 cm/min, flag anomaly for inspection.
