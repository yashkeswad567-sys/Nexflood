# DATABASE DESIGN & SCHEMA — INDORE FLOOD INTELLIGENCE

Compatible with both PostgreSQL + PostGIS (Production) and SQLite with Spatial Geometry fallback (Local Zero-Config).

## 1. Relational Schema & Tables

### 1.1 `users`
- `id`: VARCHAR(36) PRIMARY KEY
- `email`: VARCHAR(255) UNIQUE NOT NULL
- `hashed_password`: VARCHAR(255) NOT NULL
- `full_name`: VARCHAR(255) NOT NULL
- `role`: VARCHAR(32) NOT NULL -- 'citizen', 'municipal', 'field_engineer', 'firefighter'
- `phone`: VARCHAR(32)
- `organization`: VARCHAR(255)
- `created_at`: TIMESTAMP DEFAULT CURRENT_TIMESTAMP

### 1.2 `catchment_zones`
- `id`: VARCHAR(32) PRIMARY KEY -- e.g. 'zone_rajwada'
- `name`: VARCHAR(128) NOT NULL
- `description`: TEXT
- `centroid_lat`: FLOAT NOT NULL
- `centroid_lng`: FLOAT NOT NULL
- `elevation_m`: FLOAT NOT NULL -- AMSL
- `catchment_area_km2`: FLOAT NOT NULL
- `impervious_surface_ratio`: FLOAT NOT NULL -- 0.0 to 1.0
- `soil_curve_number`: FLOAT NOT NULL -- SCS CN (e.g. 78 to 92)
- `drainage_capacity_m3s`: FLOAT NOT NULL
- `polygon_geojson`: TEXT NOT NULL -- GeoJSON Polygon coordinates

### 1.3 `sensor_devices`
- `id`: VARCHAR(32) PRIMARY KEY -- 'ESP32_SN_001'
- `zone_id`: VARCHAR(32) REFERENCES catchment_zones(id)
- `name`: VARCHAR(128) NOT NULL
- `sensor_type`: VARCHAR(64) -- 'ultrasonic_depth', 'doppler_flow', 'tipping_bucket_rain'
- `latitude`: FLOAT NOT NULL
- `longitude`: FLOAT NOT NULL
- `depth_warning_threshold_cm`: FLOAT DEFAULT 30.0
- `depth_critical_threshold_cm`: FLOAT DEFAULT 50.0
- `is_active`: BOOLEAN DEFAULT TRUE
- `battery_pct`: FLOAT DEFAULT 100.0
- `last_heartbeat`: TIMESTAMP

### 1.4 `sensor_telemetry`
- `id`: INTEGER PRIMARY KEY AUTOINCREMENT
- `device_id`: VARCHAR(32) REFERENCES sensor_devices(id)
- `timestamp`: TIMESTAMP NOT NULL
- `water_level_cm`: FLOAT NOT NULL
- `flow_rate_m3s`: FLOAT
- `rainfall_rate_mmh`: FLOAT
- `battery_v`: FLOAT
- `is_valid`: BOOLEAN DEFAULT TRUE

### 1.5 `drainage_assets`
- `id`: VARCHAR(32) PRIMARY KEY -- 'PUMP_KAHN_01'
- `zone_id`: VARCHAR(32) REFERENCES catchment_zones(id)
- `name`: VARCHAR(128) NOT NULL
- `asset_type`: VARCHAR(64) -- 'stormwater_pump', 'sluice_gate', 'culvert', 'retention_basin'
- `latitude`: FLOAT NOT NULL
- `longitude`: FLOAT NOT NULL
- `rated_capacity_m3s`: FLOAT NOT NULL
- `current_status`: VARCHAR(32) -- 'OPERATIONAL', 'RUNNING', 'DEGRADED', 'FAULT'
- `silt_blockage_pct`: FLOAT DEFAULT 15.0
- `last_inspected_at`: TIMESTAMP

### 1.6 `incidents`
- `id`: VARCHAR(36) PRIMARY KEY
- `tracking_code`: VARCHAR(32) UNIQUE NOT NULL
- `reported_by_name`: VARCHAR(128)
- `phone`: VARCHAR(32)
- `incident_type`: VARCHAR(64) -- 'EMERGENCY_SOS', 'WATERLOGGING_REPORT', 'DRAIN_OVERFLOW', 'ROAD_BLOCKED'
- `latitude`: FLOAT NOT NULL
- `longitude`: FLOAT NOT NULL
- `landmark_address`: TEXT
- `severity`: VARCHAR(32) -- 'LOW', 'MODERATE', 'HIGH', 'CRITICAL'
- `people_stranded`: INTEGER DEFAULT 0
- `medical_emergency`: BOOLEAN DEFAULT FALSE
- `status`: VARCHAR(32) DEFAULT 'REPORTED' -- 'REPORTED', 'VERIFIED', 'DISPATCHED', 'ON_SCENE', 'RESOLVED'
- `assigned_unit`: VARCHAR(128)
- `assigned_personnel_id`: VARCHAR(36) REFERENCES users(id)
- `resolution_notes`: TEXT
- `created_at`: TIMESTAMP DEFAULT CURRENT_TIMESTAMP
- `updated_at`: TIMESTAMP DEFAULT CURRENT_TIMESTAMP

### 1.7 `work_orders`
- `id`: VARCHAR(36) PRIMARY KEY
- `asset_id`: VARCHAR(32) REFERENCES drainage_assets(id)
- `assigned_to`: VARCHAR(36) REFERENCES users(id)
- `title`: VARCHAR(255) NOT NULL
- `description`: TEXT
- `priority`: VARCHAR(32) -- 'ROUTINE', 'URGENT', 'EMERGENCY'
- `status`: VARCHAR(32) -- 'PENDING', 'IN_PROGRESS', 'COMPLETED'
- `initial_silt_pct`: FLOAT
- `final_silt_pct`: FLOAT
- `inspection_notes`: TEXT
- `completed_at`: TIMESTAMP

### 1.8 `road_segments`
- `id`: VARCHAR(32) PRIMARY KEY
- `name`: VARCHAR(128) NOT NULL
- `zone_id`: VARCHAR(32) REFERENCES catchment_zones(id)
- `start_lat`: FLOAT NOT NULL
- `start_lng`: FLOAT NOT NULL
- `end_lat`: FLOAT NOT NULL
- `end_lng`: FLOAT NOT NULL
- `base_speed_kmh`: FLOAT DEFAULT 40.0
- `elevation_m`: FLOAT NOT NULL
- `current_water_depth_cm`: FLOAT DEFAULT 0.0
- `is_blocked`: BOOLEAN DEFAULT FALSE

### 1.9 `pump_recommendations`
- `id`: VARCHAR(36) PRIMARY KEY
- `asset_id`: VARCHAR(32) REFERENCES drainage_assets(id)
- `zone_id`: VARCHAR(32) REFERENCES catchment_zones(id)
- `recommended_action`: VARCHAR(32) -- 'START_PUMP', 'STOP_PUMP', 'INCREASE_RPM', 'CLEAR_INLET'
- `urgency`: VARCHAR(32) -- 'ADVISORY', 'URGENT', 'CRITICAL'
- `rationale`: TEXT NOT NULL
- `inflow_rate_m3s`: FLOAT
- `status`: VARCHAR(32) DEFAULT 'PENDING' -- 'PENDING', 'ACCEPTED', 'OVERRIDDEN', 'EXECUTED'
- `operator_override_notes`: TEXT
- `created_at`: TIMESTAMP DEFAULT CURRENT_TIMESTAMP

### 1.10 `audit_logs`
- `id`: INTEGER PRIMARY KEY AUTOINCREMENT
- `user_id`: VARCHAR(36)
- `action`: VARCHAR(128) NOT NULL
- `entity_type`: VARCHAR(64) NOT NULL
- `entity_id`: VARCHAR(64) NOT NULL
- `details`: TEXT
- `timestamp`: TIMESTAMP DEFAULT CURRENT_TIMESTAMP
