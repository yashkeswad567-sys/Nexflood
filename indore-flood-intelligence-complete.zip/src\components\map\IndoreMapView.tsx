import React, { useEffect, useRef, useState, useMemo } from 'react';
import * as maplibregl from 'maplibre-gl';
import 'maplibre-gl/dist/maplibre-gl.css';
import {
  CatchmentZone, SensorDevice, DrainageAsset, Incident,
  EmergencyShelter, RouteOption
} from '../../types';
import { useTheme } from '../../context/ThemeContext';
import {
  Layers, ShieldAlert, Cpu, Home, Navigation, AlertTriangle,
  Eye, EyeOff, RotateCcw, Activity, Droplets, Waves, CheckCircle2,
  Maximize2
} from 'lucide-react';

interface IndoreMapViewProps {
  zones: CatchmentZone[];
  sensors?: SensorDevice[];
  assets?: DrainageAsset[];
  incidents?: Incident[];
  shelters?: EmergencyShelter[];
  activeRoute?: RouteOption | null;
  alternativeRoute?: RouteOption | null;
  selectedZoneId?: string | null;
  onSelectZone?: (zone: CatchmentZone) => void;
  onMapClick?: (lat: number, lng: number) => void;
  height?: string;
  className?: string;
  showDrainageChannels?: boolean;
}

// Indore Geographic Center (Longitude, Latitude)
const INDORE_CENTER: [number, number] = [75.8577, 22.7196];
const INDORE_DEFAULT_ZOOM = 12.8;

// Coordinate converter: ensures [lng, lat] order for MapLibre/GeoJSON RFC 7946
function normalizeLngLat(coord: [number, number]): [number, number] {
  // If first element is latitude (~22.7) and second is longitude (~75.8)
  if (coord[0] < 50 && coord[1] > 50) {
    return [coord[1], coord[0]];
  }
  return coord;
}

// Base Map Layer Types (Google Maps Satellite, Google Terrain, OpenStreetMap)
export type BaseMapMode = 'google-satellite' | 'google-terrain' | 'osm';

const GOOGLE_MAPS_KEY = (import.meta as any).env?.VITE_GOOGLE_MAPS_API_KEY || 'AIzaSyC75AxE4cM45Y42RDi6IrKr_gZ3Z4zsneQ';

function createMapStyle(mode: BaseMapMode, isDark: boolean): maplibregl.StyleSpecification {
  if (mode === 'google-satellite') {
    return {
      version: 8,
      name: 'Google Maps Satellite Hybrid',
      sources: {
        'base-raster-tiles': {
          type: 'raster',
          tiles: [
            `https://mt0.google.com/vt/lyrs=y&x={x}&y={y}&z={z}&key=${GOOGLE_MAPS_KEY}`,
            `https://mt1.google.com/vt/lyrs=y&x={x}&y={y}&z={z}&key=${GOOGLE_MAPS_KEY}`,
            `https://mt2.google.com/vt/lyrs=y&x={x}&y={y}&z={z}&key=${GOOGLE_MAPS_KEY}`,
            `https://mt3.google.com/vt/lyrs=y&x={x}&y={y}&z={z}&key=${GOOGLE_MAPS_KEY}`
          ],
          tileSize: 256,
          attribution: '&copy; <a href="https://maps.google.com" target="_blank" rel="noreferrer">Google Maps</a> Satellite'
        }
      },
      layers: [
        {
          id: 'base-raster-layer',
          type: 'raster',
          source: 'base-raster-tiles',
          minzoom: 0,
          maxzoom: 20
        }
      ]
    };
  }

  if (mode === 'google-terrain') {
    return {
      version: 8,
      name: 'Google Maps Physical Terrain',
      sources: {
        'base-raster-tiles': {
          type: 'raster',
          tiles: [
            `https://mt0.google.com/vt/lyrs=p&x={x}&y={y}&z={z}&key=${GOOGLE_MAPS_KEY}`,
            `https://mt1.google.com/vt/lyrs=p&x={x}&y={y}&z={z}&key=${GOOGLE_MAPS_KEY}`,
            `https://mt2.google.com/vt/lyrs=p&x={x}&y={y}&z={z}&key=${GOOGLE_MAPS_KEY}`,
            `https://mt3.google.com/vt/lyrs=p&x={x}&y={y}&z={z}&key=${GOOGLE_MAPS_KEY}`
          ],
          tileSize: 256,
          attribution: '&copy; <a href="https://maps.google.com" target="_blank" rel="noreferrer">Google Maps</a> Terrain'
        }
      },
      layers: [
        {
          id: 'base-raster-layer',
          type: 'raster',
          source: 'base-raster-tiles',
          minzoom: 0,
          maxzoom: 18
        }
      ]
    };
  }

  // OpenStreetMap standard (with Carto Dark in dark mode)
  return {
    version: 8,
    name: isDark ? 'OpenStreetMap Dark' : 'OpenStreetMap Standard',
    sources: {
      'base-raster-tiles': {
        type: 'raster',
        tiles: isDark
          ? [
              'https://a.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png',
              'https://b.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png',
              'https://c.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png'
            ]
          : [
              'https://tile.openstreetmap.org/{z}/{x}/{y}.png'
            ],
        tileSize: 256,
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noreferrer">OpenStreetMap</a> contributors'
      }
    },
    layers: [
      {
        id: 'base-raster-layer',
        type: 'raster',
        source: 'base-raster-tiles',
        minzoom: 0,
        maxzoom: 19
      }
    ]
  };
}

// Major Indore Drainage River Channels (Kahn River Spine & Saraswati Stream)
const INDORE_DRAINAGE_NETWORKS = {
  type: 'FeatureCollection',
  features: [
    {
      type: 'Feature',
      properties: { name: 'Kahn River Main Stormwater Spine', flow_capacity_m3s: 45.0, status: 'PRIMARY_OUTLET' },
      geometry: {
        type: 'LineString',
        coordinates: [
          [75.8450, 22.6850], // Bilawali Lake Outfall
          [75.8530, 22.7020], // Bhawarkuan Canal
          [75.8570, 22.7150], // Krishnapura Confluence
          [75.8590, 22.7240], // Sarafa/Rajwada Low Basin
          [75.8640, 22.7420], // Bhagirathpura Underpass
          [75.8710, 22.7660]  // Kabit Khedi STP Treatment Outfall
        ]
      }
    },
    {
      type: 'Feature',
      properties: { name: 'Saraswati River Tributary Canal', flow_capacity_m3s: 28.0, status: 'TRIBUTARY' },
      geometry: {
        type: 'LineString',
        coordinates: [
          [75.8350, 22.6950], // Pipliyapala Reservoir
          [75.8480, 22.7080], // Mhow Naka
          [75.8570, 22.7150]  // Confluence with Kahn River
        ]
      }
    },
    {
      type: 'Feature',
      properties: { name: 'Palasia Storm Trunk Channel', flow_capacity_m3s: 22.0, status: 'TRUNK_DRAIN' },
      geometry: {
        type: 'LineString',
        coordinates: [
          [75.8920, 22.7180], // Pipliyahana Lake
          [75.8840, 22.7240], // Palasia Square
          [75.8640, 22.7420]  // Bhagirathpura Interceptor
        ]
      }
    }
  ]
};

function checkWebGLSupport(): boolean {
  if (typeof window === 'undefined') return false;
  try {
    const canvas = document.createElement('canvas');
    return Boolean(
      window.WebGLRenderingContext &&
      (canvas.getContext('webgl') || canvas.getContext('experimental-webgl'))
    );
  } catch {
    return false;
  }
}

export const IndoreMapView: React.FC<IndoreMapViewProps> = ({
  zones,
  sensors = [],
  assets = [],
  incidents = [],
  shelters = [],
  activeRoute = null,
  alternativeRoute = null,
  selectedZoneId = null,
  onSelectZone,
  onMapClick,
  height = '540px',
  className = '',
  showDrainageChannels = true
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<maplibregl.Map | null>(null);
  const markersRef = useRef<{ [key: string]: maplibregl.Marker }>({});
  const activePopupRef = useRef<maplibregl.Popup | null>(null);
  const { theme } = useTheme();

  // Base Map Mode Toggle (Google Satellite, Google Terrain, OSM)
  const [baseMapMode, setBaseMapMode] = useState<BaseMapMode>('google-satellite');

  // Layer Visibility Toggles
  const [showZones, setShowZones] = useState<boolean>(true);
  const [showSensors, setShowSensors] = useState<boolean>(true);
  const [showAssets, setShowAssets] = useState<boolean>(true);
  const [showIncidents, setShowIncidents] = useState<boolean>(true);
  const [showShelters, setShowShelters] = useState<boolean>(true);
  const [showChannels, setShowChannels] = useState<boolean>(showDrainageChannels);
  const [controlsOpen, setControlsOpen] = useState<boolean>(true);

  // Status & Error States
  const [webglSupported, setWebglSupported] = useState<boolean>(true);
  const [mapLoaded, setMapLoaded] = useState<boolean>(false);
  const [tileError, setTileError] = useState<string | null>(null);

  // Check WebGL support on initial mount
  useEffect(() => {
    setWebglSupported(checkWebGLSupport());
  }, []);

  // Initialize MapLibre GL JS
  useEffect(() => {
    if (!mapContainerRef.current || !webglSupported) return;
    if (mapInstanceRef.current) return;

    const isDark = theme === 'dark';
    const styleSpec = createMapStyle(baseMapMode, isDark);

    const map = new maplibregl.Map({
      container: mapContainerRef.current,
      style: styleSpec,
      center: INDORE_CENTER,
      zoom: INDORE_DEFAULT_ZOOM,
      minZoom: 9,
      maxZoom: 20,
      pitch: 0,
      bearing: 0,
      attributionControl: false
    });

    mapInstanceRef.current = map;

    // Add Navigation, Fullscreen, Scale and Attribution Controls
    map.addControl(new maplibregl.NavigationControl({ visualizePitch: true, showCompass: true }), 'top-left');
    map.addControl(new maplibregl.FullscreenControl(), 'top-left');
    map.addControl(new maplibregl.ScaleControl({ maxWidth: 120, unit: 'metric' }), 'bottom-left');
    map.addControl(
      new maplibregl.AttributionControl({
        compact: true,
        customAttribution: 'Indore Flood Intel (Google Maps + MapLibre)'
      }),
      'bottom-right'
    );

    map.on('style.load', () => {
      setMapLoaded(true);
      map.resize();
    });

    map.on('error', (e) => {
      // Non-fatal tile error handling
      if (e.error && typeof e.error.message === 'string' && e.error.message.includes('tile')) {
        setTileError('Some base map tiles could not be reached. Geospatial vector overlays remain operational.');
      }
    });

    map.on('click', (e) => {
      if (onMapClick) {
        onMapClick(e.lngLat.lat, e.lngLat.lng);
      }
    });

    // Handle container resize dynamically (responsive desktop/mobile + drawer toggles)
    const resizeObserver = new ResizeObserver(() => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.resize();
      }
    });
    if (mapContainerRef.current) {
      resizeObserver.observe(mapContainerRef.current);
    }

    return () => {
      resizeObserver.disconnect();
      // Clean up markers
      Object.values(markersRef.current).forEach((m) => m.remove());
      markersRef.current = {};
      if (activePopupRef.current) {
        activePopupRef.current.remove();
      }
      map.remove();
      mapInstanceRef.current = null;
      setMapLoaded(false);
    };
  }, [webglSupported]);

  // Update Base Style when Mode or Theme changes (Google Satellite <-> Google Terrain <-> OSM)
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;
    const isDark = theme === 'dark';
    const newStyle = createMapStyle(baseMapMode, isDark);
    setMapLoaded(false);
    map.setStyle(newStyle);
  }, [baseMapMode, theme]);

  // Transform Catchment Zones into standard GeoJSON FeatureCollection
  const zonesGeoJSON = useMemo(() => {
    return {
      type: 'FeatureCollection',
      features: zones.map((zone) => {
        const hazardColor = {
          LOW: '#10b981',      // Emerald Green
          MODERATE: '#f59e0b', // Amber
          HIGH: '#f97316',     // Orange
          CRITICAL: '#ef4444'  // Rose Red
        }[zone.current_hazard_level || 'LOW'];

        // Normalize polygon coordinates to [lng, lat]
        const ring = (zone.polygon_geojson || []).map(normalizeLngLat);
        // Ensure ring is closed
        if (ring.length > 0) {
          const first = ring[0];
          const last = ring[ring.length - 1];
          if (first[0] !== last[0] || first[1] !== last[1]) {
            ring.push([first[0], first[1]]);
          }
        }

        return {
          type: 'Feature',
          id: zone.id,
          properties: {
            id: zone.id,
            name: zone.name,
            description: zone.description,
            elevation_m: zone.elevation_m,
            hazard_level: zone.current_hazard_level,
            hazard_color: hazardColor,
            water_depth_cm: zone.current_water_depth_cm,
            soil_saturation_pct: zone.soil_saturation_pct,
            is_selected: zone.id === selectedZoneId ? 1 : 0
          },
          geometry: {
            type: 'Polygon',
            coordinates: [ring]
          }
        };
      })
    };
  }, [zones, selectedZoneId]);

  // Render & Update Catchment Zones Vector Layers
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map || !mapLoaded) return;

    const sourceId = 'catchment-zones-source';
    const fillLayerId = 'catchment-zones-fill';
    const lineLayerId = 'catchment-zones-line';
    const labelLayerId = 'catchment-zones-label';

    const existingSource = map.getSource(sourceId) as maplibregl.GeoJSONSource;

    if (existingSource) {
      existingSource.setData(zonesGeoJSON as any);
    } else {
      map.addSource(sourceId, {
        type: 'geojson',
        data: zonesGeoJSON as any
      });

      // Fill Layer
      map.addLayer({
        id: fillLayerId,
        type: 'fill',
        source: sourceId,
        paint: {
          'fill-color': ['get', 'hazard_color'],
          'fill-opacity': [
            'case',
            ['==', ['get', 'is_selected'], 1],
            0.55,
            0.30
          ]
        }
      });

      // Outline Layer
      map.addLayer({
        id: lineLayerId,
        type: 'line',
        source: sourceId,
        paint: {
          'line-color': ['get', 'hazard_color'],
          'line-width': [
            'case',
            ['==', ['get', 'is_selected'], 1],
            4,
            2
          ],
          'line-dasharray': [
            'case',
            ['==', ['get', 'hazard_level'], 'CRITICAL'],
            ['literal', [4, 2]],
            ['literal', [1, 0]]
          ]
        }
      });

      // Label Layer
      map.addLayer({
        id: labelLayerId,
        type: 'symbol',
        source: sourceId,
        layout: {
          'text-field': ['concat', ['get', 'name'], '\n(', ['to-string', ['round', ['get', 'water_depth_cm']]], ' cm)'],
          'text-size': 11,
          'text-font': ['Open Sans Semibold', 'Arial Unicode MS Bold'],
          'text-justify': 'center',
          'text-anchor': 'center'
        },
        paint: {
          'text-color': '#0f172a',
          'text-halo-color': '#ffffff',
          'text-halo-width': 2
        }
      });

      // Interactive Click on Zone
      map.on('click', fillLayerId, (e) => {
        if (!e.features || e.features.length === 0) return;
        const feat = e.features[0];
        const props = feat.properties as any;
        const matchingZone = zones.find((z) => z.id === props.id);

        if (matchingZone && onSelectZone) {
          onSelectZone(matchingZone);
        }

        if (activePopupRef.current) activePopupRef.current.remove();

        const popupHtml = `
          <div style="font-family: inherit; min-width: 210px; padding: 12px;">
            <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 6px;">
              <h4 style="margin: 0; font-weight: 800; font-size: 14px; color: #0f172a;">${props.name}</h4>
              <span style="background: ${props.hazard_color}; color: white; font-size: 10px; font-weight: 800; padding: 2px 7px; border-radius: 9999px;">
                ${props.hazard_level}
              </span>
            </div>
            <p style="margin: 0 0 8px; font-size: 11px; color: #64748b; line-height: 1.3;">${props.description}</p>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 6px; font-size: 12px; background: #f8fafc; padding: 8px; border-radius: 8px; margin-bottom: 8px;">
              <div><span style="color:#64748b; font-size:10px; display:block;">Water Depth</span><strong>${Number(props.water_depth_cm).toFixed(1)} cm</strong></div>
              <div><span style="color:#64748b; font-size:10px; display:block;">Soil Saturation</span><strong>${Number(props.soil_saturation_pct).toFixed(0)}%</strong></div>
              <div><span style="color:#64748b; font-size:10px; display:block;">Elevation</span><strong>${Number(props.elevation_m).toFixed(0)}m AMSL</strong></div>
              <div><span style="color:#64748b; font-size:10px; display:block;">Runoff Horizon</span><strong>1h / 2h / 3h</strong></div>
            </div>
            <div style="font-size: 10px; color: #0284c7; font-weight: 600; text-align: center;">Click to focus zone analytics</div>
          </div>
        `;

        activePopupRef.current = new maplibregl.Popup({ closeButton: true, maxWidth: '280px' })
          .setLngLat(e.lngLat)
          .setHTML(popupHtml)
          .addTo(map);
      });

      // Pointer Cursor on Zone Hover
      map.on('mouseenter', fillLayerId, () => {
        map.getCanvas().style.cursor = 'pointer';
      });
      map.on('mouseleave', fillLayerId, () => {
        map.getCanvas().style.cursor = '';
      });
    }

    // Toggle layer visibility
    const vis = showZones ? 'visible' : 'none';
    if (map.getLayer(fillLayerId)) map.setLayoutProperty(fillLayerId, 'visibility', vis);
    if (map.getLayer(lineLayerId)) map.setLayoutProperty(lineLayerId, 'visibility', vis);
    if (map.getLayer(labelLayerId)) map.setLayoutProperty(labelLayerId, 'visibility', vis);
  }, [zonesGeoJSON, showZones, mapLoaded, zones, onSelectZone]);

  // Render Indore River & Drainage Channels
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map || !mapLoaded) return;

    const sourceId = 'drainage-channels-source';
    const layerId = 'drainage-channels-line';
    const labelId = 'drainage-channels-label';

    if (!map.getSource(sourceId)) {
      map.addSource(sourceId, {
        type: 'geojson',
        data: INDORE_DRAINAGE_NETWORKS as any
      });

      map.addLayer({
        id: layerId,
        type: 'line',
        source: sourceId,
        paint: {
          'line-color': '#0284c7',
          'line-width': 4,
          'line-opacity': 0.85
        }
      });

      map.addLayer({
        id: labelId,
        type: 'symbol',
        source: sourceId,
        layout: {
          'symbol-placement': 'line',
          'text-field': ['get', 'name'],
          'text-size': 10,
          'text-font': ['Open Sans Semibold'],
          'text-offset': [0, 0.8]
        },
        paint: {
          'text-color': '#0369a1',
          'text-halo-color': '#ffffff',
          'text-halo-width': 1.5
        }
      });
    }

    const vis = showChannels ? 'visible' : 'none';
    if (map.getLayer(layerId)) map.setLayoutProperty(layerId, 'visibility', vis);
    if (map.getLayer(labelId)) map.setLayoutProperty(labelId, 'visibility', vis);
  }, [showChannels, mapLoaded]);

  // Render & Update Routes (Primary Safe & Alternative Hazardous)
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map || !mapLoaded) return;

    const primarySourceId = 'primary-route-source';
    const primaryLayerId = 'primary-route-layer';
    const altSourceId = 'alt-route-source';
    const altLayerId = 'alt-route-layer';

    // Primary Safe Route LineString
    const primaryCoords = (activeRoute?.path_coordinates || []).map(normalizeLngLat);
    const primaryGeoJSON = {
      type: 'Feature',
      properties: { name: activeRoute?.name || 'Safe Route' },
      geometry: { type: 'LineString', coordinates: primaryCoords }
    };

    if (map.getSource(primarySourceId)) {
      (map.getSource(primarySourceId) as maplibregl.GeoJSONSource).setData(primaryGeoJSON as any);
    } else {
      map.addSource(primarySourceId, { type: 'geojson', data: primaryGeoJSON as any });
      map.addLayer({
        id: primaryLayerId,
        type: 'line',
        source: primarySourceId,
        layout: { 'line-join': 'round', 'line-cap': 'round' },
        paint: {
          'line-color': '#0284c7',
          'line-width': 6,
          'line-opacity': 0.95
        }
      });
    }

    // Alternative High-Risk Route LineString
    const altCoords = (alternativeRoute?.path_coordinates || []).map(normalizeLngLat);
    const altGeoJSON = {
      type: 'Feature',
      properties: { name: alternativeRoute?.name || 'Hazardous Alternative' },
      geometry: { type: 'LineString', coordinates: altCoords }
    };

    if (map.getSource(altSourceId)) {
      (map.getSource(altSourceId) as maplibregl.GeoJSONSource).setData(altGeoJSON as any);
    } else {
      map.addSource(altSourceId, { type: 'geojson', data: altGeoJSON as any });
      map.addLayer({
        id: altLayerId,
        type: 'line',
        source: altSourceId,
        layout: { 'line-join': 'round', 'line-cap': 'round' },
        paint: {
          'line-color': '#f43f5e',
          'line-width': 4,
          'line-opacity': 0.8,
          'line-dasharray': [3, 2]
        }
      });
    }

    // Auto-fit bounds if route is active
    if (primaryCoords.length > 1) {
      const bounds = new maplibregl.LngLatBounds();
      primaryCoords.forEach((pt) => bounds.extend(pt));
      altCoords.forEach((pt) => bounds.extend(pt));
      map.fitBounds(bounds, { padding: 50, maxZoom: 15, duration: 1000 });
    }
  }, [activeRoute, alternativeRoute, mapLoaded]);

  // Sync Markers: IoT Sensors, Drainage Assets, Emergency Incidents, Shelters
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map || !mapLoaded) return;

    // Clear old markers that no longer exist
    const activeMarkerKeys = new Set<string>();

    // 1. IoT Sensors Markers
    if (showSensors) {
      sensors.forEach((s) => {
        const key = `sensor_${s.id}`;
        activeMarkerKeys.add(key);

        const isCrit = s.current_water_level_cm >= s.critical_threshold_cm;
        const isWarn = s.current_water_level_cm >= s.warning_threshold_cm;
        const color = isCrit ? '#ef4444' : isWarn ? '#f59e0b' : '#0284c7';

        if (!markersRef.current[key]) {
          const el = document.createElement('div');
          el.className = 'sensor-maplibre-marker';
          el.style.width = '26px';
          el.style.height = '26px';
          el.style.borderRadius = '50%';
          el.style.background = color;
          el.style.border = '2px solid white';
          el.style.boxShadow = '0 2px 8px rgba(0,0,0,0.35)';
          el.style.display = 'flex';
          el.style.alignItems = 'center';
          el.style.justifyContent = 'center';
          el.style.color = 'white';
          el.style.fontSize = '10px';
          el.style.fontWeight = 'bold';
          el.style.cursor = 'pointer';
          el.innerText = `${Math.round(s.current_water_level_cm)}`;

          const popupHtml = `
            <div style="font-family: inherit; min-width: 200px; padding: 10px;">
              <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">
                <h4 style="margin:0; font-weight:700; font-size:13px; color:#0f172a;">${s.name}</h4>
                <span style="background:${color}; color:white; font-size:9px; font-weight:800; padding:1px 5px; border-radius:4px;">
                  ${isCrit ? 'CRITICAL' : isWarn ? 'WARNING' : 'NORMAL'}
                </span>
              </div>
              <div style="font-size:10px; color:#64748b; margin-bottom:6px;">Device ID: ${s.id}</div>
              <div style="font-size:12px; margin-bottom:3px;">Water Level: <strong>${s.current_water_level_cm.toFixed(1)} cm</strong></div>
              <div style="font-size:12px; margin-bottom:3px;">Flow Rate: <strong>${s.current_flow_rate_m3s.toFixed(1)} m³/s</strong></div>
              <div style="font-size:12px; margin-bottom:6px;">Battery: <strong>${s.battery_pct.toFixed(0)}%</strong></div>
              <div style="font-size:10px; color:#10b981; font-weight:600; border-top:1px solid #e2e8f0; padding-top:4px;">
                ● Verified Live Telemetry (ESP32)
              </div>
            </div>
          `;

          const popup = new maplibregl.Popup({ offset: 12 }).setHTML(popupHtml);
          const marker = new maplibregl.Marker({ element: el })
            .setLngLat([s.longitude, s.latitude])
            .setPopup(popup)
            .addTo(map);

          markersRef.current[key] = marker;
        } else {
          // Update position and color
          markersRef.current[key].setLngLat([s.longitude, s.latitude]);
          const el = markersRef.current[key].getElement();
          el.style.background = color;
          el.innerText = `${Math.round(s.current_water_level_cm)}`;
        }
      });
    }

    // 2. Drainage Assets Markers (Pumps, Sluice Gates)
    if (showAssets) {
      assets.forEach((a) => {
        const key = `asset_${a.id}`;
        activeMarkerKeys.add(key);

        const isRunning = a.current_status === 'RUNNING';
        const isDegraded = a.current_status === 'DEGRADED';
        const isFault = a.current_status === 'FAULT';
        const color = isRunning ? '#10b981' : isFault ? '#ef4444' : isDegraded ? '#f59e0b' : '#6366f1';
        const badgeLabel = a.asset_type === 'stormwater_pump' ? 'P' : 'G';

        if (!markersRef.current[key]) {
          const el = document.createElement('div');
          el.className = 'asset-maplibre-marker';
          el.style.width = '24px';
          el.style.height = '24px';
          el.style.borderRadius = '6px';
          el.style.background = color;
          el.style.border = '2px solid white';
          el.style.boxShadow = '0 2px 8px rgba(0,0,0,0.3)';
          el.style.display = 'flex';
          el.style.alignItems = 'center';
          el.style.justifyContent = 'center';
          el.style.color = 'white';
          el.style.fontSize = '11px';
          el.style.fontWeight = 'bold';
          el.style.cursor = 'pointer';
          el.innerText = badgeLabel;

          const popupHtml = `
            <div style="font-family: inherit; min-width: 200px; padding: 10px;">
              <h4 style="margin:0 0 2px; font-weight:700; font-size:13px; color:#0f172a;">${a.name}</h4>
              <div style="font-size:11px; color:#64748b; margin-bottom:6px;">Status: <strong style="color:${color}">${a.current_status}</strong></div>
              <div style="font-size:12px; margin-bottom:2px;">Capacity: <strong>${a.rated_capacity_m3s.toFixed(1)} m³/s</strong></div>
              <div style="font-size:12px; margin-bottom:4px;">Silt Blockage: <strong>${a.silt_blockage_pct.toFixed(1)}%</strong></div>
              <div style="font-size:10px; color:#64748b;">Asset ID: ${a.id}</div>
            </div>
          `;

          const popup = new maplibregl.Popup({ offset: 12 }).setHTML(popupHtml);
          const marker = new maplibregl.Marker({ element: el })
            .setLngLat([a.longitude, a.latitude])
            .setPopup(popup)
            .addTo(map);

          markersRef.current[key] = marker;
        } else {
          markersRef.current[key].setLngLat([a.longitude, a.latitude]);
          const el = markersRef.current[key].getElement();
          el.style.background = color;
        }
      });
    }

    // 3. Emergency SOS & Incident Distress Markers
    if (showIncidents) {
      incidents.forEach((inc) => {
        const key = `inc_${inc.id}`;
        activeMarkerKeys.add(key);

        const isSOS = inc.incident_type === 'EMERGENCY_SOS';

        if (!markersRef.current[key]) {
          const el = document.createElement('div');
          el.className = 'inc-maplibre-marker';
          el.style.width = '28px';
          el.style.height = '28px';
          el.style.borderRadius = '50%';
          el.style.background = '#e11d48';
          el.style.border = '2px solid white';
          el.style.boxShadow = '0 0 14px rgba(225, 29, 72, 0.85)';
          el.style.display = 'flex';
          el.style.alignItems = 'center';
          el.style.justifyContent = 'center';
          el.style.color = 'white';
          el.style.fontSize = '11px';
          el.style.fontWeight = '900';
          el.style.cursor = 'pointer';
          el.innerText = isSOS ? 'SOS' : '!';

          const popupHtml = `
            <div style="font-family: inherit; min-width: 220px; padding: 10px;">
              <span style="background:#ffe4e6; color:#be123c; font-size:10px; font-weight:800; padding:2px 6px; border-radius:4px; text-transform:uppercase;">
                ${inc.severity} ${inc.incident_type}
              </span>
              <h4 style="margin:6px 0 2px; font-weight:700; font-size:13px; color:#0f172a;">${inc.landmark_address}</h4>
              <p style="margin:0 0 6px; font-size:11px; color:#64748b;">Code: ${inc.tracking_code}</p>
              <div style="font-size:12px; margin-bottom:2px;">People Stranded: <strong>${inc.people_stranded}</strong></div>
              <div style="font-size:12px; margin-bottom:2px;">Status: <strong>${inc.status}</strong></div>
              ${inc.assigned_unit ? `<div style="font-size:11px; color:#0284c7; margin-top:4px;">Assigned: <strong>${inc.assigned_unit}</strong></div>` : ''}
            </div>
          `;

          const popup = new maplibregl.Popup({ offset: 12 }).setHTML(popupHtml);
          const marker = new maplibregl.Marker({ element: el })
            .setLngLat([inc.longitude, inc.latitude])
            .setPopup(popup)
            .addTo(map);

          markersRef.current[key] = marker;
        } else {
          markersRef.current[key].setLngLat([inc.longitude, inc.latitude]);
        }
      });
    }

    // 4. Emergency Shelters Markers
    if (showShelters) {
      shelters.forEach((sh) => {
        const key = `shelter_${sh.id}`;
        activeMarkerKeys.add(key);

        if (!markersRef.current[key]) {
          const el = document.createElement('div');
          el.className = 'shelter-maplibre-marker';
          el.style.width = '24px';
          el.style.height = '24px';
          el.style.borderRadius = '50%';
          el.style.background = '#059669';
          el.style.border = '2px solid white';
          el.style.boxShadow = '0 2px 6px rgba(0,0,0,0.3)';
          el.style.display = 'flex';
          el.style.alignItems = 'center';
          el.style.justifyContent = 'center';
          el.style.color = 'white';
          el.style.fontSize = '11px';
          el.style.fontWeight = 'bold';
          el.style.cursor = 'pointer';
          el.innerText = 'H';

          const popupHtml = `
            <div style="font-family: inherit; min-width: 200px; padding: 10px;">
              <h4 style="margin:0 0 2px; font-weight:700; font-size:13px; color:#0f172a;">${sh.name}</h4>
              <p style="margin:0 0 6px; font-size:11px; color:#64748b;">${sh.address}</p>
              <div style="font-size:12px; margin-bottom:2px;">Occupancy: <strong>${sh.current_occupancy} / ${sh.capacity}</strong></div>
              <div style="font-size:11px; color:#059669; font-weight:600;">${sh.facilities}</div>
            </div>
          `;

          const popup = new maplibregl.Popup({ offset: 12 }).setHTML(popupHtml);
          const marker = new maplibregl.Marker({ element: el })
            .setLngLat([sh.longitude, sh.latitude])
            .setPopup(popup)
            .addTo(map);

          markersRef.current[key] = marker;
        } else {
          markersRef.current[key].setLngLat([sh.longitude, sh.latitude]);
        }
      });
    }

    // Clean up markers that are now toggled off
    Object.keys(markersRef.current).forEach((key) => {
      if (!activeMarkerKeys.has(key)) {
        markersRef.current[key].remove();
        delete markersRef.current[key];
      }
    });
  }, [sensors, assets, incidents, shelters, showSensors, showAssets, showIncidents, showShelters, mapLoaded]);

  // Center on Indore button handler
  const handleResetView = () => {
    const map = mapInstanceRef.current;
    if (map) {
      map.flyTo({ center: INDORE_CENTER, zoom: INDORE_DEFAULT_ZOOM, pitch: 0, bearing: 0, duration: 800 });
    }
  };

  // Graceful WebGL Fallback (if browser hardware acceleration is disabled)
  if (!webglSupported) {
    return (
      <div
        style={{ height }}
        className={`relative rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-slate-900 flex flex-col items-center justify-center p-6 text-center shadow-md ${className}`}
      >
        <AlertTriangle className="w-12 h-12 text-amber-500 mb-3" />
        <h3 className="text-base font-bold text-slate-800 dark:text-slate-100 mb-1">
          WebGL Hardware Acceleration Disabled
        </h3>
        <p className="text-xs text-slate-500 dark:text-slate-400 max-w-md mb-4">
          MapLibre GL requires WebGL. Enable hardware acceleration in your browser settings to display the interactive 3D map.
        </p>
        <div className="flex flex-wrap gap-2 justify-center max-w-lg">
          {zones.map((z) => (
            <div
              key={z.id}
              onClick={() => onSelectZone && onSelectZone(z)}
              className="px-3 py-1.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-semibold cursor-pointer hover:border-sky-500"
            >
              <span>{z.name}</span>: <strong className="text-sky-600 dark:text-sky-400">{z.current_water_depth_cm.toFixed(1)}cm</strong>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className={`relative rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 shadow-md ${className}`}>
      
      {/* MapLibre WebGL Map Container */}
      <div
        ref={mapContainerRef}
        style={{ height }}
        className="w-full relative"
      />

      {/* Non-fatal Tile Error Banner */}
      {tileError && (
        <div className="absolute top-3 left-16 z-30 flex items-center gap-2 px-3 py-1.5 rounded-lg bg-amber-500/90 text-white text-[11px] shadow-md backdrop-blur-sm max-w-md">
          <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0" />
          <span>{tileError}</span>
          <button onClick={() => setTileError(null)} className="ml-auto font-bold px-1">&times;</button>
        </div>
      )}

      {/* Floating Status, Base Layer Switcher & Engine Badge */}
      <div className="absolute top-3 right-3 sm:right-4 z-20 flex flex-wrap items-center gap-2">
        {/* Base Map Switcher: Google Satellite vs Google Terrain vs OSM */}
        <div className="flex items-center bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border border-slate-200 dark:border-slate-800 rounded-lg p-0.5 shadow-md text-[10px] font-semibold">
          <button
            onClick={() => setBaseMapMode('google-satellite')}
            className={`px-2 py-1 rounded transition-colors ${
              baseMapMode === 'google-satellite'
                ? 'bg-sky-600 text-white font-bold shadow-sm'
                : 'text-slate-600 dark:text-slate-300 hover:text-sky-500'
            }`}
          >
            Google Satellite
          </button>
          <button
            onClick={() => setBaseMapMode('google-terrain')}
            className={`px-2 py-1 rounded transition-colors ${
              baseMapMode === 'google-terrain'
                ? 'bg-sky-600 text-white font-bold shadow-sm'
                : 'text-slate-600 dark:text-slate-300 hover:text-sky-500'
            }`}
          >
            Terrain
          </button>
          <button
            onClick={() => setBaseMapMode('osm')}
            className={`px-2 py-1 rounded transition-colors ${
              baseMapMode === 'osm'
                ? 'bg-sky-600 text-white font-bold shadow-sm'
                : 'text-slate-600 dark:text-slate-300 hover:text-sky-500'
            }`}
          >
            OSM
          </button>
        </div>

        <div className="hidden md:flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border border-slate-200 dark:border-slate-800 shadow-sm text-[11px] font-semibold text-slate-700 dark:text-slate-300">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          <span>{baseMapMode.startsWith('google') ? 'Google Maps Hybrid' : 'OpenStreetMap'}</span>
          <span className="text-[10px] text-slate-400 font-mono">(Live)</span>
        </div>

        <button
          onClick={handleResetView}
          title="Reset to Indore Center"
          className="p-1.5 rounded-lg bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border border-slate-200 dark:border-slate-800 shadow-sm hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 transition-colors"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>

      {/* Floating Layer Controls Toolbar (Responsive) */}
      <div className="absolute top-12 sm:top-14 right-3 sm:right-4 z-20 flex flex-col items-end">
        <button
          onClick={() => setControlsOpen(!controlsOpen)}
          className="sm:hidden flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border border-slate-200 dark:border-slate-800 shadow-md text-xs font-bold text-slate-700 dark:text-slate-200 mb-1"
        >
          <Layers className="w-3.5 h-3.5" />
          <span>Layers</span>
        </button>

        {controlsOpen && (
          <div className="flex flex-col gap-1.5 p-2 rounded-xl bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border border-slate-200 dark:border-slate-800 shadow-lg text-xs w-48 transition-all">
            <div className="flex items-center justify-between px-1 py-0.5 font-bold text-slate-500 uppercase tracking-wider text-[10px]">
              <span className="flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5" />
                <span>GIS Layers</span>
              </span>
              <span className="text-[9px] text-emerald-600 dark:text-emerald-400 font-mono">OSM Tile</span>
            </div>

            <button
              onClick={() => setShowZones(!showZones)}
              className={`flex items-center justify-between gap-2 px-2 py-1 rounded-md transition-colors ${
                showZones
                  ? 'bg-sky-50 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400 font-semibold'
                  : 'text-slate-400 opacity-60'
              }`}
            >
              <span>Catchment Zones ({zones.length})</span>
              {showZones ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
            </button>

            <button
              onClick={() => setShowSensors(!showSensors)}
              className={`flex items-center justify-between gap-2 px-2 py-1 rounded-md transition-colors ${
                showSensors
                  ? 'bg-sky-50 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400 font-semibold'
                  : 'text-slate-400 opacity-60'
              }`}
            >
              <span>IoT Sensors ({sensors.length})</span>
              {showSensors ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
            </button>

            <button
              onClick={() => setShowAssets(!showAssets)}
              className={`flex items-center justify-between gap-2 px-2 py-1 rounded-md transition-colors ${
                showAssets
                  ? 'bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 font-semibold'
                  : 'text-slate-400 opacity-60'
              }`}
            >
              <span>Drainage Pumps ({assets.length})</span>
              {showAssets ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
            </button>

            <button
              onClick={() => setShowChannels(!showChannels)}
              className={`flex items-center justify-between gap-2 px-2 py-1 rounded-md transition-colors ${
                showChannels
                  ? 'bg-cyan-50 dark:bg-cyan-950/60 text-cyan-600 dark:text-cyan-400 font-semibold'
                  : 'text-slate-400 opacity-60'
              }`}
            >
              <span>River & Storm Canals</span>
              {showChannels ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
            </button>

            <button
              onClick={() => setShowIncidents(!showIncidents)}
              className={`flex items-center justify-between gap-2 px-2 py-1 rounded-md transition-colors ${
                showIncidents
                  ? 'bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 font-semibold'
                  : 'text-slate-400 opacity-60'
              }`}
            >
              <span>Emergency SOS ({incidents.length})</span>
              {showIncidents ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
            </button>

            <button
              onClick={() => setShowShelters(!showShelters)}
              className={`flex items-center justify-between gap-2 px-2 py-1 rounded-md transition-colors ${
                showShelters
                  ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 font-semibold'
                  : 'text-slate-400 opacity-60'
              }`}
            >
              <span>Safe Shelters ({shelters.length})</span>
              {showShelters ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
            </button>
          </div>
        )}
      </div>

      {/* Legend Badge Bar (Bottom-Left) */}
      <div className="absolute bottom-3 left-3 sm:left-4 z-20 flex flex-wrap items-center gap-2 px-3 py-1.5 rounded-xl bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border border-slate-200 dark:border-slate-800 shadow-md text-[11px] font-medium">
        <span className="text-slate-400 font-semibold">Flood Risk:</span>
        <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>Low (&lt;15cm)</span>
        <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>Mod (15-30)</span>
        <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-orange-500"></span>High (30-50)</span>
        <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-rose-500"></span>Critical (&gt;50cm)</span>
      </div>

    </div>
  );
};
