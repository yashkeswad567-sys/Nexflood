import React, { useState } from 'react';
import {
  MapPin, ShieldAlert, Droplets, Navigation, Home, AlertTriangle,
  Clock, CheckCircle2, Phone, Compass, Users, HeartPulse, Send,
  ArrowRight, Search, Activity, Info, ShieldCheck, RefreshCw
} from 'lucide-react';
import { IndoreMapView } from '../components/map/IndoreMapView';
import { useFloodData } from '../context/FloodDataContext';
import { CatchmentZone, RouteResponse, Incident } from '../types';
import { api } from '../services/api';

export const CitizenDashboard: React.FC = () => {
  const { floodStatus, sensors, shelters, alerts, submitSOS, refreshData } = useFloodData();
  
  // Selected zone for detail view
  const [selectedZone, setSelectedZone] = useState<CatchmentZone | null>(null);
  
  // Routing State
  const [originZoneId, setOriginZoneId] = useState<string>('zone_rajwada');
  const [destZoneId, setDestZoneId] = useState<string>('zone_vijay_nagar');
  const [routeResult, setRouteResult] = useState<RouteResponse | null>(null);
  const [isRoutingLoading, setIsRoutingLoading] = useState<boolean>(false);

  // SOS Form State
  const [sosName, setSosName] = useState<string>('Pooja Sharma');
  const [sosPhone, setSosPhone] = useState<string>('+91 98260 11223');
  const [sosPeople, setSosPeople] = useState<number>(2);
  const [sosMedical, setSosMedical] = useState<boolean>(false);
  const [sosNotes, setSosNotes] = useState<string>('Water entering ground floor, need assistance.');
  const [sosSubmitted, setSosSubmitted] = useState<Incident | null>(null);
  const [isSubmittingSOS, setIsSubmittingSOS] = useState<boolean>(false);

  // Waterlogging Report State
  const [reportLandmark, setReportLandmark] = useState<string>('MG Road near Kothari Market');
  const [reportSeverity, setReportSeverity] = useState<string>('HIGH');
  const [reportDesc, setReportDesc] = useState<string>('Severe waterlogging, two-wheelers slipping.');
  const [reportSuccess, setReportSuccess] = useState<string | null>(null);

  // Handle Route Calculation
  const handleCalculateRoute = async () => {
    const orig = floodStatus?.zones.find(z => z.id === originZoneId);
    const dest = floodStatus?.zones.find(z => z.id === destZoneId);
    if (!orig || !dest) return;

    setIsRoutingLoading(true);
    try {
      const res = await api.calculateRoute(orig.centroid_lat, orig.centroid_lng, dest.centroid_lat, dest.centroid_lng);
      setRouteResult(res);
    } catch (e) {
      console.error(e);
    } finally {
      setIsRoutingLoading(false);
    }
  };

  // Handle SOS Submission
  const handleSOSSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmittingSOS(true);
    try {
      const orig = floodStatus?.zones.find(z => z.id === originZoneId) || floodStatus?.zones[0];
      const res = await submitSOS({
        citizen_name: sosName,
        phone: sosPhone,
        location: {
          lat: orig ? orig.centroid_lat : 22.7196,
          lng: orig ? orig.centroid_lng : 75.8577,
          address: `${orig ? orig.name : 'Rajwada Basin'}, Indore`
        },
        people_stranded: sosPeople,
        has_medical_emergency: sosMedical,
        severity: 'CRITICAL',
        notes: sosNotes
      });
      setSosSubmitted(res);
    } catch (e) {
      console.error(e);
    } finally {
      setIsSubmittingSOS(false);
    }
  };

  // Handle Waterlogging Incident Report
  const handleReportSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const orig = floodStatus?.zones.find(z => z.id === originZoneId);
      const res = await api.submitReport({
        reporter_name: sosName,
        phone: sosPhone,
        latitude: orig ? orig.centroid_lat : 22.7196,
        longitude: orig ? orig.centroid_lng : 75.8577,
        landmark: reportLandmark,
        severity: reportSeverity,
        description: reportDesc
      });
      setReportSuccess(`Incident logged with Tracking Code: ${res.tracking_code}`);
      setTimeout(() => setReportSuccess(null), 8000);
    } catch (e) {
      console.error(e);
    }
  };

  const zones = floodStatus?.zones || [];
  const activeZone = selectedZone || zones[0] || null;

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6">
      
      {/* Citizen Welcome Banner */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-5 rounded-2xl bg-gradient-to-r from-sky-600 via-blue-600 to-indigo-700 text-white shadow-xl shadow-sky-600/10">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded text-[10px] font-extrabold uppercase tracking-wider bg-white/20">
              Citizen Advisory Portal
            </span>
            <span className="text-xs text-sky-200">Indore Municipal Corporation (IMC)</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-extrabold tracking-tight mt-1">
            Real-Time Flood Risk & Emergency Guidance
          </h1>
          <p className="text-xs sm:text-sm text-sky-100 mt-1 max-w-2xl">
            Live hydrologic monitoring across Indore's 8 catchment basins. Plan flood-aware travel routes and submit verified distress signals.
          </p>
        </div>

        {/* Quick Emergency SOS CTA */}
        <a
          href="#sos"
          className="flex items-center gap-2 px-5 py-3 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-sm shadow-lg shadow-rose-900/30 transition-all hover:scale-105"
        >
          <ShieldAlert className="w-5 h-5 animate-pulse" />
          <span>REQUEST EMERGENCY SOS</span>
        </a>
      </div>

      {/* Live Rainfall & Hydrology KPI Ticker */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
        
        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold mb-1">
            <span>Rainfall Rate</span>
            <Droplets className="w-4 h-4 text-sky-500" />
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-sky-600 dark:text-sky-400">
            {floodStatus?.rainfall_rate_mmh.toFixed(1) || '32.5'} <span className="text-xs font-normal">mm/h</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1">Intensity: Heavy Monsoon</p>
        </div>

        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold mb-1">
            <span>24h Accumulation</span>
            <Clock className="w-4 h-4 text-indigo-500" />
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-indigo-600 dark:text-indigo-400">
            {floodStatus?.rainfall_24h_accum_mm.toFixed(1) || '68.2'} <span className="text-xs font-normal">mm</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1">Basin saturation high</p>
        </div>

        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold mb-1">
            <span>City Hazard Level</span>
            <AlertTriangle className="w-4 h-4 text-amber-500" />
          </div>
          <div className={`text-xl sm:text-2xl font-extrabold ${floodStatus?.city_hazard_level === 'CRITICAL' ? 'text-rose-500' : 'text-amber-500'}`}>
            {floodStatus?.city_hazard_level || 'HIGH'}
          </div>
          <p className="text-[11px] text-slate-500 mt-1">Max Depth: {floodStatus?.city_max_depth_cm.toFixed(1)} cm</p>
        </div>

        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold mb-1">
            <span>Relief Shelters</span>
            <Home className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-emerald-600 dark:text-emerald-400">
            {shelters.length} <span className="text-xs font-normal">Open</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1">Holkar & Nehru Stadium open</p>
        </div>

      </div>

      {/* Main Grid: Interactive Map + Forecast Timeline */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Map Column (Span 2) */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">Interactive Indore Flood Hazard Map</h2>
              <p className="text-xs text-slate-500">Click any catchment zone or sensor pin to inspect localized depth.</p>
            </div>
            {/* Quick Ward Filter */}
            <select
              value={activeZone?.id || ''}
              onChange={(e) => {
                const z = zones.find(item => item.id === e.target.value);
                if (z) setSelectedZone(z);
              }}
              className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-medium"
            >
              {zones.map(z => (
                <option key={z.id} value={z.id}>{z.name}</option>
              ))}
            </select>
          </div>

          <IndoreMapView
            zones={zones}
            sensors={sensors}
            shelters={shelters}
            activeRoute={routeResult?.primary_route}
            alternativeRoute={routeResult?.alternative_routes[0]}
            selectedZoneId={activeZone?.id}
            onSelectZone={(z) => setSelectedZone(z)}
            height="500px"
          />
        </div>

        {/* Selected Zone Deep Dive & Multi-Horizon Forecast (Span 1) */}
        <div className="space-y-4">
          <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Zone Inspection</span>
                <h3 className="font-bold text-sm text-slate-900 dark:text-slate-100">{activeZone?.name || 'Indore Center'}</h3>
              </div>
              <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${
                activeZone?.current_hazard_level === 'CRITICAL' ? 'bg-rose-500/10 text-rose-500' :
                activeZone?.current_hazard_level === 'HIGH' ? 'bg-orange-500/10 text-orange-500' :
                activeZone?.current_hazard_level === 'MODERATE' ? 'bg-amber-500/10 text-amber-500' : 'bg-emerald-500/10 text-emerald-500'
              }`}>
                {activeZone?.current_hazard_level}
              </span>
            </div>

            {/* Current Metrics */}
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60">
                <span className="text-slate-500 block">Water Depth</span>
                <span className="text-lg font-extrabold text-slate-900 dark:text-white">
                  {activeZone?.current_water_depth_cm.toFixed(1)} cm
                </span>
              </div>
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60">
                <span className="text-slate-500 block">Soil Saturation</span>
                <span className="text-lg font-extrabold text-slate-900 dark:text-white">
                  {activeZone?.soil_saturation_pct.toFixed(0)}%
                </span>
              </div>
            </div>

            {/* Multi-Horizon Forecast Timeline */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-slate-700 dark:text-slate-300">Predictive Horizons</span>
                <span className="text-[10px] font-mono text-emerald-500">Rational-SCS AI Model</span>
              </div>

              <div className="space-y-2">
                
                {/* Now */}
                <div className="flex items-center justify-between p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800/40 text-xs">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                    <span className="font-semibold">Current (T+0)</span>
                  </div>
                  <span className="font-mono font-bold">{activeZone?.current_water_depth_cm.toFixed(1)} cm</span>
                </div>

                {/* +1 Hour */}
                <div className="flex items-center justify-between p-2.5 rounded-lg bg-sky-50/50 dark:bg-sky-950/30 text-xs border border-sky-500/20">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-sky-500"></span>
                    <span className="font-semibold">+1 Hour Horizon</span>
                  </div>
                  <div className="text-right">
                    <span className="font-mono font-bold text-sky-600 dark:text-sky-400">
                      {activeZone?.forecast_1h?.water_depth_cm.toFixed(1) || (activeZone ? (activeZone.current_water_depth_cm * 1.25).toFixed(1) : '0.0')} cm
                    </span>
                    <span className="block text-[10px] text-slate-400">90% CI: [±6cm]</span>
                  </div>
                </div>

                {/* +2 Hour */}
                <div className="flex items-center justify-between p-2.5 rounded-lg bg-amber-50/50 dark:bg-amber-950/30 text-xs border border-amber-500/20">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-amber-500"></span>
                    <span className="font-semibold">+2 Hour Horizon</span>
                  </div>
                  <div className="text-right">
                    <span className="font-mono font-bold text-amber-600 dark:text-amber-400">
                      {activeZone?.forecast_2h?.water_depth_cm.toFixed(1) || (activeZone ? (activeZone.current_water_depth_cm * 1.15).toFixed(1) : '0.0')} cm
                    </span>
                    <span className="block text-[10px] text-slate-400">85% Confidence</span>
                  </div>
                </div>

                {/* +3 Hour */}
                <div className="flex items-center justify-between p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800/40 text-xs">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-slate-400"></span>
                    <span className="font-semibold">+3 Hour Horizon</span>
                  </div>
                  <div className="text-right">
                    <span className="font-mono font-bold">
                      {activeZone?.forecast_3h?.water_depth_cm.toFixed(1) || (activeZone ? (activeZone.current_water_depth_cm * 0.95).toFixed(1) : '0.0')} cm
                    </span>
                    <span className="block text-[10px] text-slate-400">Drainage recedes</span>
                  </div>
                </div>

              </div>
            </div>

            {/* Offline Cache Status */}
            <div className="flex items-center gap-2 p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400 text-xs">
              <ShieldCheck className="w-4 h-4 shrink-0" />
              <span>Emergency info cached offline in local storage.</span>
            </div>

          </div>
        </div>

      </div>

      {/* Flood-Aware Navigation Route Engine Widget */}
      <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-sky-500/10 text-sky-500">
              <Compass className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">Flood-Aware Route Planner</h2>
              <p className="text-xs text-slate-500">Topological Dijkstra route engine factoring in water depth impedance and impassable roads.</p>
            </div>
          </div>
          <span className="text-[11px] font-mono text-slate-400 hidden sm:inline">NetworkX Graph Routing</span>
        </div>

        {/* Input Selectors */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">Origin Ward</label>
            <select
              value={originZoneId}
              onChange={(e) => setOriginZoneId(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-semibold"
            >
              {zones.map(z => (
                <option key={z.id} value={z.id}>{z.name}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">Destination Ward</label>
            <select
              value={destZoneId}
              onChange={(e) => setDestZoneId(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-semibold"
            >
              {zones.map(z => (
                <option key={z.id} value={z.id}>{z.name}</option>
              ))}
            </select>
          </div>

          <div className="flex items-end">
            <button
              onClick={handleCalculateRoute}
              disabled={isRoutingLoading}
              className="w-full py-2.5 px-4 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold transition-all flex items-center justify-center gap-2 shadow-md shadow-sky-600/20"
            >
              {isRoutingLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Navigation className="w-4 h-4" />}
              <span>Calculate Safe Route</span>
            </button>
          </div>
        </div>

        {/* Route Output Results */}
        {routeResult && (
          <div className="mt-4 pt-4 border-t border-slate-100 dark:border-slate-800 space-y-4">
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              
              {/* Primary Safe Route Card */}
              <div className="p-4 rounded-xl border-2 border-sky-500 bg-sky-50/20 dark:bg-sky-950/20 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-sky-600 text-white uppercase">Primary Safe</span>
                    <span className="font-bold text-xs">{routeResult.primary_route.name}</span>
                  </div>
                  <span className="text-xs font-mono font-bold text-sky-600 dark:text-sky-400">
                    {routeResult.primary_route.estimated_minutes} min
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-2 text-xs">
                  <div>
                    <span className="text-slate-500 text-[11px] block">Distance</span>
                    <span className="font-bold">{routeResult.primary_route.distance_km} km</span>
                  </div>
                  <div>
                    <span className="text-slate-500 text-[11px] block">Max Depth</span>
                    <span className="font-bold text-emerald-600">{routeResult.primary_route.max_flood_depth_cm} cm</span>
                  </div>
                  <div>
                    <span className="text-slate-500 text-[11px] block">Hazard Risk</span>
                    <span className="font-bold text-emerald-600">{routeResult.primary_route.hazard_risk_score} / 100</span>
                  </div>
                </div>

                {/* Turn by Turn */}
                <div className="space-y-1 text-xs text-slate-600 dark:text-slate-300">
                  {routeResult.primary_route.turn_by_turn.map((step, idx) => (
                    <div key={idx} className="flex items-start gap-2">
                      <span className="text-sky-500 font-bold">{idx + 1}.</span>
                      <span>{step}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Alternative Route Card */}
              {routeResult.alternative_routes[0] ? (
                <div className="p-4 rounded-xl border border-rose-300 dark:border-rose-900 bg-rose-50/20 dark:bg-rose-950/20 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-600 text-white uppercase">Alternative</span>
                      <span className="font-bold text-xs">{routeResult.alternative_routes[0].name}</span>
                    </div>
                    <span className="text-xs font-mono font-bold text-rose-500">
                      {routeResult.alternative_routes[0].estimated_minutes} min
                    </span>
                  </div>

                  <div className="grid grid-cols-3 gap-2 text-xs">
                    <div>
                      <span className="text-slate-500 text-[11px] block">Distance</span>
                      <span className="font-bold">{routeResult.alternative_routes[0].distance_km} km</span>
                    </div>
                    <div>
                      <span className="text-slate-500 text-[11px] block">Max Depth</span>
                      <span className="font-bold text-rose-600">{routeResult.alternative_routes[0].max_flood_depth_cm} cm</span>
                    </div>
                    <div>
                      <span className="text-slate-500 text-[11px] block">Hazard Risk</span>
                      <span className="font-bold text-rose-600">{routeResult.alternative_routes[0].hazard_risk_score} / 100</span>
                    </div>
                  </div>

                  <div className="p-2.5 rounded-lg bg-rose-500/10 border border-rose-500/20 text-xs text-rose-600 dark:text-rose-400 flex items-start gap-2">
                    <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                    <span>{routeResult.alternative_routes[0].warning}</span>
                  </div>
                </div>
              ) : (
                <div className="p-4 rounded-xl border border-dashed border-slate-200 dark:border-slate-800 flex items-center justify-center text-xs text-slate-400">
                  No safe alternative routes available during high inundation.
                </div>
              )}

            </div>

            {/* Mandatory Safety Disclaimer */}
            <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-700 dark:text-amber-400 text-xs flex items-center gap-2">
              <Info className="w-4 h-4 shrink-0" />
              <span>{routeResult.disclaimer}</span>
            </div>

          </div>
        )}

      </div>

      {/* Emergency SOS & Citizen Incident Reporter Section */}
      <div id="sos" className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Emergency SOS Distress Form */}
        <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border-2 border-rose-500/40 shadow-lg shadow-rose-950/5 space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-rose-600 flex items-center justify-center text-white">
              <ShieldAlert className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h3 className="font-extrabold text-base text-slate-900 dark:text-slate-100">Direct Emergency SOS Dispatch</h3>
              <p className="text-xs text-slate-500">Transmits GPS coordinates to Fire Station & Municipal Command queue.</p>
            </div>
          </div>

          {sosSubmitted ? (
            <div className="p-5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-500/30 space-y-3">
              <div className="flex items-center gap-2 text-emerald-600 dark:text-emerald-400 font-bold text-sm">
                <CheckCircle2 className="w-5 h-5" />
                <span>SOS Signal Dispatched Successfully</span>
              </div>
              <div className="space-y-1 text-xs">
                <div>Tracking Code: <strong className="font-mono text-slate-900 dark:text-white">{sosSubmitted.tracking_code}</strong></div>
                <div>Status: <span className="px-2 py-0.5 rounded bg-emerald-600 text-white font-bold">{sosSubmitted.status}</span></div>
                <div>Assigned Unit: <strong>{sosSubmitted.assigned_unit || 'Palasia Fire Rescue Unit 1'}</strong></div>
              </div>
              <button
                onClick={() => setSosSubmitted(null)}
                className="w-full py-2 text-xs font-bold rounded-lg bg-emerald-600 text-white hover:bg-emerald-500 transition-colors"
              >
                Submit Another Request
              </button>
            </div>
          ) : (
            <form onSubmit={handleSOSSubmit} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">Your Name</label>
                  <input
                    type="text"
                    value={sosName}
                    onChange={(e) => setSosName(e.target.value)}
                    required
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">Contact Phone</label>
                  <input
                    type="tel"
                    value={sosPhone}
                    onChange={(e) => setSosPhone(e.target.value)}
                    required
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">People Stranded</label>
                  <input
                    type="number"
                    min={1}
                    max={50}
                    value={sosPeople}
                    onChange={(e) => setSosPeople(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                  />
                </div>
                <div className="flex items-center gap-2 pt-6">
                  <input
                    type="checkbox"
                    id="med"
                    checked={sosMedical}
                    onChange={(e) => setSosMedical(e.target.checked)}
                    className="w-4 h-4 rounded text-rose-600 accent-rose-600"
                  />
                  <label htmlFor="med" className="font-semibold text-rose-600 dark:text-rose-400 cursor-pointer">
                    Medical Emergency Present
                  </label>
                </div>
              </div>

              <div>
                <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">Specific Location Notes & Hazards</label>
                <textarea
                  rows={2}
                  value={sosNotes}
                  onChange={(e) => setSosNotes(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                />
              </div>

              <button
                type="submit"
                disabled={isSubmittingSOS}
                className="w-full py-3 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-extrabold text-xs shadow-md shadow-rose-600/30 transition-all flex items-center justify-center gap-2"
              >
                {isSubmittingSOS ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                <span>TRANSMIT RESCUE BEACON NOW</span>
              </button>
            </form>
          )}

        </div>

        {/* Citizen Waterlogging Report Form */}
        <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-sky-500/10 text-sky-500 flex items-center justify-center">
              <Droplets className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-slate-900 dark:text-slate-100">Report Street Waterlogging</h3>
              <p className="text-xs text-slate-500">Crowdsource clogged storm drains to assist municipal engineering crews.</p>
            </div>
          </div>

          {reportSuccess && (
            <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400 text-xs font-semibold">
              {reportSuccess}
            </div>
          )}

          <form onSubmit={handleReportSubmit} className="space-y-3 text-xs">
            <div>
              <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">Landmark / Street Address</label>
              <input
                type="text"
                value={reportLandmark}
                onChange={(e) => setReportLandmark(e.target.value)}
                required
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">Water Depth Severity</label>
                <select
                  value={reportSeverity}
                  onChange={(e) => setReportSeverity(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-semibold"
                >
                  <option value="MODERATE">Moderate (15-30 cm)</option>
                  <option value="HIGH">High (30-50 cm)</option>
                  <option value="CRITICAL">Critical (&gt;50 cm)</option>
                </select>
              </div>
              <div>
                <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">Catchment Ward</label>
                <select
                  value={originZoneId}
                  onChange={(e) => setOriginZoneId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                >
                  {zones.map(z => (
                    <option key={z.id} value={z.id}>{z.name}</option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">Description</label>
              <textarea
                rows={2}
                value={reportDesc}
                onChange={(e) => setReportDesc(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 dark:bg-slate-700 dark:hover:bg-slate-600 text-white font-bold text-xs transition-colors"
            >
              Submit Citizen Incident Report
            </button>
          </form>
        </div>

      </div>

      {/* Emergency Shelters List */}
      <div id="shelters" className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Home className="w-5 h-5 text-emerald-500" />
            <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">Indore Municipal Evacuation Shelters</h2>
          </div>
          <span className="text-xs text-slate-500 font-semibold">6 High Ground Camps Active</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {shelters.map((sh) => (
            <div key={sh.id} className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-emerald-500 transition-colors space-y-2">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-xs text-slate-900 dark:text-slate-100">{sh.name}</h4>
                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-600">
                  OPEN
                </span>
              </div>
              <p className="text-[11px] text-slate-500">{sh.address}</p>
              <div className="flex justify-between text-xs pt-1">
                <span className="text-slate-400">Occupancy:</span>
                <span className="font-bold font-mono">{sh.current_occupancy} / {sh.capacity} beds</span>
              </div>
              <p className="text-[10px] text-emerald-600 dark:text-emerald-400">{sh.facilities}</p>
              <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
                <span className="text-slate-500">{sh.contact_phone}</span>
                <button
                  onClick={() => {
                    const destZone = zones.find(z => z.id === 'zone_palasia') || zones[0];
                    if (destZone) setDestZoneId(destZone.id);
                    handleCalculateRoute();
                    window.scrollTo({ top: 400, behavior: 'smooth' });
                  }}
                  className="font-bold text-sky-600 hover:text-sky-500"
                >
                  Route Here &rarr;
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
