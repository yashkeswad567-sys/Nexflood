import React from 'react';
import { NavLink } from 'react-router-dom';
import {
  MapPin, ShieldAlert, Navigation, Home, Activity, Settings,
  User, CheckSquare, Wrench, Flame, Radio, Cpu, Layers,
  FileText, BellRing, Compass
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useFloodData } from '../../context/FloodDataContext';

export const Sidebar: React.FC = () => {
  const { role } = useAuth();
  const { incidents, workOrders, pumpRecs } = useFloodData();

  const pendingSOS = incidents.filter(i => i.status === 'REPORTED' || i.status === 'DISPATCHED').length;
  const pendingOrders = workOrders.filter(w => w.status !== 'COMPLETED').length;
  const pendingRecs = pumpRecs.filter(r => r.status === 'PENDING').length;

  const getRoleLinks = () => {
    switch (role) {
      case 'citizen':
        return [
          { to: '/dashboard/citizen', icon: MapPin, label: 'Flood Risk Map' },
          { to: '/route-planner', icon: Navigation, label: 'Safe Route Planner' },
          { to: '/dashboard/citizen#sos', icon: ShieldAlert, label: 'Emergency SOS', badge: 'SOS', badgeColor: 'bg-rose-500 text-white' },
          { to: '/dashboard/citizen#shelters', icon: Home, label: 'Emergency Shelters' },
          { to: '/digital-twin', icon: Activity, label: '3D Digital Twin' },
        ];
      case 'municipal':
        return [
          { to: '/dashboard/municipal', icon: Radio, label: 'City Command Center' },
          { to: '/dashboard/municipal#scenario', icon: Layers, label: 'Scenario Simulator' },
          { to: '/dashboard/municipal#pumps', icon: Cpu, label: 'Pump Recommendations', badge: pendingRecs > 0 ? String(pendingRecs) : undefined, badgeColor: 'bg-amber-500 text-white' },
          { to: '/dashboard/municipal#incidents', icon: ShieldAlert, label: 'Emergency Incident Queue', badge: pendingSOS > 0 ? String(pendingSOS) : undefined, badgeColor: 'bg-rose-500 text-white' },
          { to: '/digital-twin', icon: Activity, label: '3D Digital Twin' },
          { to: '/route-planner', icon: Compass, label: 'Network Route Engine' },
        ];
      case 'field_engineer':
        return [
          { to: '/dashboard/field-engineer', icon: Wrench, label: 'Engineering Work Orders', badge: pendingOrders > 0 ? String(pendingOrders) : undefined, badgeColor: 'bg-amber-500 text-white' },
          { to: '/dashboard/field-engineer#sensors', icon: Cpu, label: 'Sensor Diagnostics' },
          { to: '/dashboard/field-engineer#inspection', icon: CheckSquare, label: 'Asset Inspection' },
          { to: '/digital-twin', icon: Activity, label: '3D Digital Twin' },
        ];
      case 'firefighter':
        return [
          { to: '/dashboard/firefighter', icon: Flame, label: 'Emergency Dispatch Queue', badge: pendingSOS > 0 ? String(pendingSOS) : undefined, badgeColor: 'bg-rose-500 text-white animate-pulse' },
          { to: '/route-planner', icon: Navigation, label: 'Rescue Nav Route' },
          { to: '/dashboard/firefighter#status', icon: ShieldAlert, label: 'Rescue Status Lifecycle' },
          { to: '/digital-twin', icon: Activity, label: '3D Digital Twin' },
        ];
      default:
        return [];
    }
  };

  const navLinks = getRoleLinks();

  return (
    <aside className="w-64 border-r border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 backdrop-blur-md hidden md:flex flex-col justify-between p-4 shrink-0">
      <div className="space-y-6">
        
        {/* Navigation Category */}
        <div>
          <p className="text-[11px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider px-3 mb-2">
            Active Workspace
          </p>
          <nav className="space-y-1">
            {navLinks.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                className={({ isActive }) =>
                  `flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-all ${
                    isActive
                      ? 'bg-sky-50 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400 shadow-sm shadow-sky-500/10'
                      : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800/60 hover:text-slate-900 dark:hover:text-slate-200'
                  }`
                }
              >
                <div className="flex items-center gap-3">
                  <item.icon className="w-4 h-4" />
                  <span>{item.label}</span>
                </div>
                {item.badge && (
                  <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-full ${item.badgeColor || 'bg-slate-200 text-slate-700'}`}>
                    {item.badge}
                  </span>
                )}
              </NavLink>
            ))}
          </nav>
        </div>

        {/* Global Tools Category */}
        <div>
          <p className="text-[11px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider px-3 mb-2">
            System & Tools
          </p>
          <nav className="space-y-1">
            <NavLink
              to="/digital-twin"
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold transition-all ${
                  isActive
                    ? 'bg-sky-50 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400'
                    : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800/60 hover:text-slate-900 dark:hover:text-slate-200'
                }`
              }
            >
              <Activity className="w-4 h-4 text-sky-500" />
              <span>3D Digital Twin</span>
            </NavLink>
            <NavLink
              to="/settings"
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold transition-all ${
                  isActive
                    ? 'bg-sky-50 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400'
                    : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800/60 hover:text-slate-900 dark:hover:text-slate-200'
                }`
              }
            >
              <Settings className="w-4 h-4" />
              <span>Settings & Controls</span>
            </NavLink>
            <NavLink
              to="/profile"
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold transition-all ${
                  isActive
                    ? 'bg-sky-50 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400'
                    : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800/60 hover:text-slate-900 dark:hover:text-slate-200'
                }`
              }
            >
              <User className="w-4 h-4" />
              <span>User Profile</span>
            </NavLink>
          </nav>
        </div>

      </div>

      {/* System Status Mini Widget */}
      <div className="p-3 rounded-xl bg-slate-100 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 text-[11px]">
        <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-1">
          <span>AI Model</span>
          <span className="font-mono text-[10px] text-emerald-500">v1.2-hybrid</span>
        </div>
        <div className="flex items-center justify-between text-slate-500 dark:text-slate-400">
          <span>Indore Basin</span>
          <span className="font-mono text-[10px]">22.719°N, 75.857°E</span>
        </div>
      </div>
    </aside>
  );
};
