"""
Comprehensive Indore Geo-Spatial Seed Data for Indore Flood Intelligence (IFI).
Populates geographically authentic zones, sensors, drainage assets,
road segments, emergency shelters, and pre-configured role users.
"""

from datetime import datetime, timedelta
import json
import hashlib
from .database import get_connection, _lock

def hash_pw(pw: str) -> str:
    return hashlib.sha256(pw.encode('utf-8')).hexdigest()

def seed_all_data():
    """Seeds the database with authentic Indore geospatial and municipal data."""
    with _lock:
        conn = get_connection()
        cursor = conn.cursor()
        
        # Check if already seeded
        cursor.execute("SELECT COUNT(*) as cnt FROM catchment_zones")
        if cursor.fetchone()['cnt'] > 0:
            conn.close()
            return
            
        now_str = datetime.utcnow().isoformat()
        
        # 1. USERS (Demo credentials for all 4 roles)
        users = [
            ("usr_citizen_01", "citizen@indore.gov.in", hash_pw("citizen123"), "Pooja Sharma", "citizen", "+91 98260 11223", "Indore Resident (Rajwada Ward)", now_str),
            ("usr_municipal_01", "municipal@indore.gov.in", hash_pw("admin123"), "Dr. Anil Gupta", "municipal", "+91 94250 88991", "Indore Municipal Corporation (IMC) Disaster Cell", now_str),
            ("usr_engineer_01", "engineer@indore.gov.in", hash_pw("engineer123"), "Vikram Singh", "field_engineer", "+91 98261 44556", "IMC Drainage & Sewerage Division", now_str),
            ("usr_fire_01", "firefighter@indore.gov.in", hash_pw("rescue123"), "Suresh Rathore", "firefighter", "+91 98262 77889", "Indore Fire & Emergency Rescue Service (Palasia HQ)", now_str),
        ]
        cursor.executemany("""
            INSERT INTO users (id, email, password_hash, full_name, role, phone, organization, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, users)
        
        # 2. CATCHMENT ZONES (Indore Topography & Basins)
        zones = [
            (
                "zone_rajwada", "Rajwada & Sarafa Historic Basin",
                "Historic core, high impervious density, natural drainage depression near Kahn River confluence. Highly prone to flash inundation.",
                22.7196, 75.8577, 546.0, 4.8, 0.88, 92.0, 32.0,
                json.dumps([
                    [22.7150, 75.8520], [22.7250, 75.8520], [22.7260, 75.8640],
                    [22.7160, 75.8650], [22.7150, 75.8520]
                ]),
                "HIGH", 42.0, 84.0, now_str
            ),
            (
                "zone_vijay_nagar", "Vijay Nagar & AB Road Commercial Corridor",
                "Major commercial hub with multi-lane arterial roads. Stormwater runoff accumulation along AB Road underpasses.",
                22.7533, 75.8937, 558.0, 8.2, 0.76, 86.0, 55.0,
                json.dumps([
                    [22.7440, 75.8820], [22.7630, 75.8840], [22.7650, 75.9040],
                    [22.7450, 75.9020], [22.7440, 75.8820]
                ]),
                "MODERATE", 18.0, 68.0, now_str
            ),
            (
                "zone_palasia", "Palasia & Greater Kailash",
                "High density mixed residential/commercial. Intersects Pipliyapala canal feeder trunk.",
                22.7244, 75.8839, 552.0, 5.5, 0.82, 89.0, 42.0,
                json.dumps([
                    [22.7180, 75.8740], [22.7310, 75.8750], [22.7320, 75.8940],
                    [22.7190, 75.8930], [22.7180, 75.8740]
                ]),
                "LOW", 12.0, 56.0, now_str
            ),
            (
                "zone_bhanwarkuan", "Bhanwarkuan & DAVV University",
                "Educational and transit hub. Low-elevation bowl prone to waterlogging during heavy precipitation.",
                22.6926, 75.8676, 548.0, 6.1, 0.79, 88.0, 38.0,
                json.dumps([
                    [22.6840, 75.8570], [22.7020, 75.8580], [22.7030, 75.8780],
                    [22.6850, 75.8770], [22.6840, 75.8570]
                ]),
                "HIGH", 38.0, 82.0, now_str
            ),
            (
                "zone_chhavani", "Chhavani & Siyaganj Wholesale",
                "Dense wholesale trading markets flanking Kahn riverbank. Critical flood hazard zone.",
                22.7121, 75.8643, 547.0, 3.9, 0.85, 91.0, 30.0,
                json.dumps([
                    [22.7050, 75.8580], [22.7180, 75.8590], [22.7190, 75.8710],
                    [22.7060, 75.8700], [22.7050, 75.8580]
                ]),
                "HIGH", 44.0, 86.0, now_str
            ),
            (
                "zone_annapurna", "Annapurna & West Indore",
                "Established residential sector with rolling topography draining westward toward Saraswati tributary.",
                22.7012, 75.8398, 554.0, 7.0, 0.72, 84.0, 46.0,
                json.dumps([
                    [22.6920, 75.8290], [22.7110, 75.8300], [22.7120, 75.8490],
                    [22.6930, 75.8480], [22.6920, 75.8290]
                ]),
                "LOW", 10.0, 52.0, now_str
            ),
            (
                "zone_sukhlia", "Sukhlia & MR 10 Northern Sector",
                "Industrial and modern residential sector with broad engineered stormwater swales.",
                22.7621, 75.8710, 560.0, 9.4, 0.68, 82.0, 60.0,
                json.dumps([
                    [22.7530, 75.8590], [22.7720, 75.8600], [22.7730, 75.8820],
                    [22.7540, 75.8810], [22.7530, 75.8590]
                ]),
                "LOW", 8.0, 48.0, now_str
            ),
            (
                "zone_regional_park", "Pipliyapala & Bilawali Lakes",
                "Crucial urban retention lakes buffering southern flood discharge before Kahn River entry.",
                22.6789, 75.8540, 545.0, 11.2, 0.35, 74.0, 90.0,
                json.dumps([
                    [22.6680, 75.8420], [22.6900, 75.8440], [22.6910, 75.8660],
                    [22.6690, 75.8640], [22.6680, 75.8420]
                ]),
                "MODERATE", 24.0, 70.0, now_str
            ),
        ]
        cursor.executemany("""
            INSERT INTO catchment_zones (
                id, name, description, centroid_lat, centroid_lng, elevation_m,
                catchment_area_km2, impervious_surface_ratio, soil_curve_number,
                drainage_capacity_m3s, polygon_geojson, current_hazard_level,
                current_water_depth_cm, soil_saturation_pct, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, zones)
        
        # 3. SENSORS (12 IoT Stations)
        sensors = [
            ("ESP32_SN_001", "zone_rajwada", "Rajwada Chowk Drain Gauge", "ultrasonic_depth", 22.7196, 75.8577, 30.0, 50.0, 1, 96.0, 42.5, 5.8, now_str),
            ("ESP32_SN_002", "zone_rajwada", "Kahn Outfall Sluice Gauge", "ultrasonic_depth", 22.7215, 75.8595, 35.0, 55.0, 1, 94.0, 48.2, 8.4, now_str),
            ("ESP32_SN_003", "zone_vijay_nagar", "Vijay Nagar Square Underpass", "ultrasonic_depth", 22.7533, 75.8937, 25.0, 45.0, 1, 99.0, 18.0, 3.2, now_str),
            ("ESP32_SN_004", "zone_palasia", "Palasia Square Storm Culvert", "ultrasonic_depth", 22.7244, 75.8839, 28.0, 48.0, 1, 92.0, 12.4, 2.1, now_str),
            ("ESP32_SN_005", "zone_bhanwarkuan", "Bhanwarkuan Main Nullah", "ultrasonic_depth", 22.6926, 75.8676, 30.0, 50.0, 1, 88.0, 38.6, 6.7, now_str),
            ("ESP32_SN_006", "zone_chhavani", "Chhavani Kahn River Confluence", "doppler_flow", 22.7121, 75.8643, 35.0, 55.0, 1, 95.0, 44.1, 9.2, now_str),
            ("ESP32_SN_007", "zone_annapurna", "Saraswati River Gauge Station", "doppler_flow", 22.7012, 75.8398, 25.0, 45.0, 1, 97.0, 10.5, 1.8, now_str),
            ("ESP32_SN_008", "zone_regional_park", "Pipliyapala Lake Sluice Weirs", "ultrasonic_depth", 22.6789, 75.8540, 40.0, 65.0, 1, 100.0, 24.0, 14.5, now_str),
            ("ESP32_SN_009", "zone_regional_park", "Bilawali Lake Inflow Canal", "doppler_flow", 22.6710, 75.8490, 40.0, 65.0, 1, 91.0, 22.8, 12.1, now_str),
            ("ESP32_SN_010", "zone_sukhlia", "MR 10 Railway Crossing Drain", "ultrasonic_depth", 22.7621, 75.8710, 25.0, 45.0, 1, 93.0, 8.2, 1.2, now_str),
            ("ESP32_SN_011", "zone_annapurna", "Annapurna Temple Storm Trunk", "ultrasonic_depth", 22.6980, 75.8420, 25.0, 45.0, 1, 89.0, 9.4, 1.4, now_str),
            ("ESP32_SN_012", "zone_rajwada", "Malharganj Drainage Outfall", "ultrasonic_depth", 22.7230, 75.8540, 30.0, 50.0, 1, 95.0, 41.0, 5.2, now_str),
        ]
        cursor.executemany("""
            INSERT INTO sensor_devices (
                id, zone_id, name, sensor_type, latitude, longitude,
                warning_threshold_cm, critical_threshold_cm, is_active,
                battery_pct, current_water_level_cm, current_flow_rate_m3s, last_heartbeat
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, sensors)
        
        # 4. DRAINAGE ASSETS (Pumps & Sluice Gates)
        assets = [
            ("PUMP_KAHN_01", "zone_rajwada", "Kahn Outfall Heavy Storm Pump #1", "stormwater_pump", 22.7215, 75.8595, 15.0, "RUNNING", 12.0, now_str),
            ("PUMP_KAHN_02", "zone_rajwada", "Kahn Outfall Heavy Storm Pump #2", "stormwater_pump", 22.7216, 75.8596, 15.0, "OPERATIONAL", 10.0, now_str),
            ("PUMP_RAJWADA_01", "zone_rajwada", "Rajwada Low Basin Sump Pump", "stormwater_pump", 22.7196, 75.8577, 10.0, "RUNNING", 25.0, now_str),
            ("PUMP_VIJAY_01", "zone_vijay_nagar", "Vijay Nagar Underpass Ejector", "stormwater_pump", 22.7533, 75.8937, 12.0, "OPERATIONAL", 8.0, now_str),
            ("PUMP_BHANWAR_01", "zone_bhanwarkuan", "Bhanwarkuan Relief Pump", "stormwater_pump", 22.6926, 75.8676, 8.0, "RUNNING", 30.0, now_str),
            ("GATE_PIPLIYA_01", "zone_regional_park", "Pipliyapala Lake Inflow Sluice Gate", "sluice_gate", 22.6789, 75.8540, 25.0, "OPERATIONAL", 5.0, now_str),
            ("GATE_BILAWALI_01", "zone_regional_park", "Bilawali Spillway Diversion Gate", "sluice_gate", 22.6710, 75.8490, 30.0, "OPERATIONAL", 7.0, now_str),
            ("PUMP_CHHAVANI_01", "zone_chhavani", "Chhavani Market Drainage Sump", "stormwater_pump", 22.7121, 75.8643, 8.0, "RUNNING", 22.0, now_str),
        ]
        cursor.executemany("""
            INSERT INTO drainage_assets (
                id, zone_id, name, asset_type, latitude, longitude,
                rated_capacity_m3s, current_status, silt_blockage_pct, last_inspected_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, assets)
        
        # 5. EMERGENCY SHELTERS (6 High Ground Relief Centers)
        shelters = [
            ("SHELTER_01", "Holkar Stadium Disaster Relief Camp", 22.7258, 75.8778, "MG Road, Race Course Road", 2500, 340, "+91 731 2541100", "Medical Aid, Purified Water, Emergency Rations, DG Power Backup", 1),
            ("SHELTER_02", "Nehru Stadium Evacuation Center", 22.7130, 75.8820, "Residency Area, Near Zoo", 1800, 210, "+91 731 2512345", "First Aid, Dormitory, High Ground Kitchen, Ambulance Bay", 1),
            ("SHELTER_03", "Gandhi Hall Civic Relief Hub", 22.7210, 75.8620, "Mahatma Gandhi Road", 800, 150, "+91 731 2534567", "Drinking Water, Restrooms, Temporary Beds, VHF Radio Link", 1),
            ("SHELTER_04", "Scheme 54 Community Hall", 22.7550, 75.8900, "Near Meghdoot Garden, Vijay Nagar", 1200, 80, "+91 731 2556789", "Kitchen Facility, Clean Sanitation, Family Dorms, Wi-Fi", 1),
            ("SHELTER_05", "DAVV University Auditorium Shelter", 22.6950, 75.8720, "Takshashila Campus, Khandwa Road", 1500, 195, "+91 731 2468901", "Medical Station, Hot Meals, Charging Kiosks, Child Care", 1),
            ("SHELTER_06", "Annapurna Community Relief Center", 22.7030, 75.8380, "Annapurna Road, Near Temple", 950, 110, "+91 731 2489012", "Dry Rations, Medical Staff, Clean Water, Sanitized Beds", 1),
        ]
        cursor.executemany("""
            INSERT INTO emergency_shelters (
                id, name, latitude, longitude, address, capacity,
                current_occupancy, contact_phone, facilities, is_active
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, shelters)
        
        # 6. ROAD NETWORK SEGMENTS (Indore Graph)
        roads = [
            ("ROAD_01", "MG Road Central (Rajwada to High Court)", "zone_rajwada", 22.7196, 75.8577, 22.7240, 75.8720, 1.8, 35.0, 546.5, 42.0, 1),
            ("ROAD_02", "Jawahar Marg (Rajwada to Malharganj)", "zone_rajwada", 22.7196, 75.8577, 22.7230, 75.8520, 0.9, 30.0, 545.8, 48.0, 1),
            ("ROAD_03", "AB Road South (Palasia to Bhanwarkuan)", "zone_palasia", 22.7244, 75.8839, 22.6926, 75.8676, 4.2, 45.0, 550.0, 14.0, 0),
            ("ROAD_04", "AB Road North (Palasia to Vijay Nagar)", "zone_vijay_nagar", 22.7244, 75.8839, 22.7533, 75.8937, 3.8, 50.0, 555.0, 12.0, 0),
            ("ROAD_05", "Ring Road South Bypass (Bhanwarkuan to Bengali)", "zone_bhanwarkuan", 22.6926, 75.8676, 22.7150, 75.9050, 5.1, 60.0, 552.0, 6.0, 0),
            ("ROAD_06", "MR 10 Expressway (Vijay Nagar to Super Corridor)", "zone_sukhlia", 22.7533, 75.8937, 22.7650, 75.8500, 5.8, 65.0, 560.0, 5.0, 0),
            ("ROAD_07", "Annapurna Road (Annapurna to Mhow Naka)", "zone_annapurna", 22.7012, 75.8398, 22.7130, 75.8480, 2.1, 40.0, 553.0, 10.0, 0),
            ("ROAD_08", "Chhavani Main Road (Chhavani to Railway Station)", "zone_chhavani", 22.7121, 75.8643, 22.7180, 75.8700, 1.2, 30.0, 547.0, 36.0, 1),
            ("ROAD_09", "Bypass Outer Ring (MR 10 to Regional Park)", "zone_regional_park", 22.7533, 75.8937, 22.6789, 75.8540, 9.6, 70.0, 558.0, 2.0, 0),
            ("ROAD_10", "Sardar Patel Marg (High Court to Palasia)", "zone_palasia", 22.7240, 75.8720, 22.7244, 75.8839, 1.4, 40.0, 551.0, 8.0, 0),
        ]
        cursor.executemany("""
            INSERT INTO road_segments (
                id, name, zone_id, start_lat, start_lng, end_lat, end_lng,
                length_km, base_speed_kmh, elevation_m, current_water_depth_cm, is_blocked
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, roads)
        
        # 7. INITIAL WORK ORDERS (For Field Engineer)
        work_orders = [
            ("WO_101", "PUMP_KAHN_01", "usr_engineer_01", "Desilt Sump Basin & Check Impeller", "Heavy silt load reported after 45mm rainfall. Inspect suction screen.", "URGENT", "IN_PROGRESS", 25.0, None, "Suction screen partially obstructed with debris. Commencing clearing.", now_str, None),
            ("WO_102", "PUMP_BHANWAR_01", "usr_engineer_01", "Clear Debris Grating & Flow Calibration", "Scheduled preventive inspection and clearing of inlet channel.", "ROUTINE", "PENDING", 30.0, None, "Pending site arrival.", now_str, None),
            ("WO_103", "GATE_PIPLIYA_01", "usr_engineer_01", "Hydraulic Sluice Actuator Lubrication", "Monthly service of retention basin control gates.", "ROUTINE", "COMPLETED", 12.0, 5.0, "Hydraulic cylinders tested, actuator functioning within 0.2s tolerance.", now_str, now_str),
        ]
        cursor.executemany("""
            INSERT INTO work_orders (
                id, asset_id, assigned_to, title, description, priority,
                status, initial_silt_pct, final_silt_pct, inspection_notes, created_at, completed_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, work_orders)
        
        # 8. INITIAL INCIDENTS / SOS
        incidents = [
            (
                "INC_SOS_001", "IND-SOS-1042", "Sunita Jain", "+91 98260 55667",
                "EMERGENCY_SOS", 22.7185, 75.8562, "Sarafa Bazaar, Near Gopal Mandir",
                "CRITICAL", 4, 1, "DISPATCHED", "Palasia Fire Station - Rescue Boat 2", "usr_fire_01",
                "Ground floor flooded with 45cm water. Elderly grandmother requires wheelchair assistance.",
                "Dispatched Rescue Boat 2 with 3 firefighters.", now_str, now_str
            ),
            (
                "INC_SOS_002", "IND-SOS-1043", "Mohammad Farooq", "+91 94250 22334",
                "EMERGENCY_SOS", 22.6930, 75.8660, "Bhanwarkuan Square, Near Petrol Pump",
                "HIGH", 2, 0, "REPORTED", None, None,
                "Car stalled in middle of intersection, water touching car window sill.",
                None, now_str, now_str
            ),
            (
                "INC_REP_001", "IND-REP-2011", "Ramesh Patidar", "+91 98262 99001",
                "WATERLOGGING_REPORT", 22.7125, 75.8638, "Chhavani Main Gate, Siyaganj",
                "MODERATE", 0, 0, "VERIFIED", "IMC Drainage Ward Team 4", "usr_engineer_01",
                "Main storm drain backed up due to plastic crate obstruction.",
                "Ward team en route with mobile desilting unit.", now_str, now_str
            ),
        ]
        cursor.executemany("""
            INSERT INTO incidents (
                id, tracking_code, reported_by_name, phone, incident_type,
                latitude, longitude, landmark_address, severity, people_stranded,
                medical_emergency, status, assigned_unit, assigned_personnel_id,
                notes, resolution_notes, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, incidents)
        
        # 9. PUMP RECOMMENDATIONS
        pump_recs = [
            ("REC_001", "PUMP_KAHN_02", "zone_rajwada", "START_PUMP", "URGENT", "Kahn River inflow at 28.4 m³/s exceeds 85% single-pump conveyance. Engage secondary 15 m³/s pump.", 28.4, "PENDING", None, now_str),
            ("REC_002", "PUMP_BHANWAR_01", "zone_bhanwarkuan", "INCREASE_RPM", "ADVISORY", "Water level at Bhanwarkuan gauge reached 38.6cm (warning threshold 30cm). Increase ejector discharge to 100%.", 14.2, "PENDING", None, now_str),
        ]
        cursor.executemany("""
            INSERT INTO pump_recommendations (
                id, asset_id, zone_id, recommended_action, urgency, rationale,
                inflow_rate_m3s, status, operator_override_notes, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, pump_recs)
        
        # 10. ACTIVE ALERTS
        alerts = [
            ("ALERT_001", "FLASH FLOOD WARNING: Rajwada & Sarafa Basin", "CRITICAL", "zone_rajwada,zone_chhavani", "Intense precipitation (45mm/h) has triggered waterlogging in historic low-lying areas. Avoid underpasses and MG Road.", "Evacuate basement shops. Follow flood-aware routes to Holkar Stadium or Gandhi Hall shelters.", now_str, (datetime.utcnow() + timedelta(hours=6)).isoformat(), 1),
            ("ALERT_002", "Heavy Rain Advisory: Bhanwarkuan & University Corridor", "HIGH", "zone_bhanwarkuan", "Water level rising rapidly along BRTS corridor. Drive cautiously.", "Avoid waterlogged junctions. Use alternative Ring Road routes.", now_str, (datetime.utcnow() + timedelta(hours=4)).isoformat(), 1),
        ]
        cursor.executemany("""
            INSERT INTO alerts (
                id, title, severity, target_zones, message, instructions, created_at, expires_at, is_active
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, alerts)
        
        # 11. SYSTEM SIMULATION STATE
        cursor.execute("""
            INSERT OR REPLACE INTO system_state (key, value, updated_at)
            VALUES 
                ('scenario_name', 'Monsoon Surge', ?),
                ('rainfall_rate_mmh', '32.5', ?),
                ('soil_moisture_pct', '76.0', ?),
                ('simulation_multiplier', '1.0', ?)
        """, (now_str, now_str, now_str, now_str))
        
        conn.commit()
        conn.close()
