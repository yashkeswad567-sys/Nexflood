import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import {
  FloodStatusSummary, SensorDevice, DrainageAsset, Incident,
  WorkOrder, PumpRecommendation, EmergencyShelter, AlertNotification
} from '../types';
import { api } from '../services/api';

interface FloodDataContextType {
  floodStatus: FloodStatusSummary | null;
  sensors: SensorDevice[];
  assets: DrainageAsset[];
  incidents: Incident[];
  workOrders: WorkOrder[];
  pumpRecs: PumpRecommendation[];
  shelters: EmergencyShelter[];
  alerts: AlertNotification[];
  isLoading: boolean;
  refreshData: () => Promise<void>;
  triggerScenario: (scenarioName: string, rainfallMmh: number) => Promise<void>;
  submitSOS: (payload: any) => Promise<Incident>;
  updateIncidentStatus: (incidentId: string, status: string, notes?: string) => Promise<void>;
  assignIncident: (incidentId: string, unit: string) => Promise<void>;
  updateAssetStatus: (assetId: string, status: string) => Promise<void>;
  completeWorkOrder: (woId: string, finalSilt: number, notes: string) => Promise<void>;
  actOnRecommendation: (recId: string, action: 'ACCEPT' | 'OVERRIDE', notes?: string) => Promise<void>;
  broadcastAlert: (payload: any) => Promise<void>;
}

const FloodDataContext = createContext<FloodDataContextType | null>(null);

export const FloodDataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [floodStatus, setFloodStatus] = useState<FloodStatusSummary | null>(null);
  const [sensors, setSensors] = useState<SensorDevice[]>([]);
  const [assets, setAssets] = useState<DrainageAsset[]>([]);
  const [incidents, setIncidents] = useState<Incident[]>([]);
  const [workOrders, setWorkOrders] = useState<WorkOrder[]>([]);
  const [pumpRecs, setPumpRecs] = useState<PumpRecommendation[]>([]);
  const [shelters, setShelters] = useState<EmergencyShelter[]>([]);
  const [alerts, setAlerts] = useState<AlertNotification[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  const refreshData = useCallback(async () => {
    try {
      const [statusRes, sensRes, assetRes, incRes, woRes, recRes, shRes, alRes] = await Promise.all([
        api.getFloodStatus(),
        api.getSensors(),
        api.getAssets(),
        api.getIncidents(),
        api.getWorkOrders(),
        api.getPumpRecommendations(),
        api.getShelters(),
        api.getAlerts()
      ]);
      setFloodStatus(statusRes);
      setSensors(sensRes);
      setAssets(assetRes);
      setIncidents(incRes);
      setWorkOrders(woRes);
      setPumpRecs(recRes);
      setShelters(shRes);
      setAlerts(alRes);
    } catch (e) {
      console.warn('Data sync warning:', e);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    refreshData();
    // 8-second live sync interval across all dashboards
    const interval = setInterval(refreshData, 8000);
    return () => clearInterval(interval);
  }, [refreshData]);

  const triggerScenario = async (scenarioName: string, rainfallMmh: number) => {
    setIsLoading(true);
    await api.simulateScenario(scenarioName, rainfallMmh);
    await refreshData();
    setIsLoading(false);
  };

  const submitSOS = async (payload: any) => {
    const res = await api.submitSOS(payload);
    await refreshData();
    return res;
  };

  const updateIncidentStatus = async (incidentId: string, status: string, notes?: string) => {
    await api.updateIncidentStatus(incidentId, status, notes);
    await refreshData();
  };

  const assignIncident = async (incidentId: string, unit: string) => {
    await api.assignIncident(incidentId, unit);
    await refreshData();
  };

  const updateAssetStatus = async (assetId: string, status: string) => {
    await api.updateAssetStatus(assetId, status);
    await refreshData();
  };

  const completeWorkOrder = async (woId: string, finalSilt: number, notes: string) => {
    await api.completeWorkOrder(woId, finalSilt, notes);
    await refreshData();
  };

  const actOnRecommendation = async (recId: string, action: 'ACCEPT' | 'OVERRIDE', notes?: string) => {
    await api.actOnRecommendation(recId, action, notes);
    await refreshData();
  };

  const broadcastAlert = async (payload: any) => {
    await api.broadcastAlert(payload);
    await refreshData();
  };

  return (
    <FloodDataContext.Provider
      value={{
        floodStatus,
        sensors,
        assets,
        incidents,
        workOrders,
        pumpRecs,
        shelters,
        alerts,
        isLoading,
        refreshData,
        triggerScenario,
        submitSOS,
        updateIncidentStatus,
        assignIncident,
        updateAssetStatus,
        completeWorkOrder,
        actOnRecommendation,
        broadcastAlert,
      }}
    >
      {children}
    </FloodDataContext.Provider>
  );
};

export const useFloodData = () => {
  const ctx = useContext(FloodDataContext);
  if (!ctx) throw new Error('useFloodData must be used within FloodDataProvider');
  return ctx;
};
