import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Waves, ShieldCheck, ArrowRight, UserCheck, Lock, Mail } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { Role } from '../types';

export const LoginPage: React.FC = () => {
  const { login, switchDemoRole } = useAuth();
  const [email, setEmail] = useState<string>('citizen@indore.gov.in');
  const [password, setPassword] = useState<string>('password123');
  const [selectedRole, setSelectedRole] = useState<Role>('citizen');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const navigate = useNavigate();

  const handleStandardLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      await login(email, selectedRole);
      navigate(`/dashboard/${selectedRole.replace('_', '-')}`);
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDemoLogin = async (r: Role) => {
    setIsLoading(true);
    try {
      await switchDemoRole(r);
      if (r === 'citizen') navigate('/dashboard/citizen');
      else if (r === 'municipal') navigate('/dashboard/municipal');
      else if (r === 'field_engineer') navigate('/dashboard/field-engineer');
      else if (r === 'firefighter') navigate('/dashboard/firefighter');
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-[85vh] flex items-center justify-center p-4">
      <div className="w-full max-w-md p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-6">
        
        {/* Brand Header */}
        <div className="text-center space-y-2">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-sky-600 to-indigo-600 flex items-center justify-center text-white mx-auto shadow-lg shadow-sky-500/20">
            <Waves className="w-6 h-6 animate-pulse" />
          </div>
          <h2 className="text-xl font-extrabold text-slate-900 dark:text-white">
            Access Indore Flood Intel
          </h2>
          <p className="text-xs text-slate-500">
            Select an enterprise role or enter credentials to access your dashboard.
          </p>
        </div>

        {/* Quick Demo Mode One-Click Login Pills */}
        <div className="space-y-2 pt-2">
          <div className="flex items-center justify-between text-[11px] font-bold text-slate-400 uppercase tracking-wider">
            <span>Instant Demo Access</span>
            <span className="text-sky-500">No Credentials Needed</span>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs">
            <button
              type="button"
              onClick={() => handleDemoLogin('citizen')}
              className="p-3 rounded-xl border border-sky-500/30 bg-sky-50/50 dark:bg-sky-950/30 text-sky-700 dark:text-sky-300 font-bold text-left hover:scale-[1.02] transition-transform"
            >
              <div className="text-[10px] text-sky-500 uppercase">Public</div>
              <div>Citizen Portal</div>
            </button>

            <button
              type="button"
              onClick={() => handleDemoLogin('municipal')}
              className="p-3 rounded-xl border border-indigo-500/30 bg-indigo-50/50 dark:bg-indigo-950/30 text-indigo-700 dark:text-indigo-300 font-bold text-left hover:scale-[1.02] transition-transform"
            >
              <div className="text-[10px] text-indigo-500 uppercase">Command</div>
              <div>Municipal Cell</div>
            </button>

            <button
              type="button"
              onClick={() => handleDemoLogin('field_engineer')}
              className="p-3 rounded-xl border border-amber-500/30 bg-amber-50/50 dark:bg-amber-950/30 text-amber-700 dark:text-amber-300 font-bold text-left hover:scale-[1.02] transition-transform"
            >
              <div className="text-[10px] text-amber-500 uppercase">Drainage</div>
              <div>Field Engineer</div>
            </button>

            <button
              type="button"
              onClick={() => handleDemoLogin('firefighter')}
              className="p-3 rounded-xl border border-rose-500/30 bg-rose-50/50 dark:bg-rose-950/30 text-rose-700 dark:text-rose-300 font-bold text-left hover:scale-[1.02] transition-transform"
            >
              <div className="text-[10px] text-rose-500 uppercase">Rescue 101</div>
              <div>Fire & Rescue</div>
            </button>
          </div>
        </div>

        {/* Separator */}
        <div className="relative flex py-2 items-center">
          <div className="flex-grow border-t border-slate-200 dark:border-slate-800"></div>
          <span className="flex-shrink mx-4 text-slate-400 text-[10px] uppercase font-bold">Or Standard Login</span>
          <div className="flex-grow border-t border-slate-200 dark:border-slate-800"></div>
        </div>

        {/* Standard Form */}
        <form onSubmit={handleStandardLogin} className="space-y-4 text-xs">
          <div>
            <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">Email Address</label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
              />
            </div>
          </div>

          <div>
            <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">Password</label>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
              />
            </div>
          </div>

          <div>
            <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">Select Persona Role</label>
            <select
              value={selectedRole}
              onChange={(e) => setSelectedRole(e.target.value as Role)}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-semibold"
            >
              <option value="citizen">Citizen (Indore Resident)</option>
              <option value="municipal">Municipal Official (Disaster Officer)</option>
              <option value="field_engineer">Field Drainage Engineer</option>
              <option value="firefighter">Firefighter / Emergency Responder</option>
            </select>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-3 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs shadow-md shadow-sky-600/20 transition-all flex items-center justify-center gap-2"
          >
            <span>Sign In to Dashboard</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

      </div>
    </div>
  );
};
