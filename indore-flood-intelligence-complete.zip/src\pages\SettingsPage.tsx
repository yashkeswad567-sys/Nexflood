import React, { useState } from 'react';
import { Settings, Moon, Sun, Bell, Database, Shield, Radio, Key, CheckCircle2, Sparkles, Eye, EyeOff, MapPin } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { useAuth } from '../context/AuthContext';

export const SettingsPage: React.FC = () => {
  const { theme, toggleTheme } = useTheme();
  const { role, user } = useAuth();

  const [autoSync, setAutoSync] = useState(true);
  const [pushAlerts, setPushAlerts] = useState(true);
  const [offlineCache, setOfflineCache] = useState(true);
  const [apiKey, setApiKey] = useState('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');
  const [showKey, setShowKey] = useState(false);
  const [googleKey, setGoogleKey] = useState('AIzaSyC75AxE4cM45Y42RDi6IrKr_gZ3Z4zsneQ');
  const [showGoogleKey, setShowGoogleKey] = useState(false);
  const [savedMsg, setSavedMsg] = useState(false);

  const handleSave = () => {
    localStorage.setItem('ifi_openai_api_key', apiKey);
    localStorage.setItem('ifi_google_maps_key', googleKey);
    setSavedMsg(true);
    setTimeout(() => setSavedMsg(false), 3000);
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-4xl mx-auto space-y-6">
      
      <div className="flex items-center justify-between p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-sky-500/10 text-sky-500">
            <Settings className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">System Settings & Preferences</h1>
            <p className="text-xs text-slate-500">Telemetry synchronization, themes, and notification channels.</p>
          </div>
        </div>

        {savedMsg && (
          <span className="flex items-center gap-1.5 text-xs font-bold text-emerald-500">
            <CheckCircle2 className="w-4 h-4" />
            <span>Settings Saved</span>
          </span>
        )}
      </div>

      <div className="space-y-4">
        
        {/* Appearance Card */}
        <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white">Interface & Display</h3>
          
          <div className="flex items-center justify-between text-xs py-2 border-b border-slate-100 dark:border-slate-800">
            <div>
              <span className="font-semibold block text-slate-700 dark:text-slate-300">Theme Preference</span>
              <span className="text-slate-500">Toggle between high-contrast dark mode and bright enterprise light mode.</span>
            </div>
            <button
              onClick={toggleTheme}
              className="flex items-center gap-2 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 font-semibold"
            >
              {theme === 'dark' ? <Moon className="w-4 h-4 text-indigo-400" /> : <Sun className="w-4 h-4 text-amber-500" />}
              <span className="capitalize">{theme} Mode</span>
            </button>
          </div>

          <div className="flex items-center justify-between text-xs py-2">
            <div>
              <span className="font-semibold block text-slate-700 dark:text-slate-300">Offline Emergency Data Caching</span>
              <span className="text-slate-500">Stores shelter locations, emergency contacts, and evacuation routes in browser storage.</span>
            </div>
            <input
              type="checkbox"
              checked={offlineCache}
              onChange={(e) => setOfflineCache(e.target.checked)}
              className="w-4 h-4 accent-sky-600 rounded cursor-pointer"
            />
          </div>
        </div>

        {/* Telemetry & Synchronization Card */}
        <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white">Real-Time Sync & Telemetry</h3>

          <div className="flex items-center justify-between text-xs py-2 border-b border-slate-100 dark:border-slate-800">
            <div>
              <span className="font-semibold block text-slate-700 dark:text-slate-300">8-Second Live Telemetry Polling</span>
              <span className="text-slate-500">Syncs water levels, pump states, and SOS incident updates across all tabs.</span>
            </div>
            <input
              type="checkbox"
              checked={autoSync}
              onChange={(e) => setAutoSync(e.target.checked)}
              className="w-4 h-4 accent-sky-600 rounded cursor-pointer"
            />
          </div>

          <div className="flex items-center justify-between text-xs py-2">
            <div>
              <span className="font-semibold block text-slate-700 dark:text-slate-300">Flash Flood Push Notifications</span>
              <span className="text-slate-500">Receive audio chime and banner for CRITICAL & HIGH alerts.</span>
            </div>
            <input
              type="checkbox"
              checked={pushAlerts}
              onChange={(e) => setPushAlerts(e.target.checked)}
              className="w-4 h-4 accent-sky-600 rounded cursor-pointer"
            />
          </div>
        </div>

        {/* OpenAI Flood Intelligence Copilot Card */}
        <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-purple-500/10 text-purple-500">
                <Sparkles className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">OpenAI Intelligence Engine Integration</h3>
                <p className="text-xs text-slate-500">Powers the 24/7 Indore Flood AI Emergency Copilot and hydrological interpretations.</p>
              </div>
            </div>
            <span className="flex items-center gap-1.5 text-xs font-bold text-emerald-500 bg-emerald-500/10 px-2.5 py-1 rounded-full border border-emerald-500/20">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              Key Connected
            </span>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
              Active OpenAI API Key (Loaded from environment & .env)
            </label>
            <div className="relative flex items-center">
              <input
                type={showKey ? 'text' : 'password'}
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                className="w-full pl-3 pr-24 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-xs font-mono text-slate-900 dark:text-white focus:outline-none focus:border-sky-500"
              />
              <button
                type="button"
                onClick={() => setShowKey(!showKey)}
                className="absolute right-2 px-2.5 py-1 rounded-lg bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 text-[11px] font-semibold text-slate-600 dark:text-slate-300 transition-colors flex items-center gap-1"
              >
                {showKey ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                <span>{showKey ? 'Hide' : 'Reveal'}</span>
              </button>
            </div>
            <p className="text-[11px] text-slate-400">
              Default model: <span className="font-mono font-semibold text-sky-500">gpt-4o-mini</span> • Used across Citizen Emergency SOS, Municipal Command, and Tactical Navigation routes.
            </p>
          </div>
        </div>

        {/* Google Maps Platform Integration Card */}
        <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-sky-500/10 text-sky-500">
                <MapPin className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">Google Maps Platform Integration</h3>
                <p className="text-xs text-slate-500">Powers high-resolution satellite imagery, terrain tiles, places lookup, and geometry tools.</p>
              </div>
            </div>
            <span className="flex items-center gap-1.5 text-xs font-bold text-emerald-500 bg-emerald-500/10 px-2.5 py-1 rounded-full border border-emerald-500/20">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              Google Maps Active
            </span>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
              Active Google Maps API Key
            </label>
            <div className="relative flex items-center">
              <input
                type={showGoogleKey ? 'text' : 'password'}
                value={googleKey}
                onChange={(e) => setGoogleKey(e.target.value)}
                className="w-full pl-3 pr-24 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-xs font-mono text-slate-900 dark:text-white focus:outline-none focus:border-sky-500"
              />
              <button
                type="button"
                onClick={() => setShowGoogleKey(!showGoogleKey)}
                className="absolute right-2 px-2.5 py-1 rounded-lg bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 text-[11px] font-semibold text-slate-600 dark:text-slate-300 transition-colors flex items-center gap-1"
              >
                {showGoogleKey ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                <span>{showGoogleKey ? 'Hide' : 'Reveal'}</span>
              </button>
            </div>
            <p className="text-[11px] text-slate-400">
              Enables real-time toggling between <span className="font-semibold text-sky-500">Google Satellite Hybrid</span>, <span className="font-semibold text-sky-500">Google Terrain</span>, and <span className="font-semibold text-sky-500">OpenStreetMap</span> across all dashboards.
            </p>
          </div>
        </div>

        {/* System Diagnostics */}
        <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3 text-xs">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white">Version & Environment Information</h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60">
              <span className="text-slate-400 block text-[10px]">App Version</span>
              <span className="font-bold">v1.2.0-SaaS</span>
            </div>
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60">
              <span className="text-slate-400 block text-[10px]">AI Engine</span>
              <span className="font-bold text-sky-500">Rational-SCS v1.2</span>
            </div>
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60">
              <span className="text-slate-400 block text-[10px]">Active Persona</span>
              <span className="font-bold uppercase text-emerald-500">{role}</span>
            </div>
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60">
              <span className="text-slate-400 block text-[10px]">Database</span>
              <span className="font-bold">SQLite / PostGIS</span>
            </div>
          </div>
        </div>

        <div className="flex justify-end">
          <button
            onClick={handleSave}
            className="px-6 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs shadow-md transition-colors"
          >
            Save All Preferences
          </button>
        </div>

      </div>

    </div>
  );
};
