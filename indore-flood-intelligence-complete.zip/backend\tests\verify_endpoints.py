"""
Test & Verify Indore Flood Intelligence REST API Endpoints.
Starts a test server instance or verifies an active instance, and performs live HTTP GET requests to:
1. /api/v1/flood/status
2. /api/v1/iot/sensors
3. /api/v1/assets
4. /api/v1/incidents
5. /api/v1/work-orders
6. /api/v1/iot/recommendations
7. /api/v1/shelters
8. /api/v1/alerts
9. /health
"""

import sys
import os
import time
import threading
import urllib.request
import json

# Ensure project root is in sys.path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from backend.app.server import IFIRequestHandler, DualStackServer
from backend.app.database import init_db
from backend.app.seed_data import seed_all_data

PORT = 8000
HOST = "127.0.0.1"

ENDPOINTS = [
    ("Flood Status", "/api/v1/flood/status"),
    ("Sensors", "/api/v1/iot/sensors"),
    ("Drainage Assets", "/api/v1/assets"),
    ("Incidents", "/api/v1/incidents"),
    ("Work Orders", "/api/v1/work-orders"),
    ("Pump Recommendations", "/api/v1/iot/recommendations"),
    ("Emergency Shelters", "/api/v1/shelters"),
    ("Alerts", "/api/v1/alerts"),
    ("Health Check", "/health")
]

def test_endpoints(base_url: str):
    print(f"\n========================================================")
    print(f"VERIFYING ENDPOINTS ON: {base_url}")
    print(f"========================================================")
    
    passed = 0
    results = {}
    for name, ep in ENDPOINTS:
        url = f"{base_url}{ep}"
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "IFI-Verifier/1.0"})
            with urllib.request.urlopen(req, timeout=5) as response:
                status_code = response.getcode()
                raw_body = response.read().decode("utf-8")
                parsed_json = json.loads(raw_body)
                
                # Verify payload structure
                count = len(parsed_json) if isinstance(parsed_json, list) else len(parsed_json.keys())
                results[ep] = {
                    "name": name,
                    "status": status_code,
                    "payload_type": type(parsed_json).__name__,
                    "items_or_keys": count,
                    "sample": list(parsed_json.keys()) if isinstance(parsed_json, dict) else f"{count} records"
                }
                print(f" [PASS] {status_code} - {name.ljust(22)} ({ep}) -> {results[ep]['sample']}")
                passed += 1
        except Exception as e:
            print(f" [FAIL] {name.ljust(22)} ({ep}) -> Error: {e}")
            results[ep] = {"name": name, "error": str(e)}
            
    print(f"\nRESULTS: {passed}/{len(ENDPOINTS)} endpoints responded successfully.")
    return passed == len(ENDPOINTS), results

def main():
    target_port = int(sys.argv[1]) if len(sys.argv) > 1 else PORT
    base_url = f"http://{HOST}:{target_port}"
    
    # Check if a server is already listening
    server_running = False
    try:
        with urllib.request.urlopen(f"{base_url}/health", timeout=1) as r:
            if r.getcode() == 200:
                server_running = True
    except Exception:
        server_running = False

    server_thread = None
    httpd = None

    if not server_running:
        print(f"No existing server detected on {base_url}. Starting test server thread...")
        init_db()
        seed_all_data()
        httpd = DualStackServer((HOST, target_port), IFIRequestHandler)
        server_thread = threading.Thread(target=httpd.serve_forever, daemon=True)
        server_thread.start()
        time.sleep(0.5)
    else:
        print(f"Detected running server on {base_url}.")

    success, _ = test_endpoints(base_url)

    if httpd:
        httpd.shutdown()
        httpd.server_close()
        print("Test server shutdown complete.")

    sys.exit(0 if success else 1)

if __name__ == "__main__":
    main()
