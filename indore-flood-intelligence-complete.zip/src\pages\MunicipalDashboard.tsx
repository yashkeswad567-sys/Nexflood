import React, { useState } from 'react';
import {
  Radio, Droplets, Waves, Cpu, ShieldAlert, CheckSquare,
  AlertTriangle, Play, Flame, UserCheck, Bell, Activity,
  RefreshCw, Sliders, ArrowUpRight, BarChart2, CheckCircle2, XCircle
} from 'lucide-react';
import {
  AreaChart, Area, BarChart, Bar, LineChart, Line,
  XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid
} from 'recharts';
import { IndoreMapView } from '../components/map/IndoreMapView';
import { useFloodData } from '../context/FloodDataContext';
import { CatchmentZone, PumpRecommendation, Incident } from '../types';

export const MunicipalDashboard: React.FC = () => {
  const {
    floodStatus, sensors, assets, incidents, pumpRecs,
    triggerScenario, updateAssetStatus, assignIncident,
    updateIncidentStatus, actOnRecommendation, broadcastAlert, refreshData, isLoading
  } = useFloodData();

  // Scenario Simulator State
  const [selectedScenario, setSelectedScenario] = useState<string>('Heavy Downpour (45 mm/h)');
  const [customRainfall, setCustomRainfall] = useState<number>(floodStatus?.rainfall_rate_mmh || 45.0);
  const [isSimulating, setIsSimulating] = useState<boolean>(false);

  // Broadcast Alert Form State
  const [alertTitle, setAlertTitle] = useState<string>('FLASH FLOOD ADVISORY — LOW-LYING BASIN EVACUATION');
  const [alertSeverity, setAlertSeverity] = useState<string>('HIGH');
  const [alertZones, setAlertZones] = useState<string>('Rajwada, Sarafa, Chhavani');
  const [alertMessage, setAlertMessage] = useState<string>('Intense cloudburst runoff accumulating along Kahn River channel.');
  const [alertInstructions, setAlertInstructions] = useState<string>('Move valuable assets to upper floors. Follow emergency route signage.');
  const [alertSentMsg, setAlertSentMsg] = useState<string | null>(null);

  // Dispatch Modal / Selection
  const [selectedIncidentForDispatch, setSelectedIncidentForDispatch] = useState<Incident | null>(null);
  const [dispatchUnit, setDispatchUnit] = useState<string>('Palasia Fire Station - Rescue Boat 2');

  const zones = floodStatus?.zones || [];

  // Hydrograph Chart Data
  const hydrographData = [
    { time: '00:00', rain: 12, inflow: 14, depth: 16 },
    { time: '04:00', rain: 18, inflow: 22, depth: 22 },
    { time: '08:00', rain: 35, inflow: 45, depth: 38 },
    { time: '12:00', rain: floodStatus?.rainfall_rate_mmh || 45, inflow: 68, depth: floodStatus?.city_max_depth_cm || 48 },
    { time: '+1h (FC)', rain: (floodStatus?.rainfall_rate_mmh || 45) * 1.2, inflow: 78, depth: (floodStatus?.city_max_depth_cm || 48) * 1.25 },
    { time: '+2h (FC)', rain: (floodStatus?.rainfall_rate_mmh || 45) * 1.1, inflow: 62, depth: (floodStatus?.city_max_depth_cm || 48) * 1.1 },
    { time: '+3h (FC)', rain: (floodStatus?.rainfall_rate_mmh || 45) * 0.8, inflow: 40, depth: (floodStatus?.city_max_depth_cm || 48) * 0.85 },
  ];

  // Sensor telemetry bar chart data
  const sensorChartData = sensors.map(s => ({
    name: s.name.split(' ')[0],
    level: s.current_water_level_cm,
    warn: s.warning_threshold_cm,
    crit: s.critical_threshold_cm,
  }));

  // Handle Scenario Execution
  const handleRunScenario = async (name: string, rainRate: number) => {
    setIsSimulating(true);
    setSelectedScenario(name);
    setCustomRainfall(rainRate);
    try {
      await triggerScenario(name, rainRate);
    } catch (e) {
      console.error(e);
    } finally {
      setIsSimulating(false);
    }
  };

  // Handle Alert Broadcast
  const handleBroadcastSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await broadcastAlert({
        title: alertTitle,
        severity: alertSeverity,
        target_zones: alertZones,
        message: alertMessage,
        instructions: alertInstructions
      });
      setAlertSentMsg('Public Broadcast Alert transmitted across civil defense channels.');
      setTimeout(() => setAlertSentMsg(null), 6000);
    } catch (e) {
      console.error(e);
    }
  };

  // Handle Dispatch Confirm
  const handleConfirmDispatch = async () => {
    if (!selectedIncidentForDispatch) return;
    await assignIncident(selectedIncidentForDispatch.id, dispatchUnit);
    setSelectedIncidentForDispatch(null);
  };

  const activePumps = assets.filter(a => a.current_status === 'RUNNING').length;
  const criticalIncidents = incidents.filter(i => i.severity === 'CRITICAL' && i.status !== 'RESOLVED').length;

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6">
      
      {/* Header Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-5 rounded-2xl bg-slate-900 border border-slate-800 text-white shadow-xl">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded text-[10px] font-extrabold uppercase tracking-wider bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              Unified Command Center
            </span>
            <span className="text-xs text-slate-400">Indore Municipal Corporation (IMC)</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-extrabold tracking-tight mt-1">
            Municipal Disaster Response & Urban Drainage Operations
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Real-time telemetry, AI pump dispatch recommendations, scenario simulations & emergency lifecycle.
          </p>
        </div>

        <button
          onClick={() => refreshData()}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 border border-slate-700 transition-colors"
        >
          <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin text-sky-400' : ''}`} />
          <span>Sync City State</span>
        </button>
      </div>

      {/* Operational KPI Metrics Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-3">
        
        <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <span className="text-[11px] font-semibold text-slate-500 block">Hazard Level</span>
          <span className={`text-xl font-extrabold ${floodStatus?.city_hazard_level === 'CRITICAL' ? 'text-rose-500' : 'text-amber-500'}`}>
            {floodStatus?.city_hazard_level || 'HIGH'}
          </span>
          <span className="text-[10px] text-slate-400 block mt-0.5">City-wide Risk</span>
        </div>

        <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <span className="text-[11px] font-semibold text-slate-500 block">Rainfall Rate</span>
          <span className="text-xl font-extrabold text-sky-600 dark:text-sky-400">
            {floodStatus?.rainfall_rate_mmh.toFixed(1) || '45.0'} <span className="text-xs font-normal">mm/h</span>
          </span>
          <span className="text-[10px] text-slate-400 block mt-0.5">Precipitation Inflow</span>
        </div>

        <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <span className="text-[11px] font-semibold text-slate-500 block">Active Storm Pumps</span>
          <span className="text-xl font-extrabold text-emerald-600 dark:text-emerald-400">
            {activePumps} / {assets.length}
          </span>
          <span className="text-[10px] text-slate-400 block mt-0.5">Kahn River Stations</span>
        </div>

        <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <span className="text-[11px] font-semibold text-slate-500 block">Critical Incidents</span>
          <span className="text-xl font-extrabold text-rose-500">
            {criticalIncidents}
          </span>
          <span className="text-[10px] text-slate-400 block mt-0.5">Pending Dispatch</span>
        </div>

        <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <span className="text-[11px] font-semibold text-slate-500 block">Max Basin Depth</span>
          <span className="text-xl font-extrabold text-slate-900 dark:text-white">
            {floodStatus?.city_max_depth_cm.toFixed(1) || '48.0'} cm
          </span>
          <span className="text-[10px] text-slate-400 block mt-0.5">Rajwada Depression</span>
        </div>

        <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <span className="text-[11px] font-semibold text-slate-500 block">AI Advisories</span>
          <span className="text-xl font-extrabold text-indigo-500">
            {pumpRecs.filter(r => r.status === 'PENDING').length} Actionable
          </span>
          <span className="text-[10px] text-slate-400 block mt-0.5">Hydraulic Rules</span>
        </div>

      </div>

      {/* Scenario Simulator & Prediction Control Panel */}
      <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-indigo-500/10 text-indigo-500">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">AI Scenario Simulator & Inundation Forecaster</h2>
              <p className="text-xs text-slate-500">Simulate synthetic precipitation events to forecast downstream catchment surge before real-world flooding occurs.</p>
            </div>
          </div>
          <span className="text-[11px] font-mono text-slate-400 font-bold">Active: {selectedScenario}</span>
        </div>

        {/* Preset Buttons */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          <button
            onClick={() => handleRunScenario('Normal Monsoon (15 mm/h)', 15.0)}
            disabled={isSimulating}
            className={`p-3 rounded-xl border text-xs font-bold transition-all text-left ${customRainfall === 15.0 ? 'border-emerald-500 bg-emerald-500/10 text-emerald-600' : 'border-slate-200 dark:border-slate-800 hover:border-slate-300'}`}
          >
            <div className="flex items-center justify-between mb-1">
              <span>Normal Monsoon</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded bg-emerald-100 text-emerald-800">15 mm/h</span>
            </div>
            <p className="text-[11px] text-slate-500 font-normal">Moderate channel flow, zero road blockages.</p>
          </button>

          <button
            onClick={() => handleRunScenario('Heavy Downpour (45 mm/h)', 45.0)}
            disabled={isSimulating}
            className={`p-3 rounded-xl border text-xs font-bold transition-all text-left ${customRainfall === 45.0 ? 'border-amber-500 bg-amber-500/10 text-amber-600' : 'border-slate-200 dark:border-slate-800 hover:border-slate-300'}`}
          >
            <div className="flex items-center justify-between mb-1">
              <span>Heavy Downpour</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded bg-amber-100 text-amber-800">45 mm/h</span>
            </div>
            <p className="text-[11px] text-slate-500 font-normal">Rajwada basin waterlogging, 1 pump required.</p>
          </button>

          <button
            onClick={() => handleRunScenario('Severe Cloudburst (85 mm/h)', 85.0)}
            disabled={isSimulating}
            className={`p-3 rounded-xl border text-xs font-bold transition-all text-left ${customRainfall === 85.0 ? 'border-rose-500 bg-rose-500/10 text-rose-600' : 'border-slate-200 dark:border-slate-800 hover:border-slate-300'}`}
          >
            <div className="flex items-center justify-between mb-1">
              <span>Severe Cloudburst</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded bg-rose-100 text-rose-800">85 mm/h</span>
            </div>
            <p className="text-[11px] text-slate-500 font-normal">Flash flood alert, Kahn river overtopping.</p>
          </button>

          <button
            onClick={() => handleRunScenario('Extreme 100-Year Event (120 mm/h)', 120.0)}
            disabled={isSimulating}
            className={`p-3 rounded-xl border text-xs font-bold transition-all text-left ${customRainfall === 120.0 ? 'border-rose-600 bg-rose-600/10 text-rose-600' : 'border-slate-200 dark:border-slate-800 hover:border-slate-300'}`}
          >
            <div className="flex items-center justify-between mb-1">
              <span>Extreme 100-Year Event</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded bg-rose-200 text-rose-900 font-extrabold">120 mm/h</span>
            </div>
            <p className="text-[11px] text-slate-500 font-normal">All 8 pumps engaged, city evacuation protocol.</p>
          </button>
        </div>

        {/* Custom Slider + Run Trigger */}
        <div className="flex flex-wrap items-center gap-4 pt-2">
          <div className="flex-1 min-w-[240px]">
            <div className="flex justify-between text-xs font-semibold mb-1">
              <span>Custom Precipitation Intensity:</span>
              <span className="font-mono text-sky-500 font-bold">{customRainfall} mm/h</span>
            </div>
            <input
              type="range"
              min={10}
              max={140}
              step={5}
              value={customRainfall}
              onChange={(e) => setCustomRainfall(Number(e.target.value))}
              className="w-full accent-indigo-600 h-1.5 rounded-lg bg-slate-200 dark:bg-slate-800 cursor-pointer"
            />
          </div>

          <button
            onClick={() => handleRunScenario(`Custom Simulation (${customRainfall} mm/h)`, customRainfall)}
            disabled={isSimulating}
            className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition-all shadow-md shadow-indigo-600/20 flex items-center gap-2"
          >
            {isSimulating ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4" />}
            <span>Run Hydraulic Prediction</span>
          </button>
        </div>

      </div>

      {/* Main Center: City GIS Map & Recharts Analytics */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Map View (Span 2) */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-sm text-slate-900 dark:text-slate-100">Municipal Command GIS Spatial View</h3>
            <span className="text-xs text-slate-400">8 Zones | 12 Sensors | 8 Pumps | Live Incidents</span>
          </div>

          <IndoreMapView
            zones={zones}
            sensors={sensors}
            assets={assets}
            incidents={incidents}
            height="520px"
          />
        </div>

        {/* Real-Time Hydrology Analytics (Span 1) */}
        <div className="space-y-4">
          
          {/* Hydrograph Chart Card */}
          <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-900 dark:text-slate-100">Precipitation vs Water Depth</span>
              <span className="text-[10px] text-slate-400 font-mono">24h + Forecast</span>
            </div>
            
            <div className="h-44 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={hydrographData}>
                  <CartesianGrid strokeDasharray="3 3" opacity={0.15} />
                  <XAxis dataKey="time" tick={{ fontSize: 10 }} />
                  <YAxis tick={{ fontSize: 10 }} />
                  <Tooltip />
                  <Area type="monotone" dataKey="depth" stroke="#0284c7" fill="#0284c7" fillOpacity={0.25} name="Depth (cm)" />
                  <Area type="monotone" dataKey="rain" stroke="#818cf8" fill="#818cf8" fillOpacity={0.15} name="Rain (mm/h)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Sensor Gauge Comparison */}
          <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-900 dark:text-slate-100">IoT Sensor Water Levels</span>
              <span className="text-[10px] text-slate-400 font-mono">Warning threshold: 30cm</span>
            </div>

            <div className="h-44 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={sensorChartData.slice(0, 6)}>
                  <CartesianGrid strokeDasharray="3 3" opacity={0.15} />
                  <XAxis dataKey="name" tick={{ fontSize: 9 }} />
                  <YAxis tick={{ fontSize: 10 }} />
                  <Tooltip />
                  <Bar dataKey="level" fill="#0284c7" name="Level (cm)" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="warn" fill="#f59e0b" name="Warning (cm)" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

        </div>

      </div>

      {/* AI Pump-Operation Recommendations & Drainage Asset Control */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Pump Recommendations Card */}
        <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Cpu className="w-5 h-5 text-indigo-500" />
              <div>
                <h3 className="font-bold text-sm text-slate-900 dark:text-slate-100">AI Drainage Pump Recommendations</h3>
                <p className="text-xs text-slate-500">Hydraulic mass balance calculations generate human-in-the-loop pump advisories.</p>
              </div>
            </div>
            <span className="text-xs font-bold px-2 py-0.5 rounded bg-indigo-500/10 text-indigo-500">
              Decision Support
            </span>
          </div>

          <div className="space-y-3">
            {pumpRecs.map((rec) => (
              <div key={rec.id} className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-indigo-500 transition-colors space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-xs">{rec.asset_name || rec.asset_id}</span>
                    <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded uppercase ${rec.urgency === 'CRITICAL' ? 'bg-rose-500/10 text-rose-500' : 'bg-amber-500/10 text-amber-500'}`}>
                      {rec.urgency}
                    </span>
                  </div>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${rec.status === 'ACCEPTED' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-slate-100 dark:bg-slate-800 text-slate-400'}`}>
                    {rec.status}
                  </span>
                </div>

                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                  {rec.rationale}
                </p>

                <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800 text-xs">
                  <span className="text-slate-400">Inflow: <strong>{rec.inflow_rate_m3s} m³/s</strong></span>
                  
                  {rec.status === 'PENDING' ? (
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => actOnRecommendation(rec.id, 'OVERRIDE', 'Dismissed by operator.')}
                        className="px-2.5 py-1 text-xs text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 font-semibold"
                      >
                        Override
                      </button>
                      <button
                        onClick={() => actOnRecommendation(rec.id, 'ACCEPT', 'Confirmed and executed.')}
                        className="px-3 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-sm transition-colors"
                      >
                        Execute Action
                      </button>
                    </div>
                  ) : (
                    <span className="text-emerald-500 font-bold flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Action Logged</span>
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Drainage Asset Inventory & Status Control */}
        <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Waves className="w-5 h-5 text-sky-500" />
              <div>
                <h3 className="font-bold text-sm text-slate-900 dark:text-slate-100">Stormwater Assets & Pumping Stations</h3>
                <p className="text-xs text-slate-500">8 Major municipal pump stations and lake retention sluice gates.</p>
              </div>
            </div>
            <span className="text-xs font-mono text-slate-400">Total: 8 Assets</span>
          </div>

          <div className="space-y-2.5 max-h-[380px] overflow-y-auto pr-1">
            {assets.map((asset) => (
              <div key={asset.id} className="p-3 rounded-xl border border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-900 dark:text-white">{asset.name}</span>
                    <span className="text-[10px] text-slate-400">({asset.asset_type.replace('_', ' ')})</span>
                  </div>
                  <div className="text-[11px] text-slate-500 mt-0.5">
                    Capacity: <strong>{asset.rated_capacity_m3s} m³/s</strong> | Silt Blockage: <strong>{asset.silt_blockage_pct}%</strong>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${asset.current_status === 'RUNNING' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-slate-200 dark:bg-slate-700 text-slate-400'}`}>
                    {asset.current_status}
                  </span>
                  <button
                    onClick={() => updateAssetStatus(asset.id, asset.current_status === 'RUNNING' ? 'OPERATIONAL' : 'RUNNING')}
                    className={`px-2.5 py-1 rounded text-xs font-bold transition-colors ${asset.current_status === 'RUNNING' ? 'bg-rose-500/10 text-rose-500 hover:bg-rose-500/20' : 'bg-emerald-600 hover:bg-emerald-500 text-white'}`}
                  >
                    {asset.current_status === 'RUNNING' ? 'Stop' : 'Start'}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* Emergency Incident Dispatch Queue */}
      <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <ShieldAlert className="w-5 h-5 text-rose-500" />
            <div>
              <h3 className="font-bold text-sm text-slate-900 dark:text-slate-100">Live Incident & Distress Queue</h3>
              <p className="text-xs text-slate-500">Citizen SOS alerts and crowdsourced waterlogging reports ready for verification & dispatch.</p>
            </div>
          </div>
          <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-rose-500/10 text-rose-500">
            {incidents.filter(i => i.status !== 'RESOLVED').length} Active
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-400 font-bold uppercase tracking-wider text-[10px]">
              <tr>
                <th className="p-3">Tracking Code</th>
                <th className="p-3">Type & Severity</th>
                <th className="p-3">Location Landmark</th>
                <th className="p-3">Stranded</th>
                <th className="p-3">Status</th>
                <th className="p-3">Assigned Unit</th>
                <th className="p-3 text-right">Dispatch Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {incidents.map((inc) => (
                <tr key={inc.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                  <td className="p-3 font-mono font-bold text-slate-900 dark:text-slate-100">{inc.tracking_code}</td>
                  <td className="p-3">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${inc.severity === 'CRITICAL' ? 'bg-rose-500/10 text-rose-500' : 'bg-amber-500/10 text-amber-500'}`}>
                      {inc.severity}
                    </span>
                    <span className="block text-[11px] text-slate-400 mt-0.5">{inc.incident_type}</span>
                  </td>
                  <td className="p-3">
                    <div className="font-semibold">{inc.landmark_address}</div>
                    <div className="text-[10px] text-slate-400">{inc.reported_by_name} ({inc.phone})</div>
                  </td>
                  <td className="p-3">
                    {inc.people_stranded > 0 ? (
                      <span className="font-bold text-rose-500">{inc.people_stranded} people</span>
                    ) : (
                      <span className="text-slate-400">Road</span>
                    )}
                  </td>
                  <td className="p-3">
                    <span className="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-bold text-[10px]">
                      {inc.status}
                    </span>
                  </td>
                  <td className="p-3 text-slate-600 dark:text-slate-300 font-medium">
                    {inc.assigned_unit || 'Unassigned'}
                  </td>
                  <td className="p-3 text-right">
                    {inc.status === 'REPORTED' ? (
                      <button
                        onClick={() => setSelectedIncidentForDispatch(inc)}
                        className="px-3 py-1 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs transition-colors"
                      >
                        Dispatch Unit
                      </button>
                    ) : inc.status === 'DISPATCHED' ? (
                      <button
                        onClick={() => updateIncidentStatus(inc.id, 'ON_SCENE', 'Unit arrived at scene.')}
                        className="px-3 py-1 rounded-lg bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs"
                      >
                        Mark On Scene
                      </button>
                    ) : (
                      <button
                        onClick={() => updateIncidentStatus(inc.id, 'RESOLVED', 'Rescue complete.')}
                        className="px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs"
                      >
                        Resolve
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Broadcast Emergency Alert Composer */}
      <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        <div className="flex items-center gap-2.5">
          <Bell className="w-5 h-5 text-amber-500" />
          <div>
            <h3 className="font-bold text-sm text-slate-900 dark:text-slate-100">Broadcast City-Wide Emergency Alert</h3>
            <p className="text-xs text-slate-500">Transmits push notifications to citizen portals and digital public signages.</p>
          </div>
        </div>

        {alertSentMsg && (
          <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400 text-xs font-semibold">
            {alertSentMsg}
          </div>
        )}

        <form onSubmit={handleBroadcastSubmit} className="space-y-3 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-2">
              <label className="block text-slate-500 font-semibold mb-1">Alert Headline</label>
              <input
                type="text"
                value={alertTitle}
                onChange={(e) => setAlertTitle(e.target.value)}
                required
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-bold"
              />
            </div>
            <div>
              <label className="block text-slate-500 font-semibold mb-1">Severity Level</label>
              <select
                value={alertSeverity}
                onChange={(e) => setAlertSeverity(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-bold"
              >
                <option value="CRITICAL">CRITICAL WARNING (Red)</option>
                <option value="HIGH">HIGH ADVISORY (Orange)</option>
                <option value="MODERATE">MODERATE WATCH (Yellow)</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-500 font-semibold mb-1">Message Content</label>
              <textarea
                rows={2}
                value={alertMessage}
                onChange={(e) => setAlertMessage(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
              />
            </div>
            <div>
              <label className="block text-slate-500 font-semibold mb-1">Public Safety Instructions</label>
              <textarea
                rows={2}
                value={alertInstructions}
                onChange={(e) => setAlertInstructions(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
              />
            </div>
          </div>

          <button
            type="submit"
            className="px-6 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs shadow-md transition-colors"
          >
            Broadcast Civil Defense Alert
          </button>
        </form>
      </div>

      {/* Dispatch Modal Overlay */}
      {selectedIncidentForDispatch && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-md p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-4">
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Dispatch Emergency Response Team
            </h3>
            <p className="text-xs text-slate-500">
              Assigning incident <strong>{selectedIncidentForDispatch.tracking_code}</strong> at {selectedIncidentForDispatch.landmark_address}.
            </p>

            <div>
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">Select Rescue Unit</label>
              <select
                value={dispatchUnit}
                onChange={(e) => setDispatchUnit(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-semibold"
              >
                <option value="Palasia Fire Station - Rescue Boat 2">Palasia Fire Station - Rescue Boat 2</option>
                <option value="Indore Cantonment Fire Tender #4">Indore Cantonment Fire Tender #4</option>
                <option value="IMC Drainage Ward Team 4 (Mobile Sump)">IMC Drainage Ward Team 4 (Mobile Sump)</option>
                <option value="SDRF Emergency Water Rescue Unit 1">SDRF Emergency Water Rescue Unit 1</option>
              </select>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setSelectedIncidentForDispatch(null)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmDispatch}
                className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs"
              >
                Confirm Dispatch
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
