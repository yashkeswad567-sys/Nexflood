import React, { useState } from 'react';
import {
  Wrench, CheckSquare, Cpu, AlertTriangle, CheckCircle2,
  Clock, MapPin, Activity, Battery, Radio, Send, RefreshCw
} from 'lucide-react';
import { useFloodData } from '../context/FloodDataContext';
import { WorkOrder, DrainageAsset, SensorDevice } from '../types';
import { IndoreMapView } from '../components/map/IndoreMapView';

export const FieldEngineerDashboard: React.FC = () => {
  const {
    floodStatus, workOrders, assets, sensors, completeWorkOrder, refreshData, isLoading
  } = useFloodData();
  const zones = floodStatus?.zones || [];

  // Active Inspection Form State
  const [selectedWO, setSelectedWO] = useState<WorkOrder | null>(workOrders[0] || null);
  const [inspectionSilt, setInspectionSilt] = useState<number>(5.0);
  const [inspectionNotes, setInspectionNotes] = useState<string>('Desilted intake screen, verified 100% unimpeded flow.');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Fault Report Form State
  const [faultAssetId, setFaultAssetId] = useState<string>(assets[0]?.id || 'PUMP_KAHN_01');
  const [faultType, setFaultType] = useState<string>('MECHANICAL_VIBRATION');
  const [faultDesc, setFaultDesc] = useState<string>('Bearing temperature elevated above 75°C. Immediate greasing advised.');
  const [faultSubmitted, setFaultSubmitted] = useState<boolean>(false);

  // Handle Inspection Completion
  const handleCompleteInspection = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedWO) return;

    setIsSubmitting(true);
    try {
      await completeWorkOrder(selectedWO.id, inspectionSilt, inspectionNotes);
      setSuccessMsg(`Work Order ${selectedWO.id} completed. Asset silt blockage updated to ${inspectionSilt}%.`);
      setTimeout(() => setSuccessMsg(null), 6000);
    } catch (e) {
      console.error(e);
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handle Fault Report
  const handleFaultSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFaultSubmitted(true);
    setTimeout(() => setFaultSubmitted(false), 6000);
  };

  const pendingOrders = workOrders.filter(w => w.status !== 'COMPLETED');
  const completedOrders = workOrders.filter(w => w.status === 'COMPLETED');

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6">
      
      {/* Field Engineer Banner */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-5 rounded-2xl bg-slate-900 border border-slate-800 text-white shadow-xl">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded text-[10px] font-extrabold uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/30">
              Drainage Operations & Infrastructure
            </span>
            <span className="text-xs text-slate-400">IMC Sewerage Division</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-extrabold tracking-tight mt-1">
            Field Engineering Portal & Asset Maintenance
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Work order execution, silt desilting verification, and ultrasonic sensor calibrations.
          </p>
        </div>

        <button
          onClick={() => refreshData()}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 border border-slate-700 transition-colors"
        >
          <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin text-amber-400' : ''}`} />
          <span>Refresh Tasks</span>
        </button>
      </div>

      {/* KPI Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        
        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <span className="text-xs text-slate-500 block">Pending Work Orders</span>
          <span className="text-2xl font-extrabold text-amber-500">{pendingOrders.length}</span>
          <span className="text-[10px] text-slate-400 block mt-1">Tasks requiring site visit</span>
        </div>

        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <span className="text-xs text-slate-500 block">Completed Inspections</span>
          <span className="text-2xl font-extrabold text-emerald-500">{completedOrders.length}</span>
          <span className="text-[10px] text-slate-400 block mt-1">Signed off with zero silt</span>
        </div>

        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <span className="text-xs text-slate-500 block">Healthy IoT Sensors</span>
          <span className="text-2xl font-extrabold text-sky-500">12 / 12</span>
          <span className="text-[10px] text-slate-400 block mt-1">100% heartbeat latency &lt;2s</span>
        </div>

        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <span className="text-xs text-slate-500 block">Average Silt Reduction</span>
          <span className="text-2xl font-extrabold text-indigo-500">-65%</span>
          <span className="text-[10px] text-slate-400 block mt-1">Post-desilting flow gain</span>
        </div>

      </div>

      {/* Location-Based Task & Asset Map */}
      <div className="p-5 sm:p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <MapPin className="w-5 h-5 text-amber-500" />
            <div>
              <h3 className="font-bold text-sm text-slate-900 dark:text-slate-100">Location-Based Drainage Asset & Task Map</h3>
              <p className="text-xs text-slate-500">Live spatial distribution of storm sumps, pumps, and ultrasonic sensors across Indore basins.</p>
            </div>
          </div>
          <span className="text-xs text-slate-400 font-mono hidden sm:inline">8 Assets • 12 Sensors</span>
        </div>
        <IndoreMapView
          zones={zones}
          sensors={sensors}
          assets={assets}
          height="360px"
        />
      </div>

      {/* Main Grid: Work Orders + Inspection Sign-Off Form */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Work Orders List */}
        <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <CheckSquare className="w-5 h-5 text-amber-500" />
              <h3 className="font-bold text-sm text-slate-900 dark:text-slate-100">Assigned Maintenance Work Orders</h3>
            </div>
            <span className="text-xs font-mono text-slate-400">{workOrders.length} Orders</span>
          </div>

          <div className="space-y-3">
            {workOrders.map((wo) => {
              const isSelected = selectedWO?.id === wo.id;
              const isDone = wo.status === 'COMPLETED';

              return (
                <div
                  key={wo.id}
                  onClick={() => setSelectedWO(wo)}
                  className={`p-4 rounded-xl border transition-all cursor-pointer ${
                    isSelected
                      ? 'border-amber-500 bg-amber-50/20 dark:bg-amber-950/20 shadow-sm'
                      : 'border-slate-200 dark:border-slate-800 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-xs">{wo.title}</span>
                      <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded uppercase ${
                        wo.priority === 'URGENT' ? 'bg-rose-500/10 text-rose-500' : 'bg-slate-100 dark:bg-slate-800 text-slate-400'
                      }`}>
                        {wo.priority}
                      </span>
                    </div>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                      isDone ? 'bg-emerald-500/10 text-emerald-500' : 'bg-amber-500/10 text-amber-500'
                    }`}>
                      {wo.status}
                    </span>
                  </div>

                  <p className="text-xs text-slate-500 line-clamp-2 mb-2">{wo.description}</p>

                  <div className="flex items-center justify-between text-[11px] text-slate-400 pt-2 border-t border-slate-100 dark:border-slate-800">
                    <span>Asset: <strong>{wo.asset_name || wo.asset_id}</strong></span>
                    <span>Silt: <strong>{wo.initial_silt_pct}%</strong></span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Inspection & Work Completion Submission Form */}
        <div id="inspection" className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <div className="flex items-center gap-2">
            <Wrench className="w-5 h-5 text-sky-500" />
            <div>
              <h3 className="font-bold text-sm text-slate-900 dark:text-slate-100">Submit Asset Inspection & Sign-Off</h3>
              <p className="text-xs text-slate-500">Record post-cleaning silt level and update drainage asset readiness in shared database.</p>
            </div>
          </div>

          {successMsg && (
            <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400 text-xs font-semibold">
              {successMsg}
            </div>
          )}

          {selectedWO ? (
            <form onSubmit={handleCompleteInspection} className="space-y-4 text-xs">
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 space-y-1">
                <div className="text-slate-400 text-[10px] uppercase font-bold">Selected Work Order</div>
                <div className="font-bold text-sm text-slate-900 dark:text-white">{selectedWO.title}</div>
                <div className="text-slate-500">Asset: {selectedWO.asset_name} ({selectedWO.asset_id})</div>
              </div>

              <div>
                <div className="flex justify-between font-semibold mb-1">
                  <span>Verified Remaining Silt Level (%):</span>
                  <span className="font-mono text-emerald-500 font-bold">{inspectionSilt}%</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={40}
                  step={1}
                  value={inspectionSilt}
                  onChange={(e) => setInspectionSilt(Number(e.target.value))}
                  className="w-full accent-emerald-500 h-1.5 rounded-lg bg-slate-200 dark:bg-slate-800 cursor-pointer"
                />
                <span className="text-[10px] text-slate-400">Target standard: &lt;10% silt blockage.</span>
              </div>

              <div>
                <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">Inspection Notes & Sign-Off Narrative</label>
                <textarea
                  rows={3}
                  value={inspectionNotes}
                  onChange={(e) => setInspectionNotes(e.target.value)}
                  required
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                />
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md transition-colors flex items-center justify-center gap-2"
              >
                {isSubmitting ? <RefreshCw className="w-4 h-4 animate-spin" /> : <CheckCircle2 className="w-4 h-4" />}
                <span>Sign Off Work Order & Desilt Asset</span>
              </button>
            </form>
          ) : (
            <div className="p-8 text-center text-xs text-slate-400">
              Select a work order from the left to submit inspection.
            </div>
          )}

        </div>

      </div>

      {/* Sensor Health & Telemetry Diagnostics Table */}
      <div id="sensors" className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Cpu className="w-5 h-5 text-indigo-500" />
            <h3 className="font-bold text-sm text-slate-900 dark:text-slate-100">ESP32 IoT Sensor Diagnostics & Calibration</h3>
          </div>
          <span className="text-xs text-slate-400">12 Active Devices</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-400 font-bold uppercase tracking-wider text-[10px]">
              <tr>
                <th className="p-3">Device ID</th>
                <th className="p-3">Location Station</th>
                <th className="p-3">Water Depth</th>
                <th className="p-3">Flow Rate</th>
                <th className="p-3">Battery</th>
                <th className="p-3">Heartbeat</th>
                <th className="p-3 text-right">Diagnostic Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {sensors.map((s) => (
                <tr key={s.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                  <td className="p-3 font-mono font-bold">{s.id}</td>
                  <td className="p-3 font-semibold">{s.name}</td>
                  <td className="p-3 font-bold text-sky-600 dark:text-sky-400">{s.current_water_level_cm.toFixed(1)} cm</td>
                  <td className="p-3">{s.current_flow_rate_m3s.toFixed(1)} m³/s</td>
                  <td className="p-3">
                    <span className="flex items-center gap-1 font-mono text-emerald-500">
                      <Battery className="w-3.5 h-3.5" />
                      {s.battery_pct.toFixed(0)}%
                    </span>
                  </td>
                  <td className="p-3 text-slate-400 text-[10px]">Just now</td>
                  <td className="p-3 text-right">
                    <button
                      onClick={() => alert(`Diagnostic ping sent to ${s.id}. Round-trip latency: 34ms. Calibration status: OPTIMAL.`)}
                      className="px-2.5 py-1 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 font-semibold"
                    >
                      Ping & Calibrate
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Equipment Fault Reporting Form */}
      <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        <div className="flex items-center gap-2">
          <AlertTriangle className="w-5 h-5 text-rose-500" />
          <h3 className="font-bold text-sm text-slate-900 dark:text-slate-100">Report Mechanical / Electrical Equipment Fault</h3>
        </div>

        {faultSubmitted && (
          <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400 text-xs font-semibold">
            Fault ticket logged in municipal dispatch queue. Urgent repair team notified.
          </div>
        )}

        <form onSubmit={handleFaultSubmit} className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
          <div>
            <label className="block text-slate-500 font-semibold mb-1">Asset Affected</label>
            <select
              value={faultAssetId}
              onChange={(e) => setFaultAssetId(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-semibold"
            >
              {assets.map(a => (
                <option key={a.id} value={a.id}>{a.name}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-slate-500 font-semibold mb-1">Fault Category</label>
            <select
              value={faultType}
              onChange={(e) => setFaultType(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-semibold"
            >
              <option value="MECHANICAL_VIBRATION">Mechanical Vibration / Bearing</option>
              <option value="IMPELLER_BLOCKAGE">Debris Impeller Jam</option>
              <option value="POWER_FEED_DROP">Substation Power Drop</option>
              <option value="SENSOR_DRIFT">Ultrasonic Sensor Drift</option>
            </select>
          </div>

          <div className="sm:col-span-3">
            <label className="block text-slate-500 font-semibold mb-1">Technical Observation</label>
            <textarea
              rows={2}
              value={faultDesc}
              onChange={(e) => setFaultDesc(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
            />
          </div>

          <div>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs transition-colors"
            >
              Log Emergency Fault Ticket
            </button>
          </div>
        </form>
      </div>

    </div>
  );
};
